import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-driver-delete-confirm',
  standalone: true,
  imports: [CommonModule,PopupAlertComponent,TranslateModule],
  templateUrl: './driver-delete-confirm.component.html',
  styleUrls: ['./driver-delete-confirm.component.scss']
})
export class DriverDeleteConfirmComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef < DriverDeleteConfirmComponent > ) {}
  confirm($event: any) {
    this.dialogRef.close('delete')
  }
  close($event: any) {
    this.dialogRef.close();
  }
}
