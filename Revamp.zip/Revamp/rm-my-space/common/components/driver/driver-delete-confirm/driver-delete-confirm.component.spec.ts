import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverDeleteConfirmComponent } from './driver-delete-confirm.component';

describe('DriverDeleteConfirmComponent', () => {
  let component: DriverDeleteConfirmComponent;
  let fixture: ComponentFixture<DriverDeleteConfirmComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DriverDeleteConfirmComponent]
    });
    fixture = TestBed.createComponent(DriverDeleteConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
