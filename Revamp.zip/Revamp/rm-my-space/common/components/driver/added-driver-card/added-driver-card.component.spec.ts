import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddedDriverCardComponent } from './added-driver-card.component';

describe('AddedDriverCardComponent', () => {
  let component: AddedDriverCardComponent;
  let fixture: ComponentFixture<AddedDriverCardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AddedDriverCardComponent]
    });
    fixture = TestBed.createComponent(AddedDriverCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
