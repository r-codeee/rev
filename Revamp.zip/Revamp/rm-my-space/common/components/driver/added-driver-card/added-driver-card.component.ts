import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { MatDialog } from '@angular/material/dialog';
import { DriverDeleteConfirmComponent } from '../driver-delete-confirm/driver-delete-confirm.component';

@Component({
  selector: 'art-added-driver-card',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './added-driver-card.component.html',
  styleUrls: ['./added-driver-card.component.scss']
})
export class AddedDriverCardComponent {
  @Input() driver;
  @Output() driverDelete = new EventEmitter<any>();
  private readonly dialog  = inject(MatDialog)
  openDelete(id){
    const  driveDialog = this.dialog.open(DriverDeleteConfirmComponent,{
      panelClass:'popup-variant__1'
    })
    driveDialog.afterClosed().subscribe((res)=>{
      if(res == 'delete'){
        this.driverDelete.emit(this.driver)
      }
    })
  }
}
