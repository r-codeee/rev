import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddedDriverListComponent } from './added-driver-list.component';

describe('AddedDriverListComponent', () => {
  let component: AddedDriverListComponent;
  let fixture: ComponentFixture<AddedDriverListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AddedDriverListComponent]
    });
    fixture = TestBed.createComponent(AddedDriverListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
