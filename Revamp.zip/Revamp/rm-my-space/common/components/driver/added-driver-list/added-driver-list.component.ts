import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddedDriverCardComponent } from '../added-driver-card/added-driver-card.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'art-added-driver-list',
  standalone: true,
  imports: [CommonModule,AddedDriverCardComponent,TranslateModule],
  templateUrl: './added-driver-list.component.html',
  styleUrls: ['./added-driver-list.component.scss']
})
export class AddedDriverListComponent {
  @Input() driverList;
  @Output() driverAction = new EventEmitter<any>();
  
  driverPassToParent(ev){
    this.driverAction.emit(ev)
  }
}
