import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverDeleteSuccessComponent } from './driver-delete-success.component';

describe('DriverDeleteSuccessComponent', () => {
  let component: DriverDeleteSuccessComponent;
  let fixture: ComponentFixture<DriverDeleteSuccessComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DriverDeleteSuccessComponent]
    });
    fixture = TestBed.createComponent(DriverDeleteSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
