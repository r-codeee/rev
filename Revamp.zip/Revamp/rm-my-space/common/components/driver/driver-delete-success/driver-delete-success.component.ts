import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Route, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-driver-delete-success',
  standalone: true,
  imports: [CommonModule,PopupAlertComponent,TranslateModule],
  templateUrl: './driver-delete-success.component.html',
  styleUrls: ['./driver-delete-success.component.scss']
})
export class DriverDeleteSuccessComponent {
  mode
  flow
  policyId;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef <DriverDeleteSuccessComponent>,private router:Router ) {
    this.mode = data.mode;
    this.flow = data.flow;
    this.policyId = data.policyId;
  }
  confirm($event: any) {
    if(this.mode == 'add-driver'){
      this.router.navigateByUrl(`/my-space/${this.flow}/policies/detail/${this.policyId}`)
    }
    this.dialogRef.close()
  }
  close($event: any) {
    this.dialogRef.close();
  }
}
