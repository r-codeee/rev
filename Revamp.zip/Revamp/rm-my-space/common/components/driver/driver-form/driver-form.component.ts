import {
	Component,
	Output,
	EventEmitter,
	OnInit,
	Input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RmDateInputComponent } from 'src/app/design-system/rm-date-input/rm-date-input.component';
// tslint:disable-next-line:max-line-length
import { CustomDropdownMultiselectComponent } from 'src/app/design-system/custom-dropdown-multiselect/custom-dropdown-multiselect.component';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { AddDriverFomValues } from '../../../data/addDriverFormValues';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { AddDriverFormValidationSchemaService } from '../../../services/add-driver-form-validation-schema.service';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { AddedDriverListComponent } from '../added-driver-list/added-driver-list.component';
import { DriverDeleteSuccessComponent } from '../driver-delete-success/driver-delete-success.component';
import { MatDialog } from '@angular/material/dialog';
import { AlertComponent } from '../../../../../design-system/alert/alert.component';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import moment from 'moment';
import { Router } from '@angular/router';
@Component({
	selector: 'art-driver-form',
	standalone: true,
	imports: [
		CommonModule,
		TranslateModule,
		ReactiveFormsModule,
		BasicInputComponent,
		RmDateInputComponent,
		CustomDropdownMultiselectComponent,
		ArtButtonComponent,
		AddedDriverListComponent,
		AlertComponent,
	],
	templateUrl: './driver-form.component.html',
	styleUrls: ['./driver-form.component.scss'],
	providers: [AddDriverFormValidationSchemaService],
})
export class DriverFormComponent
	extends BaseFormComponent<AddDriverFomValues>
	implements OnInit
{
	@Output() addDriver = new EventEmitter<any>();
	@Input() mode;
	vehiclesList = [];
	driverList = [];
	driverIDs = [];
	alreadyIds = [];
	newlyAddedDriverIds = [];
	submitted = false;
	values: AddDriverFomValues = { nationalId: '', dateOfBirth: '', vehicle: [] };
	vehiclesSelected = [];
	optionSelected = [];
	vehiclesSelectedIDs = [];
	currentLang;
	errorMessage;
	validationSchema =
		this.addDriverFormValidationSchemaService.createDriverValidationSchema();
	policyDetails;
	quote_id;
	referenceNumber;
	endorsementDrivers = [];
	endorsePendingQuotes;
	proceedEnabled = false;
	loader = false;
	added_drivers_QoteData;
	totalPremium = 0;
	maxDate;
	dobStartDate;
	dobEndDate;
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private languageService: RMLanguageService,
		private dialog: MatDialog,
		private state: ARTStorageService,
		private commonMSService: CommonMyspaceService,
		private route: Router,
		private translateService: TranslateService,
		private addDriverFormValidationSchemaService: AddDriverFormValidationSchemaService,
	) {
		super(formBuilderService);
		this.currentLang = this.languageService.activeLang();
		this.policyDetails = this.state.GetValue(this.commonMSService.STORAGE_KEY);
		if (this.policyDetails.vehicleDetails) {
			this.vehiclesList = this.policyDetails.vehicleDetails.map((vehicle, index) => {
				if(vehicle.addl_details.make_en && vehicle.addl_details.model_en){

					return {
						make: `${vehicle.addl_details.make_en}/${vehicle.addl_details.model_en}`,
						plateNumber: vehicle.addl_details.plate_number,
						id: vehicle.id_no,
						riskId: vehicle.id_no,
						Value: vehicle.id_no,
					};
				}else{
					return {
						plateNumber: vehicle.addl_details.plate_number,
						id: vehicle.id_no,
						riskId: vehicle.id_no,
						Value: vehicle.id_no,
					};
				}
			});
		}
		let date = moment().year() + '-12-31';
		this.maxDate = moment(date);
		this.dobStartDate = moment().locale('en').subtract(118, 'year');
		this.dobEndDate = moment().locale('en').subtract(16, 'year');
		this.driverList = this.policyDetails.driversDetails
			? this.policyDetails.driversDetails
			: [];
		this.driverList.forEach(driver => {
			this.driverIDs.push(driver.id_no);
			this.alreadyIds.push(driver.id_no);
		});
		this.added_drivers_QoteData = this.policyDetails.added_drivers_QoteData;
		if (this.added_drivers_QoteData) {
			this.quote_id = this.added_drivers_QoteData.quote_id;
			this.referenceNumber = this.added_drivers_QoteData.reference_number;
			this.getSummary(true);
		}
	}
	reInitializeData(addDriverData?) {
		this.driverIDs = [];
		this.driverList = [];
		this.policyDetails = this.state.GetValue(this.commonMSService.STORAGE_KEY);
		// this.driverList= this.policyDetails.driversDetails?this.policyDetails.driversDetails:[];
		// this.driverList.forEach(driver=>{
		//   this.driverIDs.push(driver['id_no']);
		// })
		if(this.newlyAddedDriverIds.length>0){
			this.proceedEnabled = true;
		}else{
			this.proceedEnabled = false;
		}
		if (addDriverData) {
			this.driverList.push(...addDriverData);
		}
	}
	ngOnInit(): void {
		super.ngOnInit();
	}
	onSubmit(values: AddDriverFomValues) {
		this.submitted = true;
		this.removeError();
		const payload = {
			id_type: values.nationalId.startsWith('1') ? 1 : 2,
			id_no: values.nationalId,
			dob: moment(values.dateOfBirth, 'DD-MM-YYYY').format('MM-YYYY'),
		};
		if(this.driverIDs.includes(payload['id_no'])){
		  this.errorMessage = this.translateService.instant('MY_SPACE.COMMON.DRIVER_ALREADY_EXIST')
		  return ;
		}
		if (this.vehiclesSelectedIDs.length > 0 ) {
			this.commonMSService.isLoadingGlobal.next(true);
			const endorsementPayload = {
					policy_number: this.policyDetails.POLICY_NUMBER,
					policy_id: this.policyDetails.POLICY_ID.toString(),
					endorsement_type: 'add_driver',
					driver_details: {},
					risk_items: [],
				},
				risk_items = [];
				let risk_items_id_no = [];
			const endorsementPayloadEndorse = {
				driver: {},
				risk_items: [],
			};
			this.vehiclesSelectedIDs.forEach(id => {
				risk_items.push(id);
			});
			
			endorsementPayload.risk_items = risk_items;
			endorsementPayloadEndorse.risk_items = risk_items;

			this.commonMSService.getDriverdetails(payload).subscribe(data => {
				console.log(data);
				if (data.customer_details && data.address_details) {
					endorsementPayload.driver_details = {
						id_type: payload.id_type,
						id_no: payload.id_no,
						first_name: data.customer_details.first_name_en,
						last_name: data.customer_details.last_name_en,
						addl_details: { ...data.customer_details, ...data.address_details },
					};
					endorsementPayloadEndorse.driver = {
						is_endorsement: true,
						quote_id: parseInt(this.quote_id),
						id_type: payload.id_type,
						id_no: payload.id_no,
						first_name: data.customer_details.first_name_en,
						last_name: data.customer_details.last_name_en,
						addl_details: { ...data.customer_details, ...data.address_details },
					};
					if (this.quote_id) {
						this.createDriverEndorseAlready(endorsementPayloadEndorse);
					} else {
						this.createDriverEndorse(endorsementPayload);
					}
				}
			},(error)=>{
				this.submitted = false;
				this.commonMSService.isLoadingGlobal.next(false);
				this.setError(error);
			});
		}
	}
	updateVehiclesList(ev) {
		this.vehiclesSelectedIDs = [];
		ev.forEach(selecetd => {
			// this.vehiclesSelected.push(selecetd.Value);
			this.vehiclesSelected.push(selecetd);
			if(this.quote_id) {
				// this.vehiclesSelectedIDs.push(Number(selecetd.id));
				this.vehiclesSelectedIDs.push(Number(selecetd));
			} else {
				this.vehiclesSelectedIDs.push(Number(selecetd));
				// this.vehiclesSelectedIDs.push(Number(selecetd.Value));
			}
			//
		});
		this.vehiclesSelected = [...new Set(this.vehiclesSelected)];
		this.vehiclesSelectedIDs = [...new Set(this.vehiclesSelectedIDs)];
		this.form.get('vehicle').setValue(this.vehiclesSelectedIDs);
	}

	resetForm(){
		this.submitted = false;
		this.isFormSubmitted = false
		this.vehiclesSelected = [];
		this.vehiclesSelectedIDs = [];
		this.form.reset();
	}
	createDriverEndorse(payload) {
		this.commonMSService.createEndorsement(payload).subscribe(
			data => {
				console.log(data);
				this.quote_id = data.quote_id;
				this.referenceNumber = data.reference_number;
				this.added_drivers_QoteData = data;
				this.proceedEnabled = true;
				this.state.mergeIntoExistValue(this.commonMSService.STORAGE_KEY, {
					added_drivers: this.driverList,
					added_drivers_QoteData: data,
					endorsementDrivers: this.endorsementDrivers,
				});
				this.getSummary(true);
			},
			error => {
				this.commonMSService.isLoadingGlobal.next(false);
				this.submitted = false;
				this.isFormSubmitted = false
				this.setError(error);
			},
		);
	}
	createDriverEndorseAlready(payload) {
		this.commonMSService.driverCreate(payload).subscribe(
			data => {
				// this.quote_id = data.quote_id;
				// this.referenceNumber = data.reference_number;
				data.id_no = payload.driver.id_no;
				this.proceedEnabled = true;
				// quoteData: data,
				// reference_number: this.referenceNumber,
				this.state.mergeIntoExistValue(this.commonMSService.STORAGE_KEY, {
					added_drivers: this.driverList,
					endorsementDrivers: this.endorsementDrivers,
				});
				this.getSummary(true);
			},
			error => {
				this.commonMSService.isLoadingGlobal.next(false);
				this.submitted = false;
				this.isFormSubmitted = false
				this.setError(error);
			},
		);
	}
	submitaddDrierEndorsment() {
		this.removeError();
		this.commonMSService.isLoadingGlobal.next(true);
		const payload = {
			quote_id: this.added_drivers_QoteData.quote_id,
			policy_id: this.policyDetails.POLICY_ID.toString(),
		};
		this.commonMSService.submitEndorsement(payload).subscribe((data)=> {
				this.commonMSService.isLoadingGlobal.next(false);
				this.addDriverSuccess();
			},
			error => {
				this.commonMSService.isLoadingGlobal.next(false);
				this.setError(error);
			},
		);
	}
	getSummary(refresh) {
		const payload = {
			reference_number: this.added_drivers_QoteData.reference_number,
		};
		this.commonMSService.quoteSummary(payload).subscribe(data => {
			this.submitted = false;
			this.isFormSubmitted = false
			this.driverIDs = [];
			this.vehiclesSelectedIDs = [];
			this.vehiclesList = data.risk_item_details.map(vehicle => {
				if(vehicle.addl_details.make_en && vehicle.addl_details.model_en){
					return {
						make: `${vehicle.addl_details.make_en}/${vehicle.addl_details.model_en}`,
						plateNumber: vehicle.addl_details.plate_number,
						id: vehicle.id,
						riskId: vehicle.id,
						Value: vehicle.id,
					};
				}else{
					return {
						plateNumber: vehicle.addl_details.plate_number,
						id: vehicle.id,
						riskId: vehicle.id,
						Value: vehicle.id,
					};
				}
			});

			data.driver_details.forEach(driver => {
				this.driverIDs.push(driver.id_no);
				if (!this.alreadyIds.includes(driver.id_no)) {
					driver.newlyAdded = true;
					this.newlyAddedDriverIds.push(driver.id_no)
				}
			});

			if (refresh) {
				this.reInitializeData(data.driver_details);
			}
			const payload = {
				reference_number: this.referenceNumber,
				endorsement_type: 'add_driver',
				policy_id: this.policyDetails.POLICY_ID.toString(),
			};
			this.commonMSService.getRateMotorEndorsement(payload).subscribe(
				data => {
					console.log(data);
					const payload = { id: parseInt(this.quote_id) };
					this.commonMSService
						.calculatePremiumMotorEndorsement(payload)
						.subscribe(
							data => {
								this.commonMSService.isLoadingGlobal.next(false);
								this.totalPremium = data.premium;
								this.resetForm()
							},
							error => {
								this.submitted = false;
								this.isFormSubmitted = false
								this.commonMSService.isLoadingGlobal.next(false);
								this.setError(error);
							},
						);
				},
				error => {
					this.submitted = false;
					this.isFormSubmitted = false
					this.commonMSService.isLoadingGlobal.next(false);
					this.setError(error);
				},
			);
		},error => {
			this.submitted = false;
			this.isFormSubmitted = false
			this.commonMSService.isLoadingGlobal.next(false);
			this.setError(error);
		});
	}
	proceed() {
		if(this.totalPremium == 0){
			this.submitaddDrierEndorsment()
		}else{
			if(this.mode == 'individual'){
			  this.route.navigateByUrl('/my-space/individual/payment/add-driver')
			}else{
			  this.route.navigateByUrl('/my-space/sme/payment/add-driver')
			}
		}
	}

	deletedriver(ev) {
		this.loader = true;
		this.removeError();
		this.commonMSService.isLoadingGlobal.next(true);
		if (!ev.newlyAdded) {
			const deleteDriverEndorsmentpayload = {
				policy_id: this.policyDetails.POLICY_ID.toString(),
				endorsement_type: 'delete_driver',
				id_no: [ev.id_no.toString()],
			};
			this.commonMSService
				.createEndorsement(deleteDriverEndorsmentpayload)
				.subscribe(
					data => {
						const deleteDriverEndorsmentpayloadSubmit = {
							policy_id: this.policyDetails.POLICY_ID,
							drivers: [
								{
									license_no: ev.id_no,
									dob: ev.addl_details.dob,
								},
							],
							quote_id: data.quote_id,
						};
						this.commonMSService
							.endoDeleteDriver(deleteDriverEndorsmentpayloadSubmit)
							.subscribe(
								data => {
									this.loader = false;
									this.commonMSService.isLoadingGlobal.next(false);
									this.deleteSuccess();
								},
								error => {
									this.loader = false;
									this.commonMSService.isLoadingGlobal.next(false);
									this.setError(error);
								},
							);
					},
					error => {
						this.loader = false;
						this.commonMSService.isLoadingGlobal.next(false);
						this.setError(error);
					},
				);
		} else {
			const payload = { id: ev.id };
			this.commonMSService.driverDelete(payload).subscribe(
				data => {
					this.loader = false;
					this.getSummary(true);
					this.deleteSuccess();
				},
				error => {
					this.loader = false;
					this.commonMSService.isLoadingGlobal.next(false);
					this.setError(error);
				},
			);
		}
	}
	setError(err) {
		if (err.error && err.error.error) {
			this.errorMessage = err.error.error;
			if(err.error.error_msg && this.currentLang == 'ar'){
				this.errorMessage = err.error.error_msg;
			}
          } else  if (err.error && err.error) {
            this.errorMessage = err.error;
			if(err.error_msg && this.currentLang == 'ar'){
				this.errorMessage = err.error_msg;
			}
          } else if (err.message) {
            this.errorMessage = err.message;
          } else {
            this.errorMessage = this.translateService.translations[this.currentLang].motorSME.oops;
        }
	}
	removeError() {
		this.errorMessage = undefined;
	}

	deleteSuccess() {
		this.dialog.open(DriverDeleteSuccessComponent, {
			panelClass: 'popup-variant__1',
			data: {mode:'delete-driver',flow:this.mode},
		});
	}
	addDriverSuccess() {
		this.dialog.open(DriverDeleteSuccessComponent, {
			panelClass: 'popup-variant__1',
			data: {mode:'add-driver',flow:this.mode, policyId: this.policyDetails.POLICY_ID},
		});
	}
}
