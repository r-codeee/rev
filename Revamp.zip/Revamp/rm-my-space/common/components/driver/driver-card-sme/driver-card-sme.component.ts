import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-driver-card-sme',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './driver-card-sme.component.html',
  styleUrls: ['./driver-card-sme.component.scss']
})
export class DriverCardSmeComponent {

}
