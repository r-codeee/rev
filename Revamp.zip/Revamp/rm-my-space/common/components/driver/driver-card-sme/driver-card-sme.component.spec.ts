import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverCardSmeComponent } from './driver-card-sme.component';

describe('DriverCardSmeComponent', () => {
  let component: DriverCardSmeComponent;
  let fixture: ComponentFixture<DriverCardSmeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DriverCardSmeComponent]
    });
    fixture = TestBed.createComponent(DriverCardSmeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
