import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';

@Component({
  selector: 'art-driver-card',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './driver-card.component.html',
  styleUrls: ['./driver-card.component.scss']
})
export class DriverCardComponent {
  @Input() driverData
}
