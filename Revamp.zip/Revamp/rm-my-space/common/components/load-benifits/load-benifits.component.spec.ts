import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadBenifitsComponent } from './load-benifits.component';

describe('LoadBenifitsComponent', () => {
  let component: LoadBenifitsComponent;
  let fixture: ComponentFixture<LoadBenifitsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [LoadBenifitsComponent]
    });
    fixture = TestBed.createComponent(LoadBenifitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
