import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogData } from 'src/app/claims/claim-modal/claim-modal.component';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';

@Component({
  selector: 'art-load-benifits',
  standalone: true,
  imports: [CommonModule,TranslateModule, ArtButtonComponent],
  templateUrl: './load-benifits.component.html',
  styleUrls: ['./load-benifits.component.scss']
})
export class LoadBenifitsComponent {
  benifits
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private dialogRef: MatDialogRef<LoadBenifitsComponent>
    
  ) {
    this.benifits = data
  }
  close(){
    this.dialogRef.close();
  }
}
