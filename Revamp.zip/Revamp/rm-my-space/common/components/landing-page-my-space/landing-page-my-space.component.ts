import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderMySpaceComponent } from "../header-my-space/header-my-space.component";
import { SidebarMySpaceComponent } from "../sidebar-my-space/sidebar-my-space.component";
import { FooterMobileMySpaceComponent } from "../footer-mobile-my-space/footer-mobile-my-space.component";

@Component({
  selector: 'art-landing-page-my-space',
  standalone: true,
  imports: [CommonModule, HeaderMySpaceComponent, SidebarMySpaceComponent, FooterMobileMySpaceComponent],
  templateUrl: './landing-page-my-space.component.html',
  styleUrls: ['./landing-page-my-space.component.scss']
})
export class LandingPageMySpaceComponent {
  @Input() SidebarConfig;
  @Input() HeaderConfig;
  @Input() FooterConfig;
  @Input() mode;
  sidebarExpanded = false;
  sidebarMobilePop = false;
  updateConfig(ev){
    this.sidebarExpanded = (ev.expandSidebar)?ev.expandSidebar:false;
    this.sidebarMobilePop =  (ev.sidebarPopup)?ev.sidebarPopup:false;
    if(this.sidebarMobilePop){
      this.SidebarConfig.popUp = this.sidebarMobilePop;
    }
  }
}
