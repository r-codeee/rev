import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';


@Component({
  selector: 'art-cancel-submitted-popup',
  standalone: true,
  imports: [CommonModule,PopupAlertComponent,TranslateModule],
  templateUrl: './cancel-submitted-popup.component.html',
  styleUrls: ['./cancel-submitted-popup.component.scss']
})
export class CancelSubmittedPopupComponent {
  referenceId;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef <CancelSubmittedPopupComponent> ) {
    this.referenceId = data.referenceId;
  }
  track($event: any) {
    this.dialogRef.close('track')
  }
  dashboard($event: any) {
    this.dialogRef.close('dashboard');
  }
}
