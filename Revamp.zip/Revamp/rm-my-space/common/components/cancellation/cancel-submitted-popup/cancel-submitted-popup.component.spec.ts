import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelSubmittedPopupComponent } from './cancel-submitted-popup.component';

describe('CancelSubmittedPopupComponent', () => {
  let component: CancelSubmittedPopupComponent;
  let fixture: ComponentFixture<CancelSubmittedPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CancelSubmittedPopupComponent]
    });
    fixture = TestBed.createComponent(CancelSubmittedPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
