import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorCancelFormComponent } from './motor-cancel-form.component';

describe('MotorCancelFormComponent', () => {
  let component: MotorCancelFormComponent;
  let fixture: ComponentFixture<MotorCancelFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MotorCancelFormComponent]
    });
    fixture = TestBed.createComponent(MotorCancelFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
