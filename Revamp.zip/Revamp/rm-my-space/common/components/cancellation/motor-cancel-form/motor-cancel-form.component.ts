import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { CancelConfirmPopupComponent } from '../cancel-confirm-popup/cancel-confirm-popup.component';
import { CustomDropdownComponent } from 'src/app/design-system/custom-dropdown/custom-dropdown.component';
import { AlertComponent } from 'src/app/design-system/alert/alert.component';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { MotorCancellationFomValues,cancellationReasons,RefundList,CancellMethodnums } from '../../../data/motorCancellationValues';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { MotorCancellationFormValidationSchemaService } from '../../../services/motor-cacellation-form-validation-schema.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { CheckboxInputWithTextComponent } from 'src/app/design-system/checkbox-input-with-text/checkbox-input-with-text.component';
import { BasicTextareaComponent } from 'src/app/design-system/basic-textarea/basic-textarea.component';
import { ArtUploadButtonComponent } from 'src/app/design-system/art-upload-button/art-upload-button.component';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { CancelSubmittedPopupComponent } from '../cancel-submitted-popup/cancel-submitted-popup.component';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'art-motor-cancel-form',
  standalone: true,
  imports: [CommonModule,TranslateModule, 
    ReactiveFormsModule, BasicInputComponent,AlertComponent,
    CustomDropdownComponent,ArtButtonComponent,
    CheckboxInputWithTextComponent,BasicTextareaComponent,
    ArtUploadButtonComponent
  ],
  templateUrl: './motor-cancel-form.component.html',
  styleUrls: ['./motor-cancel-form.component.scss'],
  providers:[MotorCancellationFormValidationSchemaService]
})
export class MotorCancelFormComponent extends BaseFormComponent<MotorCancellationFomValues>
implements OnInit{
  @Input() mode;
  @Input() policyDetails;
  @Output() cancelPolicy =  new EventEmitter<any>();
  private  readonly dialog = inject(MatDialog)
  showFileerror;
  showFileerrors = [];
  uploadSuffixComponent = IconComponent;
	uploadSuffixComponentInputs = { icon: 'fa fa-arrow-up-from-bracket', size: 'xs' };

  private  readonly mcFormValidationSchemaService = inject(MotorCancellationFormValidationSchemaService)
  payload;
  submitted = false;
  values: MotorCancellationFomValues = {
    cancellation_reason : '',
    remarks : '',
    iban_no : '',
    accountHolderName : '',
    confirm1 : false,
    confirm2 : false,
  };
  // bankName : '',
  cancellationReasonOptions = cancellationReasons;
  CancellMethodnums = CancellMethodnums;
  RefundListOptions = RefundList;
  currentLang;
  refundOptionValue;
  cancellationReasonValue;
  errorMessage;
  quoteData;
  validationSchema = this.mcFormValidationSchemaService.createCancellationValidationSchema()
  constructor(
    protected formBuilderService: ArtFormBuilderService,
    private languageService: RMLanguageService,
    private CommonMsService: CommonMyspaceService,
    private storage: ARTStorageService,
    private router: Router,
  ){
    super(formBuilderService);
    this.currentLang = this.languageService.activeLang();
    
  }
  ngOnInit(): void {
    super.ngOnInit();
    this.policyDetails =  this.storage.GetValue(this.CommonMsService.STORAGE_KEY);
  }

  setReasons(ev){
    this.cancellationReasonValue = ev.id
    this.form.get('cancellation_reason').setValue(this.cancellationReasonValue);
  }

  setRefund(ev){
    this.refundOptionValue = ev.id;
  }

  confirmCancellation(values){
    const confirm =  this.dialog.open(CancelConfirmPopupComponent,{
      panelClass:'popup-variant__1',
      data:this.policyDetails.POLICY_NUMBER
    }) 
    confirm.afterClosed().subscribe((res)=>{
      if(res == 'confirm'){
        this.cancelProcess(values)
      }
    })
  }

  successCancellation(ref){
    const cacnelSubmited =  this.dialog.open(CancelSubmittedPopupComponent,{
      panelClass:'popup-variant__1',
      data:{
        referenceId :ref
      }
    }) 
    cacnelSubmited.afterClosed().subscribe((res)=>{
      // if(res == 'track'){}
      if(res == 'dashboard'){
        let path = `/my-space/${this.mode}`;
        this.router.navigateByUrl(path)
      }
    })
  }

  cancelProcess(values: MotorCancellationFomValues){
    this.submitted = true;
    values['iban_no'] = values['iban_no'].toUpperCase();
   
    let payload = {"iban":values['iban_no'] }
    this.CommonMsService.ibanExist(payload).subscribe((res)=>{
      if(res.status){
        let payalod = {
          "endorsement_type":"cancel_policy",
          "policy_id":this.policyDetails.POLICY_ID.toString(),
          "accountHolderName":values['accountHolderName']
        };
        this.createEndorseCancellation(payalod).then(() => {
          let endorseCancel = {
            "policy_id":this.policyDetails.POLICY_ID.toString(),
            "cancellation_reason":values['cancellation_reason'],
            "endorse_type":"cancel_policy",
            "vehicle_seq":[]
          };
          this.endorseCancellationReason(endorseCancel).then(() => {
            let payloadCancel = {
              "policy_id":this.policyDetails.POLICY_ID.toString(),
              "iban_no":values['iban_no'],
              "quote_id":this.quoteData['quote_id'],
              "id_no":this.policyDetails.NATIONAL_ID,
              "accountHolderName":values['accountHolderName']
            };
            this.policyCancellation(payloadCancel).then(() => {
              this.submitted = false;
            });
          });
        });
      }else{
        this.submitted = false;
        this.errorMessage = "Invalid Iban";
      }
    },err=>{
      this.submitted = false;
      this.errorMessage = err.message;
    })
  }

  onSubmit(values: MotorCancellationFomValues) {
    this.confirmCancellation(values)
  }

  createEndorseCancellation(payload): Promise < void > {
    return new Promise((resolve, reject) => {
      this.CommonMsService.createEndorsement(payload).subscribe((res)=>{
        this.quoteData = res
        
        resolve();
      },err=>{
        this.submitted = false;
        this.errorMessage = err.error;
        reject();
      })
    });
  }
  
  endorseCancellationReason(payload): Promise < void > {
    return new Promise((resolve, reject) => {
      this.CommonMsService.endorseCancellationReason(payload).subscribe((res)=>{
        this.quoteData['cancelData'] = res
        resolve();
      },err=>{
        this.submitted = false;
        this.errorMessage = err.message;
        reject();
      })
    })
  }

  policyCancellation(payload): Promise < void > {
    return new Promise((resolve, reject) => {
      this.CommonMsService.policyCancellation(payload).subscribe((res)=>{
        this.successCancellation(this.quoteData['reference_number'])
        this.submitted = false;
        resolve();

      },err=>{
        this.submitted = false;
        this.errorMessage = err.message;
        reject();
      })
    })
  }
 
}
