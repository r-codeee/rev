import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelConfirmPopupComponent } from './cancel-confirm-popup.component';

describe('CancelConfirmPopupComponent', () => {
  let component: CancelConfirmPopupComponent;
  let fixture: ComponentFixture<CancelConfirmPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CancelConfirmPopupComponent]
    });
    fixture = TestBed.createComponent(CancelConfirmPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
