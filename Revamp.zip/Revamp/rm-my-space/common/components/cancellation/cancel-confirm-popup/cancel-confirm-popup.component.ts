import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-cancel-confirm-popup',
  standalone: true,
  imports: [CommonModule,PopupAlertComponent,TranslateModule],
  templateUrl: './cancel-confirm-popup.component.html',
  styleUrls: ['./cancel-confirm-popup.component.scss']
})
export class CancelConfirmPopupComponent {
  policNumber
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef <CancelConfirmPopupComponent> ) {
    this.policNumber = data;
  }
  confirm($event: any) {
    this.dialogRef.close('confirm')
  }
  close($event: any) {
    this.dialogRef.close();
  }
}
