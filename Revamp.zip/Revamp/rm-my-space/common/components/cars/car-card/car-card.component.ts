import { Component, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { TranslateModule } from '@ngx-translate/core';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import { Router } from '@angular/router';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import { MatDialog } from '@angular/material/dialog';
import { AddedAddonsPopupComponent } from '../../addons/added-addons-popup/added-addons-popup.component';
import { PendingEndordsementsPopupComponent } from '../../pending-endordsements-popup/pending-endordsements-popup.component';
import { PickLocalizedNamePipe } from 'src/app/rm-shared-components/pipes/pick-localized-name.pipe';

@Component({
  selector: 'art-car-card',
  standalone: true,
  imports: [CommonModule,IconComponent,TranslateModule,MatMenuModule,MatButtonModule, PickLocalizedNamePipe],
  templateUrl: './car-card.component.html',
  styleUrls: ['./car-card.component.scss']
})
export class CarCardComponent {
  @Input() carData;
  @Input() addOnsData;
  @Input() mode;
  private readonly router = inject(Router)
  private readonly storage = inject(ARTStorageService)
  private readonly commonMSService = inject(CommonMyspaceService)
  private readonly dialog = inject(MatDialog)
  customerData;
  constructor(){
    this.customerData = this.storage.GetValue(this.commonMSService.STORAGE_KEY)
  }
  goTo(link){
    if(this.customerData.pending_endorsement == 0){
      if(link =='/policies/update-plate-sequence-number'){
        this.storage.mergeIntoExistValue(this.commonMSService.STORAGE_KEY,{
          vehicleData: this.carData
        })
      }
      if(link =='/policies/add-addon'){
        this.storage.mergeIntoExistValue(this.commonMSService.STORAGE_KEY,{
          vehicleDataSelected: this.carData
        })
      }
      if(link =='/delete-vehicle'){
        this.storage.mergeIntoExistValue(this.commonMSService.STORAGE_KEY,{
          vehicleDataSelected: this.carData
        })
      }
      let redirectLink = '/my-space/'+this.mode+link;
      this.router.navigateByUrl(redirectLink)
    }else{
      // message
      this.dialog.open(PendingEndordsementsPopupComponent,{
        panelClass:'popup-variant__1'
      })
    }
  }
  openAddonsDetails(){
    this.dialog.open(AddedAddonsPopupComponent,{
      data: this.addOnsData,
      panelClass:'popup-variant__2'
    })
  }
}
