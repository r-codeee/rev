import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-download-application-my-space',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './download-application-my-space.component.html',
  styleUrls: ['./download-application-my-space.component.scss']
})
export class DownloadApplicationMySpaceComponent {

}
