import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { Router } from '@angular/router';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { ProfileService } from '../../services/rm-profile.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { SMEMySpaceService } from 'src/app/rm-my-space/sme/services/sme-my-space.service';

@Component({
  selector: 'art-header-my-space',
  standalone: true,
  imports: [CommonModule, TranslateModule, FormsModule, ReactiveFormsModule, BasicInputComponent, IconComponent],
  templateUrl: './header-my-space.component.html',
  styleUrls: ['./header-my-space.component.scss']
})
export class HeaderMySpaceComponent implements OnInit{
  @Input() HeaderConfig;
  @Input() mode;
  @Output() headerEvent =  new EventEmitter() ;
  siedbarPopup =  false;
  searchSuffixComponent = IconComponent;
	searchSuffixComponentInputs = { icon: 'art-search-icon', size: 'xs' };
  private router  = inject(Router);
  private RMLanguageService  = inject(RMLanguageService);
  private langService = inject(LanguageService);
  private profileService = inject(ProfileService);
  private storage = inject(ARTStorageService);
  private authService = inject(AuthService);
  private SMEMySpaceService = inject(SMEMySpaceService);
  currentLang = this.RMLanguageService.activeLang();
  Name;
  authData
  smedata
  ngOnInit(): void {
    
    this.authData = this.storage.GetValue(this.authService.STORAGE_KEY);
    if(this.mode == 'sme'){  
      if(this.authData.healthFlowDcp && this.authData.motorFlowNutirnos){
        // @TODO login is not implemented
      }
      else if(this.authData.healthFlowDcp){
        this.profileService.companyName.subscribe((name)=>{
          this.Name = name;
        })
      }else if(this.authData.motorFlowNutirnos){
        if(this.smedata && this.smedata.customer_info){
          this.Name = this.smedata.customer_info.company_name;
        }else{
          this.smedata = this.storage.GetValue(this.SMEMySpaceService.STORAGE_KEY);
          this.SMEMySpaceService.customerInfo.subscribe((data)=>{
            if(data){
              this.smedata = this.storage.GetValue(this.SMEMySpaceService.STORAGE_KEY);
              this.Name = this.smedata.customer_info.company_name;
            }
          })
        }
      }
    }else{
      this.profileService.getProfileLang(this.currentLang).subscribe((data) => {
        this.Name = this.currentLang == 'en'?data.firstName:data.firstNameAr;
        })
    }
  }
  redirect(link) {
    if(link == 'home'){
      if(this.mode =='individual'){
        this.router.navigateByUrl('/my-space/individual')
      }else{
        this.router.navigateByUrl('/my-space/sme')
      }
    }else{
      this.router.navigateByUrl(link)
    }
  }
  redirectProfile() {
    if(this.mode =='individual'){
      this.router.navigateByUrl('/my-space/individual/profile')
    }else{
      this.router.navigateByUrl(`/${this.currentLang}/endorsements/sme-profile`)
    }
  }
  callParentselectLang(lang) {
		localStorage.setItem('selectedLang', lang);
		const url = this.langService.switchedURL();
		if (url === '') {
			location.reload();
		} else {
			const querryParamas = { ...this.langService.currentQuerryParams };
			this.langService.currentQuerryParams = {};
			this.router.navigate([url], { queryParams: querryParamas }).then(res => {
				location.reload();
			});
		}
	}
  toggleSidebarPopup(){
    this.siedbarPopup =  true;
    this.headerEvent.emit({sidebarPopup:this.siedbarPopup})
  }

}
