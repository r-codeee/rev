import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { DialogData } from 'src/app/claims/claim-modal/claim-modal.component';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';

@Component({
  selector: 'art-limits-and-exclusions',
  standalone: true,
  imports: [CommonModule,TranslateModule, ArtButtonComponent],
  templateUrl: './limits-and-exclusions.component.html',
  styleUrls: ['./limits-and-exclusions.component.scss']
})
export class LimitsAndExclusionsComponent {
  limits
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private dialogRef: MatDialogRef<LimitsAndExclusionsComponent>
    
  ) {
    this.limits = data
  }
  close(){
    this.dialogRef.close();
  }
}
