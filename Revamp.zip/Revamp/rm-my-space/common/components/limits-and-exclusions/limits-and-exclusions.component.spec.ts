import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LimitsAndExclusionsComponent } from './limits-and-exclusions.component';

describe('LimitsAndExclusionsComponent', () => {
  let component: LimitsAndExclusionsComponent;
  let fixture: ComponentFixture<LimitsAndExclusionsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [LimitsAndExclusionsComponent]
    });
    fixture = TestBed.createComponent(LimitsAndExclusionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
