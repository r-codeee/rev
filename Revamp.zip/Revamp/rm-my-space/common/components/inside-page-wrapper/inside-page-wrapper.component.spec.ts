import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsidePageWrapperComponent } from './inside-page-wrapper.component';

describe('InsidePageWrapperComponent', () => {
  let component: InsidePageWrapperComponent;
  let fixture: ComponentFixture<InsidePageWrapperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [InsidePageWrapperComponent]
    });
    fixture = TestBed.createComponent(InsidePageWrapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
