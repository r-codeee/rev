import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';

@Component({
  selector: 'art-inside-page-wrapper',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './inside-page-wrapper.component.html',
  styleUrls: ['./inside-page-wrapper.component.scss']
})
export class InsidePageWrapperComponent {
  @Input() contentConfig;
  @Input() customClasses = 'grid-col-2-60-40';

}
