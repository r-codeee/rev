import { Component, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { Router } from '@angular/router';

@Component({
  selector: 'art-footer-mobile-my-space',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './footer-mobile-my-space.component.html',
  styleUrls: ['./footer-mobile-my-space.component.scss']
})
export class FooterMobileMySpaceComponent {
  @Input() FooterConfig
  readonly router = inject(Router)
  redirect(link) {
      this.router.navigateByUrl(link)
  }
}
