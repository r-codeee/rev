import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-heading-my-space',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './heading-my-space.component.html',
  styleUrls: ['./heading-my-space.component.scss']
})
export class HeadingMySpaceComponent {
  @Input() heading;

}
