import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-help-center-my-space',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './help-center-my-space.component.html',
  styleUrls: ['./help-center-my-space.component.scss']
})
export class HelpCenterMySpaceComponent {

}
