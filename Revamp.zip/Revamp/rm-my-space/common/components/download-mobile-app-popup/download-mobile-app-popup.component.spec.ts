import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadMobileAppPopupComponent } from './download-mobile-app-popup.component';

describe('DownloadMobileAppPopupComponent', () => {
  let component: DownloadMobileAppPopupComponent;
  let fixture: ComponentFixture<DownloadMobileAppPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DownloadMobileAppPopupComponent]
    });
    fixture = TestBed.createComponent(DownloadMobileAppPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
