import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';

@Component({
  selector: 'art-download-mobile-app-popup',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './download-mobile-app-popup.component.html',
  styleUrls: ['./download-mobile-app-popup.component.scss']
})
export class DownloadMobileAppPopupComponent {

  navigateTo(url) {
		window.open(url, '_blank');
	}
}
