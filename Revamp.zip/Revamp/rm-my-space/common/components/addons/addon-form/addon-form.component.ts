import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArtProductPlanCard } from "../../../../../design-system/rm-product-plan-card/rm-product-plan-card";
import { TranslateModule } from '@ngx-translate/core';
import { MatDialog } from '@angular/material/dialog';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { AddonDetailsPopupComponent } from '../addon-details-popup/addon-details-popup.component';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import { Router } from '@angular/router';

@Component({
  selector: 'art-addon-form',
  standalone: true,
  imports: [CommonModule, ArtProductPlanCard,TranslateModule,ArtButtonComponent],
  templateUrl: './addon-form.component.html',
  styleUrls: ['./addon-form.component.scss']
})
export class AddonFormComponent {
  @Output() addAddons = new EventEmitter<any>();
  @Input() mode;
  @Input() addons;
  private readonly dialog = inject(MatDialog);
  private readonly lanugaeService = inject(RMLanguageService);
  private readonly storage = inject(ARTStorageService);
  private readonly router = inject(Router);
  private readonly commonMSService = inject(CommonMyspaceService);
  addonsList = []
  selectedAddons = [];
  vehiclesSelectedIDs = [];
  selectedAddonsIds: any = [];
  totalPremim = 0
  submitted = false
  enableProceed = false
  selectedVehicleData;
  policyDetails;
  currentLang = localStorage.getItem('selectedLang');
  quote_id
  referenceNumber
  errorMessage;
  addonsDetails = [];
  alreadySelectedAddonsIds = [];
  constructor(){
    
    this.policyDetails =  this.storage.GetValue(this.commonMSService.STORAGE_KEY)
    this.selectedVehicleData = this.policyDetails.vehicleDataSelected; 
    this.vehiclesSelectedIDs.push(this.selectedVehicleData['id_no'])
    this.vehiclesSelectedIDs = [...this.vehiclesSelectedIDs]
    this.addonsDetails= this.policyDetails.addonsDetails;
    if(this.addonsDetails && this.addonsDetails.length > 0) {
    this.addonsDetails.forEach(async (addon,i)=>{
      this.alreadySelectedAddonsIds.push(addon.add_on_code);
    })
  }

    this.getAddons()
  }
  getAddons(){
    let addonsPayload = {"customer_type_id":1}
    this.commonMSService.masterAddOns(addonsPayload).subscribe(data=>{
      console.log(data)
      let addonsList = data[0]['add_ons']
      addonsList = addonsList.filter((addons)=> this.applicable(addons['applicable_products']))
      this.addonsList =  addonsList;
      this.getAddonsRate()
    },error=>{
      console.log(error)

    })
  }
  applicable(applicableProducts){
    let flag = false;
    applicableProducts.forEach((ap)=> {
      if(ap.product_id == this.selectedVehicleData.product_code){
        flag = true;
      }
    })
    return flag;
  }
  getAddonsRate(){
    let payload  = {"policy_id":this.policyDetails.POLICY_ID,"vehicle_id_no":[this.selectedVehicleData['id_no']]}
    this.commonMSService.endorseAddOnsRate(payload).subscribe(data=>{
      console.log(data)
      let addonsPrice = data[0]['plans'][this.selectedVehicleData.product_code]['add_ons'];
      this.addonsList.forEach(addon=>{
        if(addonsPrice[addon.cover_id]){
          addon['price'] = addonsPrice[addon.cover_id]['TotalPremium'];
        }
      })
      this.storage.mergeIntoExistValue(this.commonMSService.STORAGE_KEY,{
        addonsAllList:this.addonsList
      })
    },error=>{
      console.log(error)
    })
  }
  addonSelecetion(ev){
    console.log(ev);
    let obj = {
      "risk_items": this.vehiclesSelectedIDs,
      "add_on_code": null,
      "addl_details":{}
    }

    if(ev.isChecked){
      if(!this.selectedAddonsIds.includes(ev.value.cover_id)){
        obj['add_on_code'] = ev.value.cover_id;
        obj['addl_details'] = ev.value;
        this.selectedAddons.push(obj);
        this.selectedAddonsIds.push(ev.value.cover_id);
      }
      this.calculateTotal()
    }else{
      if(this.selectedAddons && this.selectedAddons.length>0){
        this.selectedAddonsIds = this.selectedAddonsIds.filter(id=> id != ev.value.cover_id)
        this.selectedAddons = this.selectedAddons.filter((addon)=> addon.add_on_code != ev.value.cover_id);
        this.calculateTotal()
      }
    }
    console.log(this.selectedAddons)
  }
  
  showBenifits(addon){
   let isDisabled =  this.checkedAddons(addon.cover_id);
    const addonDetailsPopupRef = this.dialog.open(AddonDetailsPopupComponent,{
      panelClass:'popup-variant__1',
      data:{
        addon:addon,
        isDisabled: isDisabled
      }
    })
    addonDetailsPopupRef.afterClosed().subscribe((res)=>{
      if(res == 'add'){
        let obj = {
          "risk_items": this.vehiclesSelectedIDs,
          "add_on_code": null,
          "addl_details":{}
        }
        if(this.selectedAddonsIds && !this.selectedAddonsIds.includes(addon.cover_id)){
          this.selectedAddonsIds.push(addon.cover_id)
          obj['add_on_code'] = addon.cover_id;
          obj['addl_details'] = addon;
          this.selectedAddons.push(obj);
          this.calculateTotal()
        }
      }
    })
  }
  calculateTotal(){
    if(this.selectedAddons.length == 0){
      this.totalPremim = 0;
      this.enableProceed = false;
      return;  
    }
    this.totalPremim =  this.selectedAddons.reduce( function(a, b){
      return a + b['addl_details']['price'];
    }, 0);
    this.enableProceed = true;
  }

  checkedAddons(id){
    if(this.alreadySelectedAddonsIds.includes(id)){
        return true;
    }else{
        return false;
    }
}

  proceed(){
    if(this.selectedAddons && this.selectedAddons.length > 0 && this.totalPremim > 0){ 
      let endorsmentPayload = {
        "policy_id": this.policyDetails.POLICY_ID.toString(),
        "endorsement_type": "add_covers",
        "add_ons": this.selectedAddons
      }
      this.commonMSService.createEndorsement(endorsmentPayload).subscribe(data=>{
        this.quote_id = data.quote_id
        this.referenceNumber = data.reference_number
        this.storage.mergeIntoExistValue(this.commonMSService.STORAGE_KEY,{
          added_addons:endorsmentPayload,
          quoteData:data,
          reference_number:this.referenceNumber
        })
        this.paymentInfo();
      },error=>{
        console.log(error)
        
      })
    }
  }
  paymentInfo(){
    if(this.mode == 'individual'){
      let payload = {"reference_number":this.referenceNumber,"endorsement_type":"add_covers","policy_id":this.policyDetails.POLICY_ID.toString()}
      this.commonMSService.getRateMotorEndorsement(payload).subscribe(data=>{
        console.log(data)
        let payload = {"reference_number":this.referenceNumber}
        this.commonMSService.quoteSummary(payload).subscribe(data=>{
          console.log(data)
          let payload = {"id":data.quote_details.id} 
          this.commonMSService.calculatePremiumMotorEndorsement(payload).subscribe(data=>{
            console.log(data)
              this.router.navigateByUrl('/my-space/individual/payment/add-addon')

          },error=>{
            this.errorMessage = error.message;
          })
        },error=>{
          this.errorMessage = error.message;
        })
      },error=>{
        this.errorMessage = error.message;
      })
      
    }else{
      this.router.navigateByUrl('/my-space/sme/payment/add-addon')
    }
  }
}
