import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'art-addon-details-popup',
  standalone: true,
  imports: [CommonModule,PopupAlertComponent,TranslateModule],
  templateUrl: './addon-details-popup.component.html',
  styleUrls: ['./addon-details-popup.component.scss']
})
export class AddonDetailsPopupComponent {
  heading
  addon
  description
  amount
  isAddAddon = true;
  isDisabled = false;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef < AddonDetailsPopupComponent > ) {
    this.addon =  data.addon;
    this.heading =  data.addon.cover_name;
    this.description =  data.addon.cover_desc;
    this.amount =  data.addon.price;
    this.isDisabled = data.isDisabled;
    if(data.addAddon){
      this.isAddAddon =  data.addAddon;
    }
  }
  add() {
    this.dialogRef.close('add')
  }
  close() {
    this.dialogRef.close();
  }
}
