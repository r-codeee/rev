import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArtProductPlanCard } from 'src/app/design-system/rm-product-plan-card/rm-product-plan-card';
import { TranslateModule } from '@ngx-translate/core';
import { MatDialog } from '@angular/material/dialog';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import { AddonDetailsPopupComponent } from '../../addons/addon-details-popup/addon-details-popup.component';
@Component({
  selector: 'art-addons-slider-with-actions',
  standalone: true,
  imports: [CommonModule,ArtProductPlanCard,TranslateModule,SlickCarouselModule],
  templateUrl: './addons-slider-with-actions.component.html',
  styleUrls: ['./addons-slider-with-actions.component.scss']
})
export class AddonsSliderWithActionsComponent  implements OnInit {
  addonsConfig
  private readonly dialog = inject(MatDialog);
  private readonly commonMSService = inject(CommonMyspaceService);
  private readonly storage = inject(ARTStorageService);
  private readonly langService = inject(RMLanguageService);
  @Input() addonsList = [];
  @Input() vehicleId;
  @Input() mode;
  @Input() itemsToDisplay = 4;
  @Input() responsive
  @Output() addonAdded = new EventEmitter();
  @Input() selectedAddonsIds: any = [];
  selectedAddons = [];
  vehiclesSelectedIDs = [];
  totalPremim = 0;
  policyDetails;
  change$:any;
  currentLang;
  addOnriskItems = {};
  addonsListFiltered = [];
  selected
  constructor(){
    this.policyDetails =  this.storage.GetValue(this.commonMSService.STORAGE_KEY)
    this.currentLang = this.langService.activeLang();
  }
  ngOnInit() {
  this.addonsListFiltered = this.addonsList;

    this.addonsConfig = {
      slidesToShow: 4,
      slidesToScroll: 1,
      speed: 500,
      dots: false,
      arrows: true,
      addonsListFiltered:false,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2.5,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1.5,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
      ],
      rtl: this.currentLang === "ar",
    };
  }
  

  addonSelecetion(ev){
    this.selected = ev.value.cover_id;
    console.log(ev);
    let obj = {
      "risk_items": this.vehiclesSelectedIDs,
      "add_on_code": null,
      "addl_details":{}
    }
    if(ev.cardClick){
      let data = {
        activeAddon:this.selected,
      }
      this.addonAdded.emit(data)
      this.calculateTotal()
    }
    else if(ev.isChecked){
      if(!this.selectedAddonsIds.includes(ev.value.cover_id)){
        obj['add_on_code'] = ev.value.cover_id;
        obj['addl_details'] = ev.value;
        this.selectedAddons.push(obj);
        this.selectedAddonsIds.push(ev.value.cover_id);
      }
      this.calculateTotal()
    }else{
      if(this.selectedAddons && this.selectedAddons.length>0){
        this.selectedAddonsIds = this.selectedAddonsIds.filter(id=> id != ev.value.cover_id)
        this.selectedAddons = this.selectedAddons.filter((addon)=> addon.add_on_code != ev.value.cover_id);
      }
      this.calculateTotal()
    }
    
    console.log(this.selectedAddons)
  }
  checkedAddons(cover_id){
    return this.selectedAddonsIds.includes(cover_id);
  }
  showBenifits(addon){
      const addonDetailsPopupRef = this.dialog.open(AddonDetailsPopupComponent,{
        panelClass:'popup-variant__1',
        data:{
          addon:addon
        }
      })
      addonDetailsPopupRef.afterClosed().subscribe((res)=>{
        if(res == 'add'){
          let obj = {
            "risk_items": this.vehiclesSelectedIDs,
            "add_on_code": null,
            "addl_details":{}
          }
          if(this.selectedAddonsIds && !this.selectedAddonsIds.includes(addon.cover_id)){
            this.selectedAddonsIds.push(addon.cover_id)
            obj['add_on_code'] = addon.cover_id;
            obj['addl_details'] = addon;
            this.selectedAddons.push(obj)
            this.calculateTotal()
          }
        }
      })
  }
  calculateTotal(){
    this.totalPremim =  this.selectedAddons.reduce( function(a, b){
        return a + b['addl_details']['price'];
    }, 0);
    let data = {
      totalPremim:this.totalPremim,
      selectedAddons:this.selectedAddons,
      activeAddon:this.selected,
    }
    this.addonAdded.emit(data)
  }
}
