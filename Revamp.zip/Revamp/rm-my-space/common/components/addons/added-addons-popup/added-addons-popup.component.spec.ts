import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddedAddonsPopupComponent } from './added-addons-popup.component';

describe('AddedAddonsPopupComponent', () => {
  let component: AddedAddonsPopupComponent;
  let fixture: ComponentFixture<AddedAddonsPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AddedAddonsPopupComponent]
    });
    fixture = TestBed.createComponent(AddedAddonsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
