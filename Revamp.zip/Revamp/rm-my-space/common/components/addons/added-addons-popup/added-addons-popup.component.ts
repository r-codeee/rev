import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'art-added-addons-popup',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent],
  templateUrl: './added-addons-popup.component.html',
  styleUrls: ['./added-addons-popup.component.scss']
})
export class AddedAddonsPopupComponent {

  addons
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef < AddedAddonsPopupComponent > ) {
      this.addons =  data;
    }

    navigateTo(url) {
      window.open(url, '_blank');
    }
}
