import {Component, inject, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { CommonMyspaceService } from '../../../services/common-myspace.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
@Component({
  selector: 'art-addons-slider',
  standalone: true,
  imports: [CommonModule,TranslateModule,IconComponent,SlickCarouselModule],
  templateUrl: './addons-slider.component.html',
  styleUrls: ['./addons-slider.component.scss']
})
export class AddonsSliderComponent implements OnInit {
  addonsConfig
  private readonly commonMSService = inject(CommonMyspaceService);
  private readonly storage = inject(ARTStorageService);
  private readonly langService = inject(RMLanguageService);
  @Input() addonsList = [];
  @Input() vehicleId;
  @Input() mode;
  @Input() itemsToDisplay = 4;
  @Input() itemWidthXl = 250;
  @Input() itemWidthMD = 290;
  @Input() itemWidthSM = 225;
  selectedAddons = [];
  vehiclesSelectedIDs = [];
  selectedAddonsIds: any = [];
  totalPremim = 0;
  policyDetails;
  selectedVehicleData;
  change$:any;
  currentLang;
  addOnriskItems = {};
  addonsListFiltered = [];
  constructor(){
    this.policyDetails =  this.storage.GetValue(this.commonMSService.STORAGE_KEY)
    this.selectedVehicleData = this.policyDetails.vehicleDataSelected;
    this.currentLang = this.langService.activeLang();
  }
  ngOnInit() {
    this.addonsList.forEach((addon)=>{
      addon.risk_items.forEach((vehicel)=>{
        if(this.addOnriskItems[addon.add_on_code]){
          this.addOnriskItems[addon.add_on_code].push(vehicel['id_no'])
        }else{
          this.addOnriskItems[addon.add_on_code] = []
          this.addOnriskItems[addon.add_on_code].push(vehicel['id_no'])
        }
      })
    });
    console.log(this.addOnriskItems)
    if(this.vehicleId){
      this.addonsListFiltered = this.addonsList.filter((addon)=>{
        if(this.addOnriskItems[addon.add_on_code].includes(this.vehicleId)){
          return addon;
        }
      })
    }
    let slidesToShow,slidesToShow1024,slidesToShow768,slidesToShow576
    if(this.mode  == 'small'){
      slidesToShow = 2
      slidesToShow1024 = 2 
      slidesToShow768 =  2
      slidesToShow576 = 1
    }
    else if(this.mode  == 'big'){
      slidesToShow = 4
      slidesToShow1024 = 4
      slidesToShow768 =  2
      slidesToShow576 = 1
    }
    
    this.addonsConfig = {
      slidesToShow: slidesToShow,
      slidesToScroll: 1,
      speed: 500,
      dots: false,
      arrows: true,
      addonsListFiltered:false,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: slidesToShow1024,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: slidesToShow768,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: slidesToShow576,
            slidesToScroll: 1,
            rtl: this.currentLang === "ar",
          },
        },
      ],
      rtl: this.currentLang === "ar",
    };
  }

}
