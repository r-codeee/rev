import { HttpErrorResponse } from '@angular/common/http';
import { Component, inject, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { finalize, Subject, Subscription, takeUntil } from 'rxjs';
import { OtpComponent } from 'src/app/design-system/otp/otp.component';
import {
	ResendOtpRequest,
	VerifyOtpRequestWithMobile,
} from 'src/app/rm-otp/models/config';
import { RMOtpService } from 'src/app/rm-otp/services/rm-otp-service.service';
import { timerDown } from 'src/app/rm-otp/utilities/timer.utilities';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

@Component({
	selector: 'art-rm-sme-login-otp',
	templateUrl: './rm-sme-login-otp.component.html',
	styleUrls: ['./rm-sme-login-otp.component.scss'],
})
export class RMSMELoginOTPComponent implements OnInit {
	otpResponseData: any;
	$destroy: Subject<unknown> = new Subject();
	@ViewChild(OtpComponent) otpComRef: OtpComponent;
	otp = '';
	timerDisplay = '';
	isCounterEnabled = true;
	isResendEnabled = false;
	errorMessage = '';
	timerSubscription: Subscription = new Subscription();
	private readonly otpService = inject(RMOtpService);
	private readonly storage = inject(ARTStorageService);
	private readonly authService = inject(AuthService);
	readonly router = inject(Router);
	private readonly languageService = inject(RMLanguageService);
	currentLang = this.languageService.activeLang();
	config = this.otpService.config;
	timeToReset = this.config.timer;
	storedData = this.storage.GetValue(this.authService.STORAGE_KEY);
	referenceId: string;
	phoneNumber: string;
	resendOtpReq;
	ngOnInit(): void {
		this.referenceId = this.storedData.referenceId;
		this.phoneNumber = '******' + this.storedData.mobileTail;
		this.storedData = {
			...this.storedData,
			phoneNumber: this.storedData.mobile,
			transactionType: TransactionTypes.HEALTH_SME_ENDORSEMENT,
			identifier: this.referenceId,
		};
		this.storage.Setvalue(this.authService.STORAGE_KEY, this.storedData);
		this.initializeOTP();
	}

	initializeOTP() {
		this.timerSubscription.unsubscribe();
		this.timerSubscription = this.timerExpire(this.timeToReset);
		this.otpComRef.ngOtpInputRef.otpForm.enable();
	}

	timerExpire(timeToLive: number) {
		return timerDown(Math.round(timeToLive))
			.pipe(
				takeUntil(this.$destroy),
				finalize(() => {
					this.timerDisplay = '00:00';
					if (this.timerDisplay === '00:00') {
						this.isResendEnabled = true;
						this.otpComRef.ngOtpInputRef.otpForm.disable();
					}
				}),
			)
			.subscribe(timeInfo => {
				this.timerDisplay = timeInfo.time;
			});
	}

	changeOTP(value) {
		if (value.length === this.config.length) {
			this.errorMessage = '';
			let verifyOtpRequest = new VerifyOtpRequestWithMobile(
				this.storedData.mobile,
				this.storedData.otpId,
				this.storage.encryptData(value, this.storedData.otpId.toString()),
			);
			this.otpComRef.ngOtpInputRef.otpForm.disable();
			this.authService.verifyFeatureOTP(verifyOtpRequest).subscribe({
				next: (res: any) => {
					if (res) {
						if(this.storedData.bothEnabeled){
							this.storage.mergeIntoExistValue(
								this.authService.STORAGE_KEY,
								{
									healthFlowDcp: true,
									motorFlowNutirnos: true
								},
							);
							localStorage.setItem('token', res.data.token);
							localStorage.setItem('dcp-token', res.data.token);
						}else{
							this.storage.mergeIntoExistValue(
								this.authService.STORAGE_KEY,
								{
									healthFlowDcp: true,
									motorFlowNutirnos: false
								},
							);
						}
						
						sessionStorage.setItem("htoken", res.data.token);
						localStorage.setItem('LoggedIn', res.data.token);
						localStorage.setItem('updateMobileSuccess', 'true');
						localStorage.setItem('smeLogin', 'true');
						this.router.navigateByUrl('/my-space/sme');
					}
				},
				error: (error: HttpErrorResponse) => {
					if (error && error.error && error.error.error) {
						this.errorMessage = error.error.error.message;
					}
					this.otpComRef.ngOtpInputRef.otpForm.enable();
				},
			});
		}
	}

	resendOTP() {
		this.resendOtpReq = new ResendOtpRequest(
			this.storedData.mobileNumber,
			this.storedData.otpId,
			'health_endorsement',
			localStorage.getItem('selectedLang'),
		);
		this.authService.refreshToke().subscribe(() => {
			this.authService.resendFeatureOTP(this.resendOtpReq).subscribe(
				res => {
					if (res.meta && res.meta.status === 1) {
						this.storedData = {
							...this.storedData,
							otpId: res.data.otpId.toString(),
						};
						this.storage.Setvalue(
							this.authService.STORAGE_KEY,
							this.storedData,
						);
						this.isResendEnabled = false;
						this.initializeOTP();
					}
				},
				err => {
					this.errorCode(err);
				},
			);
		});
	}

	errorCode(err) {
		if (err.meta && err.meta.status === 0) {
			this.errorMessage = err && err.error.message;
		} else {
			this.errorMessage = err.message;
			if (this.errorMessage == 'You have exceeded max resend tries!') {
				this.resendOTP();
			}
		}
	}

	changePhoneNumber() {
		this.router.navigate(['/revamp-auth/auth-change-mobile-number']);
	}

	ngOnDestroy(): void {
		this.$destroy.next(null);
		this.$destroy.complete();
		this.$destroy.unsubscribe();
	}
}
