import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LOGIN } from '../shared/app.constant';
import { isLoaderNotReq } from '../utils/services/shared/loader-interceptor.service';

@Injectable()
export class RmAuthService {
	baseUrl = environment.baseUrl;
	private _loginMobileUrl = this.baseUrl + '/users/v2/login_mobile';
	userInfo = '';
	modalRefData;
	redirectUrl;
	constructor(private http: HttpClient) {}

	loginUserByMobile(user) {
		const headers = new HttpHeaders({
			language: localStorage.getItem('selectedLang'),
		});
		return this.http.post<any>(this._loginMobileUrl, user, { headers });
	}

	public loggedIn() {
		return !!localStorage.getItem('LoggedIn');
	}

	refreshUserToken() {
		return this.http.get<any>(this.baseUrl + "/refreshusertoken");
	  }

	refreshToke() {
		if (this.loggedIn()) {
			return this.refreshUserToken().pipe(
				map((token: any) => {
					// localStorage.setItem("token", token.token);
					localStorage.setItem('LoggedIn', token.token);
					return token;
				}),
			);
		}
		return this.guestLogin().pipe(
			map((token: any) => {
				localStorage.setItem('token', token.token);
				return token;
			}),
		);
	}

	guestLogin() {
		const guestUserData = {
		  username: "app",
		  password:
			LOGIN.GUEST_PASSWORD,
		  id: "guest",
		};
		return this.http.post<any>(this.baseUrl + "/guestlogin", guestUserData,{context: isLoaderNotReq()});
	  }

	public set setmodalRef(data) {
		this.modalRefData = data;
	}
	getmodalRef() {
		return this.modalRefData;
	}

	setUserInfo(user: string) {
		this.userInfo = user;
	}
	getUserInfo() {
		return this.userInfo;
	}
}
