import { Component, EventEmitter, inject, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import * as yup from 'yup';

@Component({
	selector: 'art-rm-update-login-mobile',
	templateUrl: './rm-update-login-mobile.component.html',
	styleUrls: ['./rm-update-login-mobile.component.scss'],
})
export class RmUpdateLoginMobileComponent extends BaseFormComponent<{
	phoneNumber: string;
}> {
	private readonly ValidationRulesService = inject(ArtValidationRulesService);
	values = {
		phoneNumber: '',
	};
	validationSchema = yup.object().shape({
		phoneNumber: this.ValidationRulesService.phoneNumberValidationRule(),
	});
	@Output() phoneNumberChanged: EventEmitter<string> = new EventEmitter();
	@Output() onCancelled: EventEmitter<void> = new EventEmitter();
	componentConfig: any = {
		isFooter: true,
		isRedirectEnabled: true,
		hasCancel: true,
		inputHasLabel: true,
		headerTitleCustomClasses: '',
		headerTitle: 'COMMON.PHONE.TITLE',
		headerDesc: 'COMMON.PHONE.DESCRIPTION',
		saveBtnText: 'COMMON.PHONE.SUBMIT',
	};
	private readonly storage = inject(ARTStorageService);
	private readonly authService = inject(AuthService);
	private router = inject(Router);
	customerData: any;
	sendRequest;
	errorMessage;
	currentLang = localStorage.getItem('selectedLang');
	isLoading = false;
	constructor(protected formBuilderService: ArtFormBuilderService) {
		super(formBuilderService);
		const { STORAGE_KEY } = this.authService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
	}

	onSubmit(values: { phoneNumber: string }) {
		this.isLoading = true;
		this.authService
			.checkMobileValidity(values.phoneNumber, this.customerData?.nationalId)
			.subscribe(
				res => {
					this.isLoading = false;
					if (res.meta?.statusCode === 200) {
						this.customerData = {
							...values,
							token: res.data.token,
							mobileTail: res.data.mobileTail,
						};
						localStorage.setItem('token', res.data.token);
						this.storage.Setvalue(
							this.authService.STORAGE_KEY,
							this.customerData,
						);
						this.router.navigateByUrl('/revamp-auth/individual-login-otp');
					} else if (res.meta?.statusCode == '001') {
						this.errorMessage = errMsgs['001'][this.currentLang];
					} else if (res.meta?.statusCode == '011') {
						this.errorMessage = errMsgs['011'][this.currentLang];
					}
				},
				err => {
					this.isLoading = false;
					this.errorMessage = err.error.message;
				},
			);
	}
}

const errMsgs = {
	'001': {
		en: 'Dear Customer, Apologies! The entered mobile number is not registered under your National/Iqama ID. Please provide a registered mobile number. For further assistance, contact AlRajhi Takaful customer care at 8001184444',
		ar: 'عزيزي العميل، نعتذر! رقم الجوال المُدخل غير مسجل تحت الهوية الوطنية/ الإقامة الخاصة بك. يُرجى تزويدنا برقم جوال مُسجل. للحصول على مساعدة إضافية، يُرجى التواصل مع خدمة العملاء في التكافل الراجحي على الرقم 8001184444',
	},
	'011': {
		en: 'Dear customer, we are unable to log into your account at the moment due to technical issue. Please try again later.',
		ar: 'عزيزي العميل، لا يمكننا تسجيل الدخول إلى حسابك في الوقت الحالي بسبب مشكلة فنية. يرجى المحاولة مرة أخرى بعد مرور بعض الوقت.',
	}
};