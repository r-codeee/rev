import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/utils/services/auth/auth.service';

@Component({
	selector: 'art-rm-login-option',
	templateUrl: './rm-login-option.component.html',
	styleUrls: ['./rm-login-option.component.scss'],
})
export class RMLoginOptionComponent {
	constructor(private router: Router, private authService: AuthService) {
		this.authService.logoutUser(false);
		this.deleteAllCookies()
	}

	deleteAllCookies() {
		// connect.b2c.sid
		document.cookie.split(";").forEach(function(c) { document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); });
	}

	loginAsIndividual() {
		this.router.navigateByUrl('/revamp-auth/login-individual');
	}

	loginAsSME() {
		this.router.navigateByUrl('/revamp-auth/login-sme');
	}
}
