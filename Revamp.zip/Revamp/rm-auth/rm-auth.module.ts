import { NgModule } from '@angular/core';
import { RMAuthRoutingModule } from './rm-auth-routing.module';
import { CommonModule } from '@angular/common';
import { RMOtpModule } from '../rm-otp/rm-otp.module';
import { RMLoginOptionComponent } from './rm-login-option/rm-login-option.component';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from '../design-system/icon/icon.component';
import { RMAccountFormContainerComponent } from '../design-system/rm-account-form-container/rm-account-form-container.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BasicInputComponent } from '../design-system/basic-input/basic-input.component';
import { ArtButtonComponent } from '../design-system/art-button/art-button.component';
import { PhoneBasicInputComponent } from '../design-system/phone-basic-input/phone-basic-input.component';
import { RmDateInputComponent } from '../design-system/rm-date-input/rm-date-input.component';
import { RMLoginIndividualFormComponent } from './rm-login-individual-form/rm-login-individual-form.component';
import { RMLoginSMEFormComponent } from './rm-login-sme-form/rm-login-sme-form.component';
import { RMSignupIndividualFormComponent } from './rm-signup-individual-form/rm-signup-individual-form.component';
import { OtpComponent } from "../design-system/otp/otp.component";
import { RMSMELoginOTPComponent } from './rm-sme-login-otp/rm-sme-login-otp.component';
import { RmIndividualLoginOTPComponent } from './rm-individual-login-otp/rm-individual-login-otp.component';
import { RMChangePhoneNumberComponent } from '../rm-change-phone-number/rm-change-phone-number.component';
import { RmAuthChangeMobileNumberComponent } from './rm-auth-change-mobile-number/rm-auth-change-mobile-number.component';
import { RmUpdateLoginMobileComponent } from './rm-update-login-mobile/rm-update-login-mobile.component';
import { RmMotorSmeLoginOtpComponent } from './rm-motor-sme-login-otp/rm-motor-sme-login-otp.component';


@NgModule({
	declarations: [
		RMLoginOptionComponent,
		RMLoginIndividualFormComponent,
		RMLoginSMEFormComponent,
		RMSignupIndividualFormComponent,
		RMSMELoginOTPComponent,
		RmIndividualLoginOTPComponent,
        RmAuthChangeMobileNumberComponent,
        RmUpdateLoginMobileComponent,
        RmMotorSmeLoginOtpComponent
	],
	imports: [
    CommonModule,
    RMAuthRoutingModule,
    TranslateModule,
    ReactiveFormsModule,
    IconComponent,
    RMOtpModule,
    BasicInputComponent,
    ArtButtonComponent,
    PhoneBasicInputComponent,
    RmDateInputComponent,
    RMAccountFormContainerComponent,
    OtpComponent,
    RMChangePhoneNumberComponent
],
})
export class RmAuthModule {}
