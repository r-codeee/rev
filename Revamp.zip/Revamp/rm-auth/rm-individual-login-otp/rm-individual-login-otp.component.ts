import { AfterViewInit, Component, inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { finalize, Subject, Subscription, takeUntil } from 'rxjs';
import { timerDown } from 'src/app/rm-otp/utilities/timer.utilities';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ProfileService } from 'src/app/utils/services/auth/profile.service';
import { RMOtpService } from 'src/app/rm-otp/services/rm-otp-service.service';
import { OtpComponent } from 'src/app/design-system/otp/otp.component';
import { TranslateService } from '@ngx-translate/core';

@Component({
	selector: 'art-individual-login-otp',
	templateUrl: './rm-individual-login-otp.component.html',
	styleUrls: ['./rm-individual-login-otp.component.scss'],
})
export class RmIndividualLoginOTPComponent implements OnInit, AfterViewInit, OnDestroy {
	@ViewChild(OtpComponent) otpComRef: OtpComponent;
	isCounterEnabled: boolean = true;
	isResendEnabled: boolean = false;
	timerDisplay = '00:00';
	errorMessage = '';
	phoneNumber = '';
	$destroy: Subject<unknown> = new Subject();
	timerSubscription: Subscription = new Subscription();
	private readonly otpService = inject(RMOtpService);
	private readonly storage = inject(ARTStorageService);
	private readonly _authService = inject(AuthService);
	private readonly languageService = inject(RMLanguageService);
	private readonly _profileService = inject(ProfileService);
	private readonly translate = inject(TranslateService);
	private readonly router = inject(Router);
	config = this.otpService.config;
	timeToReset = this.config.timer;
	errMessage;
	currentLang = this.languageService.activeLang();
	customerData: any = {};
	encodeValue: any;
	constructor() {
		this.customerData = this.storage.GetValue(this._authService.STORAGE_KEY)
			? this.storage.GetValue(this._authService.STORAGE_KEY)
			: {};
		this.phoneNumber = '******' + this.customerData.mobileTail;
	}

	ngOnInit(): void {
		this.config.length = 4;
		this.errMessage = this.translate.instant('COMMON.OTP_ERROR')
	}

	ngAfterViewInit(): void {
		this.initializeOTP();	
	}

	initializeOTP() {
		this.timerSubscription.unsubscribe();
		this.timerSubscription = this.timerExpire(this.timeToReset);
		this.otpComRef.ngOtpInputRef.otpForm.enable();
	}

	timerExpire(timeToLive: number) {
		return timerDown(Math.round(timeToLive))
			.pipe(
				takeUntil(this.$destroy),
				finalize(() => {
					this.timerDisplay = '00:00';
					if (this.timerDisplay === '00:00') {
						this.isResendEnabled = true;
						this.otpComRef.ngOtpInputRef.otpForm.disable();
					}
				}),
			)
			.subscribe(timeInfo => {
				this.timerDisplay = timeInfo.time;
			});
	}

	changeOTP(otp) {
		if (otp.length === this.config.length) {
			let encrOTP = this.storage.encryptData(
				otp,
				this.customerData.mobileTail.toString(),
			);
			let verifyOtpRequest = {
				otp: encrOTP,
				otpId: this.customerData.mobileTail,
			};
			this.errorMessage = '';
			this.otpComRef.ngOtpInputRef.otpForm.disable();
			this._authService.otpVerification(verifyOtpRequest).subscribe({
				next: (res: any) => {
					if (res) {
						localStorage.setItem('token', res.token);
						localStorage.setItem('LoggedIn', res.token);
						localStorage.setItem('dcp-token', res.token);
						localStorage.setItem('individualLogin', 'true');
						localStorage.setItem('updateMobileSuccess', 'true');
						this._profileService.getProfileLang(this.currentLang).subscribe(
							res => {
								this._authService.idValue = res.idValue;
								localStorage.setItem('user', JSON.stringify(res));
								this._authService.setUserInfo(JSON.stringify(res));
								this._authService.currentUserSubject.next(res);
								this.router.navigateByUrl(this.customerData.redirectUrl);
								this._authService.redirectUrl = null;
							},
							err => {
								console.log(err);
								this.otpComRef.ngOtpInputRef.otpForm.enable();
							},
						);
					}
				},
				error: (error: HttpErrorResponse) => {
					if (error && error.error) {
						this.errorMessage = this.errMessage;
					}
					this.otpComRef.ngOtpInputRef.otpForm.enable();
				},
			});
		}
	}

	changePhoneNumber() {
		this.router.navigate(['/revamp-auth/auth-change-mobile-number']);
	}

	resendOTP() {
		let body = {};
		this._authService.resendUserOtp(body).subscribe(
			res => {
				this.isResendEnabled = false;
				this.initializeOTP();
			},
			err => {
				console.log('err', err);
			},
		);
	}

	ngOnDestroy(): void {
		this.$destroy.next(null);
		this.$destroy.complete();
		this.$destroy.unsubscribe();
	}
}
