import {
	AfterViewInit,
	Component,
	EventEmitter,
	inject,
	Input,
	OnChanges,
	OnInit,
	Output,
	ViewChild,
} from '@angular/core';
import { Router } from '@angular/router';
import { finalize, Subject, Subscription, switchMap, takeUntil } from 'rxjs';
import { RMOtpService } from 'src/app/rm-otp/services/rm-otp-service.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { CommonMyspaceService } from 'src/app/rm-my-space/common/services/common-myspace.service';
import { timerDown } from 'src/app/rm-otp/utilities/timer.utilities';
import { AuthService } from 'src/app/utils/services/auth/auth.service';

@Component({
	selector: 'art-rm-motor-sme-login-otp',
	templateUrl: './rm-motor-sme-login-otp.component.html',
	styleUrls: ['./rm-motor-sme-login-otp.component.scss'],
})
export class RmMotorSmeLoginOtpComponent
	implements OnInit, AfterViewInit, OnChanges
{
	otpResponseData: any;
	$destroy: Subject<unknown> = new Subject();
	otp = '';
	timerDisplay = '';
	enableResend = false;
	@Input() invalidOTP = false;
	@Input() CustomSendPayload;
	@Input() CustomReSendPayload;
	@Input() VerifyOtpRequestByMobile = false;
	@Input() isFirstOtp = false;
	timeToReset = 300; // in seconds;
	errorMessage = '';
	timerSubscription: Subscription = new Subscription();
	@Input() redirectUrl; // TODO: will be changed according to requirements.
	@ViewChild('ngOtpInput') ngOtpInputRef: any;
	@Input() componentConfig: RmOTPComponentConfigI = {
		isFooter: true,
		isChangePhoneEnabled: false,
		isRedirectEnabled: true,
		isResendEnabled: true,
		isCounterEnabled: true,
		headerTitleCustomClasses: '',
	};
	@Output() otpValue: EventEmitter<string> = new EventEmitter();
	private readonly otpService = inject(RMOtpService);
	private readonly storage = inject(ARTStorageService);
	private readonly individualMotorService = inject(IndividualMotorService);
	private readonly languageService = inject(LanguageService);
	private readonly commonMyspaceService = inject(CommonMyspaceService);
	private readonly authService = inject(AuthService);
	readonly router = inject(Router);
	config = this.otpService.config;
	storedData = this.storage.GetValue(this.commonMyspaceService.STORAGE_KEY);
	currentLang = this.languageService.currentLang;
	txId: string;
	hiddenPhoneNo: string;
	phoneNo: string;

	ngOnInit(): void {
		// this.txId = this.storedData?.txId;
		this.config.length = 6;
		this.sendOTP();
		console.log(this.storedData);
	}

	ngAfterViewInit(): void {
		this.ngOtpInputRef?.otpForm.enable();
		console.log(this.storedData);
	}

	sendOTP() {
		this.commonMyspaceService.sedOTP().subscribe({
			next: res => {
				this.initializeOTP();
				this.txId = res.txId;

				this.storage.mergeIntoExistValue(
					this.commonMyspaceService.STORAGE_KEY,
					{
						txId_otp: res.txId,
						phone_no_otp: res.phone_no,
					},
				);
			},
			error: err => {
				console.log(err);
			},
		});
	}

	ngOnChanges(): void {
		this.config.length = 6;
		this.sendOTP();
	}
	initializeOTP() {
		this.otpService.config.length = 6;
		this.timerSubscription.unsubscribe();
		this.timerSubscription = this.timerExpire(this.timeToReset);
		this.enableResend = false;
	}

	timerExpire(timeToLive: number) {
		return timerDown(Math.round(timeToLive))
			.pipe(
				takeUntil(this.$destroy),
				finalize(() => {
					this.timerDisplay = '00:00';
					if (this.timerDisplay === '00:00') {
						this.ngOtpInputRef.otpForm.disable();
					}
					this.enableResend = true;
				}),
			)
			.subscribe(timeInfo => {
				this.timerDisplay = timeInfo.time;
			});
	}

	changeOTP(val: any) {
		if (val.length === this.config.length) {
			this.commonMyspaceService
				.verifyOTP({ TxId: this.txId, value: val })
				.subscribe(
					res => {
						if (res && res.status) {
							this.storage.mergeIntoExistValue(this.authService.STORAGE_KEY, {
								healthFlowDcp: false,
								motorFlowNutirnos: true,
							});
							localStorage.setItem('LoggedIn', 'true');
							localStorage.setItem('smeLogin', 'true');
							this.router.navigateByUrl('/my-space/sme');
							// localStorage.setItem('LoggedIn', res.data.token);
						} else {
							this.errorMessage =
								this.currentLang === 'en'
									? 'Wrong OTP entered.Please enter correct OTP'
									: 'الرمز المدخل غير صحيح، الرجاء ادخال الرمز الصحيح.';
						}
					},
					error => {
						this.ngOtpInputRef?.otpForm.reset();
						this.errorMessage =
							this.currentLang === 'en'
								? 'Wrong OTP entered.Please enter correct OTP'
								: 'الرمز المدخل غير صحيح، الرجاء ادخال الرمز الصحيح.';
						this.invalidOTP = true;
					},
				);
		}
	}

	ngOnDestroy(): void {
		this.$destroy.next(null);
		this.$destroy.complete();
		this.$destroy.unsubscribe();
	}
}

export interface RmOTPComponentConfigI {
	isFooter: boolean;
	isChangePhoneEnabled: boolean;
	isRedirectEnabled: boolean;
	isResendEnabled: boolean;
	isCounterEnabled: boolean;
	headerTitleCustomClasses: string;
}
