import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RMLoginOptionComponent } from './rm-login-option/rm-login-option.component';
import { RMLoginIndividualFormComponent } from './rm-login-individual-form/rm-login-individual-form.component';
import { RMLoginSMEFormComponent } from './rm-login-sme-form/rm-login-sme-form.component';
import { RMSignupIndividualFormComponent } from './rm-signup-individual-form/rm-signup-individual-form.component';
import { RMSMELoginOTPComponent } from './rm-sme-login-otp/rm-sme-login-otp.component';
import { RmIndividualLoginOTPComponent } from './rm-individual-login-otp/rm-individual-login-otp.component';
import { RmAuthChangeMobileNumberComponent } from './rm-auth-change-mobile-number/rm-auth-change-mobile-number.component';
import { RmUpdateLoginMobileComponent } from './rm-update-login-mobile/rm-update-login-mobile.component';
import { RmMotorSmeLoginOtpComponent } from './rm-motor-sme-login-otp/rm-motor-sme-login-otp.component';
const routes: Routes = [
	{
		path: '',
		component: RMLoginOptionComponent,
		data: { showHeader: true, showFooter: false },
	},
	{
		path: 'login-individual',
		component: RMLoginIndividualFormComponent,
		data: { showHeader: true, showFooter: false },
	},

	{
		path: 'login-sme',
		component: RMLoginSMEFormComponent,
		data: { showHeader: true, showFooter: false },
	},
	{
		path: 'signup-individual',
		component: RMSignupIndividualFormComponent,
		data: { showHeader: true, showFooter: false },
	},
	{
		path: 'individual-login-otp',
		component: RmIndividualLoginOTPComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'sme-login-otp',
		component: RMSMELoginOTPComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'sme-login-motr-otp',
		component: RmMotorSmeLoginOtpComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'auth-change-mobile-number',
		component: RmAuthChangeMobileNumberComponent,
		data: { showHeader: true, showFooter: false },
	},
	{
		path: 'update-login-mobile',
		component: RmUpdateLoginMobileComponent,
		data: { showHeader: true, showFooter: false },
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class RMAuthRoutingModule {}
