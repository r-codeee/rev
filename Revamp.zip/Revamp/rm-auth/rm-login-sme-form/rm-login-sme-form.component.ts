import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { ArtLoginSignupFormValidationSchemaService } from 'src/app/rm-shared-components/services/art-get-login-signup-form-validation-schema.service';
import { GetSMELoginValues } from 'src/app/rm-shared-components/types/GetLoginFormValues';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { ResendOtpRequest, SendOtpRequest } from 'src/app/auth/otp-common-verification/otp-request.model';
import { CommonMyspaceService } from 'src/app/rm-my-space/common/services/common-myspace.service';
import { delay, switchMap, tap } from 'rxjs';

@Component({
	selector: 'art-rm-login-sme-form',
	templateUrl: './rm-login-sme-form.component.html',
	styleUrls: ['./rm-login-sme-form.component.scss'],
})
export class RMLoginSMEFormComponent extends BaseFormComponent<GetSMELoginValues> {
	values: GetSMELoginValues = {} as GetSMELoginValues;
	validationSchema = this.loginSignupFormValidation.createSMESignupSchema();
	nationalIdSuffixComponent = IconComponent;
	nationalIdSuffixComponentInputs = { icon: 'nationalId', size: 'xs' };
	otpId;
	mobileNumber;
	errorMessage = '';
	isLoading = false;
	isHealthPolcies = false;
	isMotorPolcies = false;
	customerData;
	currentLang = localStorage.getItem('selectedItem');
	resendOtpReq;
	sendRequest;
	healthError;
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private loginSignupFormValidation: ArtLoginSignupFormValidationSchemaService,
		private router: Router,
		private authService: AuthService,
		private storage: ARTStorageService,
		private commonMyspaceService: CommonMyspaceService,
	) {
		super(formBuilderService);
	}

	onSubmit(values: GetSMELoginValues) {
		this.isLoading = true;
		this.errorMessage = '';
		this.authService.loginSME(values).subscribe(
			res => {
				this.isLoading = false;
				const data = res.data;
				if (data) {
					this.otpId = data.otpId;
					localStorage.setItem('HEtoken', 'Bearer' + ' ' + data.token);
					this.storage.Setvalue('referenceId',data.referenceId)
					this.mobileNumber = data.mobileNumber;
					let mobileTail = this.mobileNumber.toString();
                    mobileTail = mobileTail.substr(mobileTail.length - 4);
					this.customerData = {
						...values,
						token: data.token,
						HEtoken: 'Bearer' + ' ' + data.token,
						referenceId: data.referenceId,
						otpId: this.otpId,
						mobile: this.mobileNumber,
						mobileTail: mobileTail
					};
					this.storage.Setvalue(
						this.authService.STORAGE_KEY,
						this.customerData,
					);
					// "message": "No active policies found for this company. Please ensure that the company has active policies in the ESKA database."
					this.isHealthPolcies = true;
					this.getMotorStatus(values)
					
				}
			},
			error => {
				this.isHealthPolcies = false;
				this.healthError = error;
				console.log(error);
				this.getMotorStatus(values)
			},
		);
	}
	getMotorStatus(values){
		this.commonMyspaceService.generateAuthCode().subscribe((res) => {
				let authorizationCode = res.Authorization_code;
				if (authorizationCode) {
					this.commonMyspaceService
					.generateAccessToken(authorizationCode)
					.subscribe((res) => {
					this.authService.setPaymentAuthToken(
						"Bearer" + " " + res.Access_token
					);
					// refreshToke
					this.authService.guestLogin()
						.pipe(
						tap((res: any) => {
						console.log(res);
						localStorage.removeItem('dcp-token');
						localStorage.setItem('dcp-token', res.token);
						}),
						delay(1200),
						switchMap(() => this.commonMyspaceService.deleteUserInfo()),
						switchMap(() => this.commonMyspaceService.getCacheData()),
						)
						.subscribe((res) => {
						let satatusCheckBody = {
						"customer_id": values['unifiedNo'],
						}
						this.commonMyspaceService.statusUpdate(satatusCheckBody).subscribe((res) => {
						if (res.status) {
							this.isLoading = false;
							this.isMotorPolcies = true;
							this.checkScenario()
							// this.commonMyspaceService.getUserInfo().subscribe((res) => {
								
							// })
						} else{
							this.isLoading = false;
							this.isMotorPolcies = false;
							this.checkScenario()
						}
					}, err => {
						this.isLoading = false;
					});
			  });
			});
		}
			
		})
	}
	checkScenario(){
		if(this.isHealthPolcies && !this.isMotorPolcies){
			this.healthFlow()
		}else if(!this.isHealthPolcies && this.isMotorPolcies){
			this.motorFlow()
		}else if(this.isHealthPolcies && this.isMotorPolcies){
			this.healthFlow(true)
		}else{
			if(!this.isHealthPolcies && !this.isMotorPolcies){
				// this.errorCode(this.healthError)
				this.errorCode(this.healthError)
			}
			
		}
	}
	motorFlow(){
		this.router.navigateByUrl('revamp-auth/sme-login-motr-otp');
	}
	healthFlow(bothMode?){
		this.sendRequest = new SendOtpRequest(
			this.mobileNumber,
			this.storage.GetValue('referenceId').toString(),
			"requestId",
			"health_endorsement",
			localStorage.getItem("selectedLang")
		);
		if (this.otpId == 0) {
			this.sendOTP(bothMode);
		} else {
			this.resendOTP(bothMode);
		}
	}

	sendOTP(bothMode?) {
		this.errorMessage = '';
		this.authService.sendFeatureOTP(this.sendRequest).subscribe(
			res => {
				if (res.data) {
					this.customerData = {
						...this.customerData,
						otpId: res.data.otpId.toString(),
						bothEnabeled:false // both is set to false always as login is not implemented : after implmented need to set to bothEnabeled:bothMode
					};
					this.storage.Setvalue(
						this.authService.STORAGE_KEY,
						this.customerData,
					);
					this.router.navigateByUrl('/revamp-auth/sme-login-otp');
				}
			},
			err => {
				this.errorCode(err);
			},
		);
	}

	resendOTP(bothMode?) {
		this.resendOtpReq = new ResendOtpRequest(
			this.mobileNumber,
			this.otpId,
			'health_endorsement',
			localStorage.getItem('selectedLang'),
		);
		this.authService.refreshToke().subscribe(
			() => {
				this.authService.resendFeatureOTP(this.resendOtpReq).subscribe(
					res => {
						if (res.meta && res.meta.status === 1) {
							this.customerData = {
								...this.customerData,
								otpId: res.data.otpId.toString(),
								bothEnabeled:bothMode
							};
							this.storage.Setvalue(
								this.authService.STORAGE_KEY,
								this.customerData,
							);
							this.router.navigateByUrl('/revamp-auth/sme-login-otp');
						}
					},
					err => {
						this.errorCode(err);
					},
				);
			},
			error => {
				this.errorMessage = error.statusText;
			},
		);
	}

	errorCode(err) {
		if (err.meta && err.meta.status === 0) {
			this.errorMessage = err && err.error.message;
		} else {
			this.errorMessage = err.message;
			if (this.errorMessage == 'You have exceeded max resend tries!') {
				this.resendOTP();
			}
		}
	}

	registerNow() {
		this.router.navigateByUrl('revamp-auth/signup-sme');
	}
}
