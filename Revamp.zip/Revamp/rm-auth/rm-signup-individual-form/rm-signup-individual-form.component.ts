import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { ArtLoginSignupFormValidationSchemaService } from 'src/app/rm-shared-components/services/art-get-login-signup-form-validation-schema.service';
import { GetIndividualSignupValues } from 'src/app/rm-shared-components/types/GetSignupFormValues';
import { PrivacyService } from 'src/app/shared-components/privacy/privacy.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';

@Component({
	selector: 'art-rm-signup-individual-form',
	templateUrl: './rm-signup-individual-form.component.html',
	styleUrls: ['./rm-signup-individual-form.component.scss'],
})
export class RMSignupIndividualFormComponent
	extends BaseFormComponent<GetIndividualSignupValues>
	implements AfterViewInit
{
	values: GetIndividualSignupValues = {
		idValue: '',
		dateOfBirth: '',
		mobile: '',
		email: '',
	};
	validationSchema =
		this.loginSingupFormValidationSchemaService.createIndividualSignupSchema();
	nationalIdSuffixComponent = IconComponent;
	nationalIdSuffixComponentInputs = { icon: 'nationalId', size: 'xs' };
	currentLang = localStorage.getItem('selectedLang');
	privacy;
	privacyData;
	serverErrMsg = '';
	isLoading = false;
	customerData;
	IconSuffixComponent = IconComponent;
	emailSuffixComponentInputs = {
		icon: 'fa-thin fa-envelope',
		size: 'xs',
		customClasses: 'color-main-dark-gray',
	};
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private loginSingupFormValidationSchemaService: ArtLoginSignupFormValidationSchemaService,
		private router: Router,
		private authService: AuthService,
		private privacyService: PrivacyService,
		private storage: ARTStorageService,
	) {
		super(formBuilderService);
		this.customerData = this.storage.GetValue(this.authService.STORAGE_KEY)
			? this.storage.GetValue(this.authService.STORAGE_KEY)
			: {};
	}

	ngAfterViewInit(): void {
		this.loadCustomerData();
	}

	loadCustomerData() {
		this.customerData =
			this.storage.GetValue(this.authService.STORAGE_KEY) || {};
		this.userFormvalues();
	}
	userFormvalues() {
		this.form.patchValue({ idValue: this.customerData?.nationalId || '' });
		this.form.patchValue({ mobile: this.customerData.mobile || '' });
	}

	onSubmit(values: GetIndividualSignupValues) {
		this.isLoading = true;
		values['dateOfBirth'] = moment(values.dateOfBirth)
			.format('DD-MM-YYYY')
			.toString();
		values['nationality'] = this.currentLang === 'en' ? 'IN' : 'SA';
		values['privacyPolicyConsent'] = true;
		this.authService.refreshToke().subscribe(
			() => {
				this.getPrivacyVersion(values.idValue);
				this.getPrivacyContent();

				this.authService.registerUser(values).subscribe(
					res => {
						this.isLoading = false;
						if (res.meta?.statusCode == 200) {
							localStorage.setItem('token', res.data.token);
							localStorage.setItem('registeration', 'true');
							let mobileTail = values.mobile.toString();
							mobileTail = mobileTail.substr(mobileTail.length - 4);
							let redirectUrl = '/my-space/individual';
							this.customerData = {
								...values,
								mobileTail: mobileTail,
								token: res.data.token,
								redirectUrl,
							};
							this.storage.Setvalue(
								this.authService.STORAGE_KEY,
								this.customerData,
							);
							this.router.navigateByUrl('/revamp-auth/individual-login-otp');
						} else if (res.meta?.statusCode == '001') {
							this.serverErrMsg = errMsgs['001'][this.currentLang];
						} else if (res.meta?.statusCode == '002') {
							this.serverErrMsg = errMsgs['002'][this.currentLang];
						} else if (res.meta?.statusCode == '004') {
							this.serverErrMsg = errMsgs['004'][this.currentLang];
						} else if (res.meta?.statusCode == '006') {
							this.serverErrMsg = errMsgs['006'][this.currentLang];
						} else if (res.meta?.statusCode == '009') {
							this.serverErrMsg = errMsgs['009'][this.currentLang];
						} else if (res.meta?.statusCode == '010') {
							this.serverErrMsg = errMsgs['010'][this.currentLang];
						} else if (res.meta?.statusCode == '005') {
							this.serverErrMsg = errMsgs['005'][this.currentLang];
						}
					},
					err => {
						this.isLoading = false;
						if (err.error) {
							this.serverErrMsg = err.error.error.message;
						}
						if (err.error) {
							this.serverErrMsg = err.error.message;
						}
					},
				);
			},
			err => {
				this.isLoading = false;
			},
		);
	}

	LoginNow() {
		this.router.navigateByUrl('/revamp-auth/login-individual');
	}

	public getPrivacyVersion(id) {
		this.authService.getVeriosnDetails(id).subscribe((data: privacyData) => {
			this.privacyData = data;
		});
	}

	public getPrivacyContent() {
		this.privacyService
			.GetPrivacyData(this.currentLang)
			.subscribe((data: Privacy) => {
				this.privacy = data;
			});
	}
}

export class privacyData {
	encrypted_national_id: string;
	expiry_date: string;
	is_ppc_expired: boolean;
	ppc_version: string;
}

export interface Privacy {
	Header: string;
	Title: string;
	Text: string;
	Version: string;
}
const errMsgs = {
	'002': {
		en: 'Exceeded number of login retries',
		ar: 'كلمة المرور التي أدخلتها غير صحيحة ، يرجى المحاولة مرة أخرى',
	},
	'004': {
		en: 'Dear Customer, we are unable to sign you up at the moment due to a technical issue. Please try again later.',
		ar: 'عزيزي العميل ، لا يمكننا تسجيلك في هذه اللحظة بسبب مشكلة فنية. يرجى المحاولة مرة أخرى بعد مرور بعض الوقت.',
	},
	'006': {
		en: 'This NationalID is already registered',
		ar: 'رقم الهوية مسجل من قبل',
	},
	'007': {
		en: 'Incorrect credentials/User does not Exist when trying to login with mobile',
		ar: 'بيانات الدخول غير صحيحة او المستخدم غير موجود عند محاولة تسجيل الدخول باستخدام الجوال',
	},
	'009': {
		en: 'This Mobile number is already registered',
		ar: 'رقم الجوال مسجل من قبل',
	},
	'010': {
		en: 'This Email is already registered',
		ar: 'البريد الاليكتروني مسجل من قبل',
	},
	'001': {
		en: 'Dear Customer, Apologies! The entered mobile number is not registered under your National/Iqama ID. Please provide a registered mobile number. For further assistance, contact AlRajhi Takaful customer care at 8001184444',
		ar: 'عزيزي العميل، نعتذر! رقم الجوال المُدخل غير مسجل تحت الهوية الوطنية/ الإقامة الخاصة بك. يُرجى تزويدنا برقم جوال مُسجل. للحصول على مساعدة إضافية، يُرجى التواصل مع خدمة العملاء في التكافل الراجحي على الرقم 8001184444',
	},
	'005': {
		en: 'Dear Customer, the DOB you entered does not match your National/Iqama ID. Please enter the DOB matches your National/Iqama ID',
		ar: 'عزيزنا العميل، لقد قمت بإدخال تاريخ ميلاد غير متطابق مع رقم الهوية، يرجى التحقق من صحة تاريخ الميلاد.',
	},
};
