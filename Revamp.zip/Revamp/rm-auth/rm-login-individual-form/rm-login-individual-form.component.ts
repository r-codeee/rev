import { Component } from '@angular/core';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { ArtLoginSignupFormValidationSchemaService } from 'src/app/rm-shared-components/services/art-get-login-signup-form-validation-schema.service';
import { GetIndividualLoginValues } from 'src/app/rm-shared-components/types/GetLoginFormValues';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { forkJoin, take } from 'rxjs';
import { PrivacyService } from 'src/app/shared-components/privacy/privacy.service';
import { NewPrivacyPopupComponent } from 'src/app/shared-components/new-privacy-popup/new-privacy-popup.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
	selector: 'art-rm-login-individual-form',
	templateUrl: './rm-login-individual-form.component.html',
	styleUrls: ['./rm-login-individual-form.component.scss'],
})
export class RMLoginIndividualFormComponent extends BaseFormComponent<GetIndividualLoginValues> {
	values: GetIndividualLoginValues = {} as GetIndividualLoginValues;
	validationSchema =
		this.loginSignupFormValidation.createIndividualLoginSchema();
	nationalIdSuffixComponent = IconComponent;
	nationalIdSuffixComponentInputs = { icon: 'nationalId', size: 'xs' };
	customerData;
	errorMessage;
	currentLang = localStorage.getItem('selectedLang');
	isLoading = false;
	privacyData;
	privacy;
	statusCode;
	showClickHere = '';
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private loginSignupFormValidation: ArtLoginSignupFormValidationSchemaService,
		private router: Router,
		private storage: ARTStorageService,
		private authService: AuthService,
		private privacyService: PrivacyService,
		private dialog: MatDialog,
	) {
		super(formBuilderService);
	}

	onSubmit(values: GetIndividualLoginValues) {
		this.isLoading = true;
		this.errorMessage = '';
		values.nationality = this.currentLang === 'en' ? 'IN' : 'SA';
		values.privacyPolicyConsent = true;
		this.customerData = {
			...values,
		};
		this.storage.Setvalue(this.authService.STORAGE_KEY, this.customerData);
		this.authService.guestLogin().subscribe(
			guestLoginResponse => {
				localStorage.setItem('token', guestLoginResponse.token);
				const getPrivacyVersion = this.getPrivacyVersion(
					values?.nationalId,
				).pipe(take(1));
				const privacyContent = this.getPrivacyContent().pipe(take(1));

				forkJoin([getPrivacyVersion, privacyContent]).subscribe(
					([res, res1]) => {
						this.privacyData = res;
						this.privacy = res1;
						if (this.privacyData && this.privacy) {
							if (
								Number(this.privacyData?.ppc_version) === this.privacy?.Version
							) {
								this.authService.refreshToke().subscribe(
									() => {
										this.authService.loginUserByMobile(values).subscribe({
											next: res => {
												this.isLoading = false;
												this.loginAPISuccessResponseMapping(res, values);
											},
											error: err => {
												this.isLoading = false;
											},
										});
									},
									err => {
										console.log('error in login', err);
									},
								);
							} else {
								const modalRef = this.dialog.open(NewPrivacyPopupComponent, {
									disableClose: true,
									data: {
										content: this.privacy,
										source: 'login',
										id: this.privacyData?.encrypted_national_id,
									},
								});
								modalRef.afterClosed().subscribe((confirmed: any) => {
									if (confirmed == true) {
										this.authService.refreshToke().subscribe(() => {
											this.authService.loginUserByMobile(values).subscribe(
												res => {
													this.loginAPISuccessResponseMapping(res, values);
												},
												err => {
													if (err) {
														this.errorMessage = err.error.Error;
													}
													if (err.error) {
														this.errorMessage = err.error.error.message;
													}
												},
											);
										});
									} else {
										this.router.navigateByUrl('');
										//   this.btnClicked = false;
										//   this.hasServerErr2 = false;
										//   this.privacyNotAccepted = true;
									}
								});
							}
						}
					},
				);
			},
			err => {},
		);
	}

	loginAPISuccessResponseMapping(res, values) {
		if (res.meta?.statusCode === '001') {
			this.errorMessage = errMsgs['001'][this.currentLang];
		} else if (res.meta?.statusCode === '002') {
			this.errorMessage = errMsgs['002'][this.currentLang];
		} else if (res.meta?.statusCode === '004') {
			this.errorMessage = errMsgs['004'][this.currentLang];
		} else if (res.meta?.statusCode === '006') {
			this.errorMessage = errMsgs['006'][this.currentLang];
		} else if (res.meta?.statusCode === '009') {
			this.errorMessage = errMsgs['009'][this.currentLang];
		} else if (res.meta?.statusCode === '010') {
			this.errorMessage = errMsgs['010'][this.currentLang];
		} else if (res.meta?.statusCode === '005') {
			this.errorMessage = errMsgs['005'][this.currentLang];
		} else if (res.meta?.statusCode === '011') {
			this.errorMessage = errMsgs['011'][this.currentLang];
		} else if (res.meta?.statusCode === '007') {
			this.registerNow();
		} else if (res.meta?.statusCode === '012') {
			this.statusCode = res.meta?.statusCode;
			this.showClickHere = errMsgs['012'][this.currentLang];
		} else if (res.meta?.statusCode === 200) {
			// @TODO Commented for temprary for testing ans server issues by MANOJ
			let redirectUrl = '/my-space/individual';
			// let redirectUrl = `${this.currentLang}`;
			if (this.authService.loginRedirect()) {
				redirectUrl = localStorage.getItem('loginRedirect');
			}
			this.customerData = {
				...values,
				token: res.data.token,
				mobileTail: res.data.mobileTail,
				redirectUrl,
			};
			localStorage.setItem('token', res.data.token);
			this.storage.Setvalue(this.authService.STORAGE_KEY, this.customerData);
			this.isLoading = false;
			this.router.navigateByUrl('/revamp-auth/individual-login-otp');
		}
	}

	registerNow() {
		this.router.navigateByUrl('revamp-auth/signup-individual');
	}

	getPrivacyVersion(id) {
		return this.authService.getVeriosnDetails(id);
	}

	getPrivacyContent() {
		return this.privacyService.GetPrivacyData(this.currentLang);
	}

	getMobileNumberPopup() {
		this.router.navigateByUrl('/revamp-auth/update-login-mobile');
	}
	signupNow() {
		this.router.navigateByUrl('/revamp-auth/signup-individual');
	}
}
const errMsgs = {
	'002': {
		en: 'Exceeded number of login retries',
		ar: 'كلمة المرور التي أدخلتها غير صحيحة ، يرجى المحاولة مرة أخرى',
	},
	'004': {
		en: 'Dear Customer, we are unable to register you at this moment due to a technical issue. Please try again after sometime.',
		ar: 'عزيزي العميل, لا يمكننا تسجيلك في الوقت الحالي بسبب مشكلة تقنية. الرجاء المحاولة في وقت لاحق',
	},
	'006': {
		en: 'This NationalID is already registered',
		ar: 'رقم الهوية مسجل من قبل',
	},
	'007': {
		en: 'Incorrect credentials/User does not Exist when trying to login with mobile',
		ar: 'بيانات الدخول غير صحيحة او المستخدم غير موجود عند محاولة تسجيل الدخول باستخدام الجوال',
	},
	'009': {
		en: 'This Mobile number is already registered',
		ar: 'رقم الجوال مسجل من قبل',
	},
	'010': {
		en: 'This Email is already registered',
		ar: 'البريد الاليكتروني مسجل من قبل',
	},
	'001': {
		en: 'Dear Customer, Apologies! The entered mobile number is not registered under your National/Iqama ID. Please provide a registered mobile number. For further assistance, contact AlRajhi Takaful customer care at 8001184444',
		ar: 'عزيزي العميل، نعتذر! رقم الجوال المُدخل غير مسجل تحت الهوية الوطنية/ الإقامة الخاصة بك. يُرجى تزويدنا برقم جوال مُسجل. للحصول على مساعدة إضافية، يُرجى التواصل مع خدمة العملاء في التكافل الراجحي على الرقم 8001184444',
	},
	'005': {
		en: 'Dear Customer, the DOB you entered does not match your National/Iqama ID. Please enter the DOB matches your National/Iqama ID',
		ar: 'عزيزنا العميل، لقد قمت بإدخال تاريخ ميلاد غير متطابق مع رقم الهوية، يرجى التحقق من صحة تاريخ الميلاد.',
	},
	'011': {
		en: 'Dear customer, we are unable to log into your account at the moment due to technical issue. Please try again later.',
		ar: 'عزيزي العميل، لا يمكننا تسجيل الدخول إلى حسابك في الوقت الحالي بسبب مشكلة فنية. يرجى المحاولة مرة أخرى بعد مرور بعض الوقت.',
	},
	'012': {
		en: 'User profile for this National/Iqama id already exists with different mobile number. If you wish to update your mobile number,',
		ar: 'رقم الجوال المدخل غير متطابق مع رقم الهوية/الاقامة المسجل لدينا، إذا كنت ترغب في تحديث رقم هاتفك',
	},
};

export class privacyData {
	encrypted_national_id: string;
	expiry_date: string;
	is_ppc_expired: boolean;
	ppc_version: string;
}
