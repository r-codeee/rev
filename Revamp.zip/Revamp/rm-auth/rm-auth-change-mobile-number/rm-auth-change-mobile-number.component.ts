import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import {
	ResendOtpRequestMobile,
	SendOtpRequestMobile,
} from 'src/app/rm-otp/models/config';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

@Component({
	selector: 'art-rm-auth-change-mobile-number',
	templateUrl: './rm-auth-change-mobile-number.component.html',
	styleUrls: ['./rm-auth-change-mobile-number.component.scss'],
})
export class RmAuthChangeMobileNumberComponent {
	private readonly storage = inject(ARTStorageService);
	private readonly authService = inject(AuthService);
	private router = inject(Router);
	customerData: any;
	sendRequest;
	errorMessage;
	constructor() {
		const { STORAGE_KEY } = this.authService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
	}

	updatePhoneNumber(phoneNumber) {
		this.customerData.phoneNumber = phoneNumber;
		let mobileTail = phoneNumber.toString();
		mobileTail = mobileTail.substr(mobileTail.length - 4);
		this.customerData.mobileTail = mobileTail;
		this.storage.Setvalue(this.authService.STORAGE_KEY, this.customerData);
		this.sendRequest = new SendOtpRequestMobile(
			this.customerData.phoneNumber,
			this.storage.GetValue('referenceId').toString(),
			'requestId',
			this.customerData.transactionType,
			localStorage.getItem('selectedLang'),
		);
		this.sendOTP();
	}

	sendOTP() {
		this.authService.sendFeatureOTP(this.sendRequest).subscribe(
			res => {
				if (res.data) {
					this.customerData = {
						...this.customerData,
						otpId: res.data.otpId.toString(),
					};
					this.storage.Setvalue(
						this.authService.STORAGE_KEY,
						this.customerData,
					);
					this.router.navigateByUrl('/revamp-auth/sme-login-otp');
				}
			},
			err => {
				this.errorCode(err);
			},
		);
	}
	errorCode(err) {
		if (err.meta && err.meta.status === 0) {
			this.errorMessage = err && err.error.message;
		} else {
			this.errorMessage = err.message;
			if (this.errorMessage == 'You have exceeded max resend tries!') {
				this.resendOTP();
			}
		}
	}

	resendOTP() {
		let resendOtpReq = new ResendOtpRequestMobile(
			this.customerData.phoneNumber,
			this.customerData.otpId,
			'health_endorsement',
			localStorage.getItem('selectedLang'),
		);
		this.authService.refreshToke().subscribe(
			() => {
				this.authService.resendFeatureOTP(resendOtpReq).subscribe(
					res => {
						if (res.meta && res.meta.status === 1) {
							this.customerData = {
								...this.customerData,
								otpId: res.data.otpId.toString(),
							};
							this.storage.Setvalue(
								this.authService.STORAGE_KEY,
								this.customerData,
							);
							this.router.navigateByUrl('/revamp-auth/sme-login-otp');
						}
					},
					err => {
						this.errorCode(err);
					},
				);
			},
			error => {
				this.errorMessage = error.statusText;
			},
		);
	}

  onCancelled() {
    this.router.navigateByUrl('/revamp-auth/sme-login-otp');
  }
}
