export enum Languages {
	EN = 'en',
	AR = 'ar',
}
