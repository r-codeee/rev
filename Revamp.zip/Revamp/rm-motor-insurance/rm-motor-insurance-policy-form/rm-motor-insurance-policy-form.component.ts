import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
	selector: 'app-rm-motor-insurance-policy-form',
	templateUrl: './rm-motor-insurance-policy-form.component.html',
	styleUrls: ['./rm-motor-insurance-policy-form.component.scss'],
})
export class RmMotorInsurancePolicyFormComponent {
	@Input() form: FormGroup;
}
