import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorInsurancePolicyFormComponent } from './rm-motor-insurance-policy-form.component';

describe('RmMotorInsurancePolicyFormComponent', () => {
  let component: RmMotorInsurancePolicyFormComponent;
  let fixture: ComponentFixture<RmMotorInsurancePolicyFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorInsurancePolicyFormComponent]
    });
    fixture = TestBed.createComponent(RmMotorInsurancePolicyFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
