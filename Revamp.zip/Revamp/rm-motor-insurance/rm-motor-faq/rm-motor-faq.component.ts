import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-faq',
	templateUrl: './rm-motor-faq.component.html',
	styleUrls: ['./rm-motor-faq.component.scss'],
})
export class RmMotorFAQComponent {
	// TODO: add the motor FAQ here and pass it to component art-product-FAQ in the template
}
