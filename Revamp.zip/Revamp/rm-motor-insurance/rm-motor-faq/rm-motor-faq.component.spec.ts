import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorFAQComponent } from './rm-motor-faq.component';

describe('RmMotorFAQComponent', () => {
  let component: RmMotorFAQComponent;
  let fixture: ComponentFixture<RmMotorFAQComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorFAQComponent]
    });
    fixture = TestBed.createComponent(RmMotorFAQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
