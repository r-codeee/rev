import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorInsuranceOwnerFormComponent } from './rm-motor-insurance-owner-form.component';

describe('RmMotorInsuranceOwnerFormComponent', () => {
  let component: RmMotorInsuranceOwnerFormComponent;
  let fixture: ComponentFixture<RmMotorInsuranceOwnerFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorInsuranceOwnerFormComponent]
    });
    fixture = TestBed.createComponent(RmMotorInsuranceOwnerFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
