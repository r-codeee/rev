import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { IconComponent } from 'src/app/design-system/icon/icon.component';

@Component({
	selector: 'app-rm-motor-insurance-owner-form',
	templateUrl: './rm-motor-insurance-owner-form.component.html',
	styleUrls: ['./rm-motor-insurance-owner-form.component.scss'],
})
export class RmMotorInsuranceOwnerFormComponent {
	@Input() form: FormGroup;

	nationalIdSuffixComponent = IconComponent;
	nationalIdSuffixComponentInputs = { icon: 'art-id-icon', size: 'xs' };
}
