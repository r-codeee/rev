import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
	selector: 'app-rm-motor-insurance-policy-date-form',
	templateUrl: './rm-motor-insurance-policy-date-form.component.html',
	styleUrls: ['./rm-motor-insurance-policy-date-form.component.scss'],
})
export class RmMotorInsurancePolicyDateFormComponent {
	@Input() form: FormGroup;
	@Input() isFormSubmitted = false;
}
