import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorInsurancePolicyDateFormComponent } from './rm-motor-insurance-policy-date-form.component';

describe('RmMotorInsurancePolicyDateFormComponent', () => {
  let component: RmMotorInsurancePolicyDateFormComponent;
  let fixture: ComponentFixture<RmMotorInsurancePolicyDateFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorInsurancePolicyDateFormComponent]
    });
    fixture = TestBed.createComponent(RmMotorInsurancePolicyDateFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
