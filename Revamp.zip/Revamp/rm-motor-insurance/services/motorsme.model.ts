export interface ICompanyInfo {
	crNumber: string;
	mobileNumber: string;
	emailAddress: string;
	source: string;
	zatcaNumber: string;
	policyStartDate: string;
	language: string;
	privacyPolicyConsent?: boolean;
}
