import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { isSourceSystemAPI } from 'src/app/utils/helpers/token-interceptor.service';
import { catchError, map, Observable, retry, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ICompanyInfo } from './motorsme.model';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Injectable({
	providedIn: 'root',
})
export class MotorServicesService {
	motorPurchaseApi = environment.motorPurchaseApi;
	private http = inject(HttpClient);
	currentLang = this.languageService.activeLang();
	baseurl = environment.sitecoreApi;

	constructor(private languageService: RMLanguageService) {}

	addCompanyInfo(lang: string, objData: ICompanyInfo): Observable<any> {
		const httpOptions = {
			headers: new HttpHeaders({
				language: this.currentLang,
			}),
		};
		return this.http
			.post<ICompanyInfo>(
				this.baseurl + '/v1/motorSmePolicies/companyinfo',
				objData,
				httpOptions,
			)
			.pipe(retry(1), catchError(this.errorHandl));
	}

	uploadDocsSingle(filePath: any) {
		return this.http
			.post<any>(this.motorPurchaseApi + '/v1/upload-single/file', filePath, {
				context: isSourceSystemAPI(),
			})
			.pipe(catchError(this.errorHandl));
	}

	errorHandl(error) {
		let errorMessage = '';
		if (error.error instanceof ErrorEvent) {
			errorMessage = error.error.message;
		} else {
			if (error.error.error == undefined) {
				errorMessage = 'oops';
			} else {
				errorMessage = error.error.error.message; //`Error Code: ${error.status}\nMessage: ${error.message}`;
			}
		}
		return throwError(errorMessage);
	}
}
