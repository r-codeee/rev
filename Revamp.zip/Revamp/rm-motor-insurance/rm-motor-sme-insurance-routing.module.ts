import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { RMMotorSmeTrackRequestComponent } from './rm-motor-sme-track-request/rm-motor-sme-track-request.component';
// import { MotorSmeConfirmationPaymentComponent } from './rm-motor-sme-confirmation-payment/rm-motor-sme-confirmation-payment.component';
import { AdditionalDriverComponent } from './rm-motor-sme-additional-driver/additional-driver.component';
import { RmMotorSmeHomeComponent } from './rm-motor-sme-home/rm-motor-sme-home.component';
import { RmMotorQuotationComponent } from './rm-motor-quotation/rm-motor-quotation.component';

const routes: Routes = [
	{
		path: '',
		component: RmMotorSmeHomeComponent,
	},
	{
		path: 'quotation',
		component: RmMotorQuotationComponent,
	},
	// {
	// 	path: 'track-request',
	// 	component: RMMotorSmeTrackRequestComponent,
	// },
	// {
	// 	path: 'payment-confirmation',
	// 	component: MotorSmeConfirmationPaymentComponent,
	// },
	{
		path: 'revamp-additional-driver',
		component: AdditionalDriverComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class RmMotorSmeInsuranceRoutingModule {}
