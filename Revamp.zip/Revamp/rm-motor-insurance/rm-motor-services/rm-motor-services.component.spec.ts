import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorServicesComponent } from './rm-motor-services.component';

describe('RmMotorServicesComponent', () => {
  let component: RmMotorServicesComponent;
  let fixture: ComponentFixture<RmMotorServicesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorServicesComponent]
    });
    fixture = TestBed.createComponent(RmMotorServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
