import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-services',
	templateUrl: './rm-motor-services.component.html',
	styleUrls: ['./rm-motor-services.component.scss'],
})
export class RmMotorServicesComponent {
	// TODO: add the motor services here and pass it to component art-product-services in the template
}
