import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RmMotorSmeInsuranceRoutingModule } from 'src/app/rm-motor-insurance/rm-motor-sme-insurance-routing.module';
import { ArtTrackRequest } from '../design-system/rm-track-request/rm-track-request.component';
import { RmPaymentConfirmationPageComponent } from '../rm-payment-confirmation-page/rm-payment-confirmation-page.component';
import { ArtProductSummaryCard } from '../design-system/rm-product-summary-card/rm-product-summary-card';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from '../design-system/icon/icon.component';
import { BasicInputComponent } from '../design-system/basic-input/basic-input.component';
import { ArtButtonComponent } from '../design-system/art-button/art-button.component';
import { StepperFooterComponent } from '../design-system/stepper-footer/stepper-footer.component';
import { RmDateInputComponent } from '../design-system/rm-date-input/rm-date-input.component';
import { ArtFormsModule } from 'src/art-forms/art-forms.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdditionalDriverComponent } from './rm-motor-sme-additional-driver/additional-driver.component';
import { RmMotorSmeHomeComponent } from './rm-motor-sme-home/rm-motor-sme-home.component';
import { SwitchBusinessIndividualComponent } from '../design-system/switch-business-individual/switch-business-individual.component';
import { RmMotorInsuranceOverviewComponent } from './rm-motor-insurance-overview/rm-motor-insurance-overview.component';
import { InsuranceOverviewComponent } from '../design-system/insurance-overview/insurance-overview.component';
import { GetMotorQuoteFormComponent } from './get-motor-quote-form/get-motor-quote-form.component';
import { DiscoverProductComponent } from '../design-system/discover-product/discover-product.component';
import { ManageYourPolicyOnlineSectionComponent } from '../design-system/manage-your-policy-online-section/manage-your-policy-online-section.component';
import { ShariahAndInsuranceAuthorityComponent } from '../design-system/shariah-and-insurance-authority/shariah-and-insurance-authority.component';
import { ProductInsuranceSideMenuComponent } from '../design-system/product-insurance-side-menu/product-insurance-side-menu.component';
import { RmMotorFeatureBenefitsComponent } from './rm-motor-feature-benefits/rm-motor-feature-benefits.component';
import { FeatureBenefitsComponent } from '../design-system/feature-benefits/feature-benefits.component';
import { RmMotorServicesComponent } from './rm-motor-services/rm-motor-services.component';
import { ProductServicesComponent } from '../design-system/product-services/product-services.component';
import { DoYouNeedHelpComponent } from '../design-system/do-you-need-help/do-you-need-help.component';
import { RmMotorFAQComponent } from './rm-motor-faq/rm-motor-faq.component';
import { ProductFAQComponent } from '../design-system/product-FAQ/product-FAQ.component';
import { ArtComparisonCard } from '../design-system/rm-comparison-card/rm-comparison-card';
import { RmMotorQuotationComponent } from './rm-motor-quotation/rm-motor-quotation.component';
import { BreadcrumbComponent } from '../design-system/breadcrumb/breadcrumb.component';
import { QuotationFormPageComponent } from '../design-system/quotation-form-page/quotation-form-page.component';
import { RmMotorFormComponent } from './rm-motor-quotation/rm-motor-form/rm-motor-form.component';
import { RmCustomOptionsComponent } from '../design-system/rm-custom-options/rm-custom-options.component';
import { PhoneBasicInputComponent } from '../design-system/phone-basic-input/phone-basic-input.component';
import { RmMotorInsurancePolicyFormComponent } from './rm-motor-insurance-policy-form/rm-motor-insurance-policy-form.component';
import { RmMotorInsuranceOwnerFormComponent } from './rm-motor-insurance-owner-form/rm-motor-insurance-owner-form.component';
import { RmMotorInsurancePolicyDateFormComponent } from './rm-motor-insurance-policy-date-form/rm-motor-insurance-policy-date-form.component';
import { RmMotorInsuranceOtherDetailsFormComponent } from './rm-motor-insurance-other-details-form/rm-motor-insurance-other-details-form.component';
import { AccordionRowComponent } from '../shared-components/accordions-holder/accordion-row/accordion-row.component';
import { RMOtpModule } from '../rm-otp/rm-otp.module';
import { RMMenuDataComponent } from '../rm-shared-components/rm-table copy/rm-menu-data.component';

@NgModule({
	declarations: [
		AdditionalDriverComponent,
		RmMotorSmeHomeComponent,
		RmMotorInsuranceOverviewComponent,
		GetMotorQuoteFormComponent,
		RmMotorFeatureBenefitsComponent,
		RmMotorServicesComponent,
		RmMotorFAQComponent,
		RmMotorQuotationComponent,
		RmMotorFormComponent,
		RmMotorInsurancePolicyFormComponent,
		RmMotorInsuranceOwnerFormComponent,
		RmMotorInsurancePolicyDateFormComponent,
		RmMotorInsuranceOtherDetailsFormComponent,
	],
	imports: [
		CommonModule,
		RmMotorSmeInsuranceRoutingModule,
		ArtTrackRequest,
		RmPaymentConfirmationPageComponent,
		CommonModule,
		ArtProductSummaryCard,
		TranslateModule,
		IconComponent,
		BasicInputComponent,
		ArtButtonComponent,
		StepperFooterComponent,
		RmDateInputComponent,
		ArtFormsModule,
		FormsModule,
		ReactiveFormsModule,
		SwitchBusinessIndividualComponent,
		InsuranceOverviewComponent,
		DiscoverProductComponent,
		ManageYourPolicyOnlineSectionComponent,
		ShariahAndInsuranceAuthorityComponent,
		ProductInsuranceSideMenuComponent,
		FeatureBenefitsComponent,
		ProductServicesComponent,
		DoYouNeedHelpComponent,
		ProductFAQComponent,
		ArtComparisonCard,
		BreadcrumbComponent,
		QuotationFormPageComponent,
		RmCustomOptionsComponent,
		PhoneBasicInputComponent,
		AccordionRowComponent,
		RMOtpModule,
		RMMenuDataComponent
	],
})
export class RmMotorSmeInsuranceModule {}
