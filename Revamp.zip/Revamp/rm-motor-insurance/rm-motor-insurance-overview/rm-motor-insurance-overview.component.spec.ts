import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorInsuranceOverviewComponent } from './rm-motor-insurance-overview.component';

describe('RmMotorInsuranceOverviewComponent', () => {
  let component: RmMotorInsuranceOverviewComponent;
  let fixture: ComponentFixture<RmMotorInsuranceOverviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorInsuranceOverviewComponent]
    });
    fixture = TestBed.createComponent(RmMotorInsuranceOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
