import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-insurance-overview',
	templateUrl: './rm-motor-insurance-overview.component.html',
	styleUrls: ['./rm-motor-insurance-overview.component.scss'],
})
export class RmMotorInsuranceOverviewComponent {
	onClickCheckProductDetails() {
		document
			.getElementById('feature-benefits')
			?.scrollIntoView({ behavior: 'smooth' });
	}
}
