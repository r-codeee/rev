import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { SvgIconComponent } from 'src/app/design-system/svg-icon/svg-icon.component';
import { ArtValidators } from 'src/app/utils/helpers/art-validators.helper';
import { MotorSmeService } from 'src/app/main-views/product-details/motor-sme/services/motorsme.service';
import { TranslateService } from '@ngx-translate/core';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import * as moment from 'moment';
import { IAdditionalDriverInfo } from 'src/app/main-views/product-details/motor-sme/services/motorsme.model';
import { ValidationError } from 'src/app/shared-components/error-validation-form/form-validation';
import { Router } from '@angular/router';

moment.locale('en'); //dont remove this line. it is added to have the locale in English
@Component({
	selector: 'art-additional-driver',
	templateUrl: './additional-driver.component.html',
	styleUrls: ['./additional-driver.component.scss'],
})
export class AdditionalDriverComponent {
	customerData = {
		driverName: 'omer',
		Model: 'Toyota',
		plateNumber: '123ABC',
		paymentAmount: '1000',
		paymentCurrency: 'SAR',
		paymentFrom: '21-05-2023',
		paymentTo: '21-05-2023',
		refNumber: '#65896226975',
		productIcon: 'car',
	};

	addAdditionalDriverForm: FormGroup;
	addDrivers: boolean = false;
	isShowMainDriverInfo = false;
	index = 0;
	public additionalDriversList: IAdditionalDriverInfo[];
	@Input() isShowAtleastOneAdditionalDriverError: boolean = false;
	@Output() premiumBreakupData = new EventEmitter<any>();
	@Output() isShowAtleastOneAdditionalDriverErrorFunction =
		new EventEmitter<any>();
	public submitted: boolean = false;
	public isDriverCheckedTrueFalse: boolean = false;
	public additionalDriverAddSection = false;
	public isShowadditionalDriversSection: boolean = false;
	public serverErrMsg: string = '';
	public hasServerErr: boolean = false;
	public hasError: boolean = false;
	public fromDate: any;
	public currentDate: any;
	public totalPremium: any;
	currentLang = 'en';
	public clearDate: boolean = false;
	public maxDriver: number = 5;
	public refId = 'U2FsdGVkX1%2BQIU3Gn27D%2Bi19WhbnNsOOXnEEwPwLSeU%3D'; // static reference id for testing purpose
	readonly router: Router = inject(Router);
	constructor(
		private fb: FormBuilder,
		private motorSmeService: MotorSmeService,
		private translateService: TranslateService,
		private formvalidation: ValidationError,
		private _auth: AuthService,
	) {
		this.constructForm();
	}
	constructForm() {
		this.addAdditionalDriverForm = this.fb.group({
			nationalId: [
				'',
				[Validators.required, ArtValidators.saudiNationalIDValidate()],
			],
			dateOfBirth: ['', [Validators.required]],
		});
	}
	nationalIdSuffixComponent = SvgIconComponent;
	nationalIdSuffixComponentInputs = { icon: 'nationalId', size: 'xs' };
	searchIconSuffixComponent = IconComponent;
	searchIconSuffixComponentInputs = { icon: 'search-logo-icon', size: 'xs' };

	ngOnInit(): void {
		this.getMainDriverInfo();
	}
	public formControlErrs(formControlName: string) {
		return this.formvalidation.getFormControlErrors(
			this.addAdditionalDriverForm,
			formControlName,
		);
	}

	public getMainDriverInfo() {
		this.motorSmeService
			.getMainDriverInfo(this.refId) // static Reference id used for api call
			.subscribe(res => {
				if (res.data) {
					this.premiumBreakupData.emit(res.data.finalRateSummary);
					this.isShowMainDriverInfo = true;
					this.totalPremium = res.data.finalRateSummary.basePremium;
					if (this.motorSmeService.isDriverChecked()) {
						this.isDriverCheckedTrueFalse = true;
					}

					this.getdrivers();
				}
			});
	}
	public getdrivers() {
		this.additionalDriverAddSection = true;
		this.motorSmeService
			.getdrivers(this.refId) // static Reference id used for api call
			.subscribe(res => {
				if (res.data) {
					this.maxDriver = Number(res.data.maxDriver);
					this.clearDate = false;
					this.additionalDriversList = res.data.addtionalDrivers;

					if (this.additionalDriversList.length > 0) {
						if (this.additionalDriversList.length >= this.maxDriver) {
							this.additionalDriverAddSection = false;
						}
						this.isShowadditionalDriversSection = true;
					}
				}
			});
	}
	public onSubmit() {
		const dobControl = this.addAdditionalDriverForm.get('dateOfBirth');
		const dobValue = dobControl.value;
		const formattedDob = moment(dobValue).format('DD-MM-YYYY');
		this.isShowAtleastOneAdditionalDriverError = false;
		this.isShowAtleastOneAdditionalDriverErrorFunction.emit(false);
		this.submitted = true;
		this.hasError = false;
		this.hasServerErr = false;
		if (!this.addAdditionalDriverForm.valid) {
			this.hasError = true;
			return false;
		} else {
			this._auth.guestLogin().subscribe(res => {
				localStorage.removeItem('token');
				localStorage.setItem('token', res.token);
				let driverPayload = {
					nationalId: this.addAdditionalDriverForm.value.nationalId,
					dateOfBirth: formattedDob,
				};

				this.motorSmeService
					.addDriver(
						this.currentLang,
						driverPayload,
						this.refId, // static Reference id used for api call
					)
					.subscribe({
						next: result => {
							this.getMainDriverInfo();

							this.submitted = false;
							this.addAdditionalDriverForm.reset();
							this.clearDate = true;
							this.getdrivers();
						},
						error: err => {
							this.submitted = false;
							this.hasServerErr = true;
							if (err === 'oops') {
								this.serverErrMsg =
									this.translateService.translations[
										this.currentLang
									].motorSME.oops;
							} else {
								this.serverErrMsg = err;
							}
						},
						complete: () => {},
					});
			});
		}
	}
	back() {
		this.router.navigateByUrl(
			'/revamp-motor-insurance-sme/rm-motor-insurance-sme-stepper/revamp-motor-add-addons',
		);
	}
	public deleteDriver(driverId) {
		this.isShowAtleastOneAdditionalDriverErrorFunction.emit(false);
		this.isShowAtleastOneAdditionalDriverError = false;
		this.hasServerErr = false;
		this.hasError = false;
		let deletePayload = {
			driverId: driverId,
		};
		this.motorSmeService
			.deleteDriver(
				deletePayload,
				this.refId, // static Reference id used for api call
			)
			.subscribe(res => {
				this.addAdditionalDriverForm.reset();
				this.clearDate = true;
				this.getMainDriverInfo();
			});
	}
}
