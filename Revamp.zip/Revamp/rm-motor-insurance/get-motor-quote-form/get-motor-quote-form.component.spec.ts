import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMotorQuoteFormComponent } from './get-motor-quote-form.component';

describe('GetMotorQuoteFormComponent', () => {
  let component: GetMotorQuoteFormComponent;
  let fixture: ComponentFixture<GetMotorQuoteFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GetMotorQuoteFormComponent]
    });
    fixture = TestBed.createComponent(GetMotorQuoteFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
