import { Component } from '@angular/core';

@Component({
	selector: 'app-get-motor-quote-form',
	templateUrl: './get-motor-quote-form.component.html',
	styleUrls: ['./get-motor-quote-form.component.scss'],
})
export class GetMotorQuoteFormComponent {
	heading = 'INDIVIDUAL_MOTOR.BANNER_HEADING';
	description = 'INDIVIDUAL_MOTOR.BANNER_DESCRIPTION';
	buttonText = 'INDIVIDUAL_MOTOR.BANNER_BUTTON_TEXT';
}
