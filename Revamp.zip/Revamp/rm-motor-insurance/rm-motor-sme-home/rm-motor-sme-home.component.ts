import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-sme-home',
	templateUrl: './rm-motor-sme-home.component.html',
	styleUrls: ['./rm-motor-sme-home.component.scss'],
})
export class RmMotorSmeHomeComponent {}
