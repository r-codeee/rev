import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorSmeHomeComponent } from './rm-motor-sme-home.component';

describe('RmMotorSmeHomeComponent', () => {
  let component: RmMotorSmeHomeComponent;
  let fixture: ComponentFixture<RmMotorSmeHomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorSmeHomeComponent]
    });
    fixture = TestBed.createComponent(RmMotorSmeHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
