import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorFeatureBenefitsComponent } from './rm-motor-feature-benefits.component';

describe('RmMotorFeatureBenefitsComponent', () => {
  let component: RmMotorFeatureBenefitsComponent;
  let fixture: ComponentFixture<RmMotorFeatureBenefitsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorFeatureBenefitsComponent]
    });
    fixture = TestBed.createComponent(RmMotorFeatureBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
