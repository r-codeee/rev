import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-feature-benefits',
	templateUrl: './rm-motor-feature-benefits.component.html',
	styleUrls: ['./rm-motor-feature-benefits.component.scss'],
})
export class RmMotorFeatureBenefitsComponent {
	// TODO: add 'benefits' variable here and pass it to <art-feature-benefits /> when marketing team give real data for feature benefits section.
}
