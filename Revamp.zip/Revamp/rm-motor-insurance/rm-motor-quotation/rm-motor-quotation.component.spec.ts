import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorQuotationComponent } from './rm-motor-quotation.component';

describe('RmMotorQuotationComponent', () => {
  let component: RmMotorQuotationComponent;
  let fixture: ComponentFixture<RmMotorQuotationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorQuotationComponent]
    });
    fixture = TestBed.createComponent(RmMotorQuotationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
