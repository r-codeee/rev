import { Component } from '@angular/core';

@Component({
	selector: 'app-rm-motor-quotation',
	templateUrl: './rm-motor-quotation.component.html',
	styleUrls: ['./rm-motor-quotation.component.scss'],
})
export class RmMotorQuotationComponent {
	breadcrumbItems = [
		{ label_ar: 'Home', label_en: 'Home', link: '/' },
		{
			label_ar: 'SME Products',
			label_en: 'SME Products',
			link: '/revamp-motor-sme-insurance',
		},
		{
			label: 'Motor Insurance',
			label_en: 'Motor Insurance',
			link: '/revamp-motor-sme-insurance/quotation',
		},
	];
	currentUrl = 'revamp-motor-sme-insurance/quotation';
}
