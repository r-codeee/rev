import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorFormComponent } from './rm-motor-form.component';

describe('RmMotorFormComponent', () => {
  let component: RmMotorFormComponent;
  let fixture: ComponentFixture<RmMotorFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorFormComponent]
    });
    fixture = TestBed.createComponent(RmMotorFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
