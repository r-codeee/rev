import { Component } from '@angular/core';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { GetMotorQuoteFormValues } from 'src/app/rm-shared-components/types/GetMotorQuoteFormValues';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtGetQuoteFormValidationSchemaService } from 'src/app/rm-shared-components/services/art-get-quote-form-validation-schema.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { TranslateService } from '@ngx-translate/core';
import { NavigationExtras, Router } from '@angular/router';
import {
	LanguageService,
	Pages,
} from 'src/app/utils/services/shared/language.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { MotorServicesService } from '../../services/motor-services.service';

@Component({
	selector: 'app-rm-motor-form',
	templateUrl: './rm-motor-form.component.html',
	styleUrls: ['./rm-motor-form.component.scss'],
})
export class RmMotorFormComponent extends BaseFormComponent<GetMotorQuoteFormValues> {
	values: GetMotorQuoteFormValues = {
		CRNumber: '',
		nationalId: '',
		mobileNumber: '',
		email: '',
		policyStartDate: '',
		haveZatcaVatNumber: false,
		zatcaNumber: '',
		zatcaDocUrl: '',
	};
	serverErrMsg: string = '';

	validationSchema =
		this.quoteFormValidationSchemaService.createIndividualMotorValidationSchema();

	currentLang = this.languageService.activeLang();

	constructor(
		private quoteFormValidationSchemaService: ArtGetQuoteFormValidationSchemaService,
		protected formBuilderService: ArtFormBuilderService,
		private languageService: RMLanguageService,
		private motorServicesService: MotorServicesService,
		private translateService: TranslateService,
		private _route: Router,
		private langService: LanguageService,
		private storage: ARTStorageService,
	) {
		super(formBuilderService);
	}

	onSubmit(values: GetMotorQuoteFormValues) {
		if (!this.form.valid) {
			return false;
		} else {
			let date = new Date(this.form.get('policyStartDate').value);
			let motorSmeObj = {
				crNumber: this.form.value.CRNumber,
				mobileNumber: this.form.value.mobileNumber,
				emailAddress: this.form.value.email,
				zatcaNumber: this.form.value.zatcaNumber,
				zatcaDocUrl: this.form.value.zatcaDocUrl,
				policyStartDate:
					date.getDate() + '-' + date.getMonth() + '-' + date.getFullYear(),
				driverNationalId: this.form.value.nationalId,
				source: 'web',
				language: this.currentLang,
				privacyPolicyConsent: true,
			};
			this.motorServicesService
				.addCompanyInfo(this.currentLang, motorSmeObj)
				.subscribe(
					res => {
						const navCont: NavigationExtras = {
							state: {
								referenceId: res.data.referenceId,
							},
						};
						this.storage.RemoveValue('totalVehicle');
						this.storage.RemoveValue('flowSelectedVehicles');
						this.storage.RemoveValue('flowSelectedAddons');
						this.storage.RemoveValue('addonCustomList');
						this.storage.Setvalue('referenceId', res.data.referenceId);
						this.storage.Setvalue('isProcessVehicleList', false);
						this.storage.Setvalue('stepperCurrentStep', 1);
						this.storage.Setvalue('skipSmartComprehensive', true);
						this.storage.Setvalue('isShowAppPremiumBreakup', false);
						this.storage.Setvalue('isComprehensiveProduct', false);
						this.storage.Setvalue('isQuoteGenerated', false);
						this.storage.Setvalue('isDriverChecked', false);
						let URL = this.langService.getLink(Pages.sme.motorsmeDetails);
						this._route.navigate([URL], {
							state: { navData: navCont },
						});
					},
					err => {
						if (err === 'oops') {
							this.serverErrMsg =
								this.translateService.translations[
									this.currentLang
								].motorSME.oops;
						} else {
							this.serverErrMsg = err;
						}
					},
				);
		}
	}
}
