import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CustomOption } from 'src/app/products/personal/rm-mmp/models/custom-option.model';
import { MotorServicesService } from '../services/motor-services.service';
import { TranslateService } from '@ngx-translate/core';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Component({
	selector: 'app-rm-motor-insurance-other-details-form',
	templateUrl: './rm-motor-insurance-other-details-form.component.html',
	styleUrls: ['./rm-motor-insurance-other-details-form.component.scss'],
})
export class RmMotorInsuranceOtherDetailsFormComponent {
	@Input() form: FormGroup;
	@Input() isFormSubmitted = false;
	serverErrMsg: string = '';
	yesNoOptions: Array<CustomOption> = [
		new CustomOption('Yes', true),
		new CustomOption('No', false),
	];
	uploadZatcaVat = false;

	docItem = {
		Id: undefined,
		Name: undefined,
		size: undefined,
		URL: undefined,
	};
	showFileerrorsRequired: boolean = false;
	ZATCAFileUploadName: '';
	currentLang = this.languageService.activeLang();

	constructor(
		private motorServicesService: MotorServicesService,
		private translateService: TranslateService,
		private languageService: RMLanguageService,
	) {}

	onClaimsSelected(event) {
		this.uploadZatcaVat = event;
		this.form.value.zatcaNumber = '';
	}

	onFileSelect(event) {
		const file = event.target.files[0];
		let size;
		const allowedExt = {
			'image/png': 'png',
			'image/jpeg': 'jpg',
			'application/pdf': 'pdf',
		};
		size = 10000000;
		if (
			(file.type == 'image/png' ||
				file.type == 'image/jpeg' ||
				file.type == 'application/pdf') &&
			file.size <= size
		) {
			const fileExt = allowedExt[file.type];
			let myfile = event.target.files[0];
			this.ZATCAFileUploadName = myfile ? myfile.name : '';
			let filename =
				('ZATCA' + new Date().getTime()).replace(/[^\w\s]/gi, '') +
				'.' +
				fileExt;
			const blobToDataUrl = blob =>
				new Promise((resolve, reject) => {
					const reader = new FileReader();
					reader.onload = () => resolve(reader.result);
					reader.onerror = reject;
					reader.readAsDataURL(blob);
				});

			let transactionId =
				this.form.get('CRNumber').value +
				('MotorSme' + new Date().getTime()).replace(/[^\w\s]/gi, '');
			blobToDataUrl(myfile).then(data => {
				let body = {
					upload: data,
					docType: file.type,
					productType: 'GeneralSME',
					transactionId: transactionId,
					imageDirection: 'ZATCAA',
				};
				this.motorServicesService.uploadDocsSingle(body).subscribe({
					next: res => {
						if (res.data && res.data.dmsUrl) {
							this.form.value.zatcaDocUrl = res.data.dmsUrl;
							this.docItem.URL = res.data.dmsUrl;
						}
						this.showFileerrorsRequired = false;
					},
					error: err => {
						this.showFileerrorsRequired = true;
						this.serverErrMsg =
							this.translateService.translations[this.currentLang].motorSME.err;
					},
				});
			});
			this.showFileerrorsRequired = false;
		} else {
			this.showFileerrorsRequired = true;
		}
	}

	deleteFile(docId) {
		this.docItem = {
			Id: undefined,
			Name: undefined,
			size: undefined,
			URL: undefined,
		};
		this.form.value.zatcaDocUrl = '';
	}
}
