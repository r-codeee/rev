import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorInsuranceOtherDetailsFormComponent } from './rm-motor-insurance-other-details-form.component';

describe('RmMotorInsuranceOtherDetailsFormComponent', () => {
  let component: RmMotorInsuranceOtherDetailsFormComponent;
  let fixture: ComponentFixture<RmMotorInsuranceOtherDetailsFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorInsuranceOtherDetailsFormComponent]
    });
    fixture = TestBed.createComponent(RmMotorInsuranceOtherDetailsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
