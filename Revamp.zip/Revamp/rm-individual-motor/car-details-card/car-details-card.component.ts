import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RMIndividualMotorModalComponent } from '../rm-individual-motor-modal/rm-individual-motor-modal.component';

@Component({
	selector: 'art-car-details-card',
	templateUrl: './car-details-card.component.html',
	styleUrls: ['./car-details-card.component.scss'],
})
export class CarDetailsCardComponent implements OnInit {
	@Input() vehicleDetails: any;
	@Input() referenceNumber: any;
	@Input() isSelected: boolean;
	@Output() removeCard = new EventEmitter();
	coverageValue: number = 0;
	currentLang: string;

	constructor(private ngbModal: NgbModal) {
		this.currentLang = localStorage.getItem('selectedLang') || 'en';
	}

	ngOnInit() {
		if (this.vehicleDetails?.premium_details?.length) {
			this.coverageValue = this.vehicleDetails?.premium_details.find(
				item => item.product_code == this.vehicleDetails.product_code,
			)?.ITDPremium;
		}
	}

	removeCardFunction() {
		let deleteModalRef = this.ngbModal.open(RMIndividualMotorModalComponent, {
			centered: true,
			windowClass: 'custom-common-model-width',
		});
		deleteModalRef.componentInstance.btncustomClasses = 'background-bg-error';
		deleteModalRef.componentInstance.variant = 'error';
		deleteModalRef.componentInstance.fontAwesomeClass =
			'fa-solid fa-triangle-exclamation';
		deleteModalRef.componentInstance.btnConfirmLabel = 'COMMON.CONFRIM_DELETE';
		deleteModalRef.componentInstance.btnCloseLabel = 'COMMON.CANCEL_DELETE';
		deleteModalRef.componentInstance.desc =
			'INDIVIDUAL_MOTOR.DELETE_CONFIRMATION';
		// Handle modal result
		deleteModalRef.result
			.then(result => {
				if (result) {
					this.removeCard.emit(); // Emit the remove event if confirmed
				}
			})
			.catch(() => {
				console.log('Modal dismissed');
			});
	}

	deductibleDefaultValue(x) {
		x = Number(x);
		let val = 2000;
		if (x > 60000) {
			val = 25000;
		}
		if (x > 45000 && x <= 60000) {
			val = 20000;
		}
		if (x > 30000 && x <= 45000) {
			val = 15000;
		}
		if (x <= 30000) {
			val = 10000;
		}
		return val;
	}
}
