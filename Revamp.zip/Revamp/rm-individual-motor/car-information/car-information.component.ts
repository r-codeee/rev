import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IVehicle } from 'src/app/rm-individual-motor/types/IVehicle';
import { IQuoteRiskItemDetail } from '../models/individualMotorDto';

@Component({
	selector: 'art-car-information',
	templateUrl: './car-information.component.html',
	styleUrls: ['./car-information.component.scss'],
})
export class CarInformationComponent {
	@Input() riskItemDetail: IQuoteRiskItemDetail;
	@Input() isAddNewCar: boolean;
	@Input() nationalId: string;
	@Output() onCloseAddNewCar = new EventEmitter();
	@Output() onClickAddNewCar = new EventEmitter();

	handleClickAddNewCar($event: any) {
		this.onClickAddNewCar.emit($event);
	}
	handlCloseAddNewCar() {
		this.onCloseAddNewCar.emit();
	}
}
