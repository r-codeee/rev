import { CommonModule } from '@angular/common';
import {
	Component,
	Input,
} from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';
import { NgbActiveModal, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
@Component({
	selector: 'rm-individual-motor-modal',
	standalone: true,
	templateUrl: './rm-individual-motor-modal.component.html',
	styleUrls: ['./rm-individual-motor-modal.component.scss'],
	imports: [
		CommonModule,
		IconComponent,
		ArtButtonComponent,
		TranslateModule,
		PopupAlertComponent,
		NgbModalModule
	],
})
export class RMIndividualMotorModalComponent {
	@Input() fontAwesomeClass;
	@Input() btncustomClasses;
	@Input() desc;
	@Input() btnConfirmLabel;
	@Input() btnCloseLabel;
	@Input() btnClass;
	@Input() variant;
	
	currentLang: string;
	constructor(
		private modalRef: NgbActiveModal,
	) {
		this.currentLang = localStorage.getItem('currentLang') || 'ar';
	}

	confirm() {
		this.modalRef.close(true);
		
	}
	close() {
		this.modalRef.close(false);
	}

}
