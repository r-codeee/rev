import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNewCarFormComponent } from './add-new-car-form.component';

describe('AddNewCarFormComponent', () => {
  let component: AddNewCarFormComponent;
  let fixture: ComponentFixture<AddNewCarFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddNewCarFormComponent]
    });
    fixture = TestBed.createComponent(AddNewCarFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
