import {
	Component,
	EventEmitter,
	inject,
	Input,
	OnInit,
	Output,
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { cloneDeep } from 'lodash';
import { ICardData } from 'src/app/design-system/motor-card-with-radio/motor-card-with-radio.component';
import { queryClient } from 'src/app/revamp-routing/configureRevampModule';
import { queryKeys } from 'src/app/rm-individual-motor/constants/queryKeys';
import { AddNewCarMethods } from 'src/app/rm-individual-motor/enums/AddNewCarMethods';
import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';
import { MultiMotorService } from 'src/app/rm-individual-motor/services/multi-motor.service';
import {
	IAddVehicleByCustomNumber,
	IAddVehicleByOwnershipNumber,
	IAddVehicleBySequenceNumber,
} from 'src/app/rm-individual-motor/types/IAddNewVehicle';
import { IRatesInfoResponse } from 'src/app/rm-individual-motor/types/IRatesInfoResponse';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

@Component({
	selector: 'art-add-new-car-form',
	templateUrl: './add-new-car-form.component.html',
	styleUrls: ['./add-new-car-form.component.scss'],
})
export class AddNewCarFormComponent implements OnInit {
	@Input() nationalId: string;
	@Input() isLoadingAddNewCar: boolean = false;

	protected readonly AddNewCarMethods = AddNewCarMethods;
	private individualMotor = inject(IndividualMotorService);
	private multiMotor = inject(MultiMotorService);
	serverErrorMessage: string;

	addCarMethods = cloneDeep(this.individualMotor.ADD_CAR_METHODS);
	form: FormGroup;
	@Input() title = '';
	@Input() customClass = '';

	@Output() onAddNewVehicleSuccessfully: EventEmitter<any> =
		new EventEmitter<any>();

	@Output() onChangeInput: EventEmitter<any> = new EventEmitter<any>();

	private storage = inject(ARTStorageService);
	storageData = this.storage.GetValue(this.individualMotor.STORAGE_KEY);

	ngOnInit() {
		this.form = new FormGroup({
			[AddNewCarMethods.SEQUENCE_NUMBER]: new FormControl(false),
			[AddNewCarMethods.OWNERSHIP_TRANSFER]: new FormControl(false),
			[AddNewCarMethods.CUSTOM_NUMBER]: new FormControl(false),
		});
	}

	handleSelectAddCarMethod(selectedMethod: ICardData) {
		console.info(selectedMethod);

		this.addCarMethods = this.addCarMethods.map(method => {
			if (method.id === selectedMethod.id) {
				this.form.get(method.id).setValue(true);
				return {
					...method,
					active: true,
				};
			}
			this.form.get(method.id).setValue(false);
			return { ...method, active: false };
		});
		this.onChangeInput.emit(true);
	}

	handleSubmitAddCar(
		values: IAddVehicleByCustomNumber | IAddVehicleByOwnershipNumber,
	) {
		// this.isLoadingAddNewCar = true;
		if (!values?.nationalIdNumber) {
			values.nationalIdNumber = this.nationalId;
		}
		const trueKeys = Object.keys(this.form.value).filter(
			key => this.form.value[key] === true,
		);
		this.onAddNewVehicleSuccessfully.emit({
			values,
			selectedMethod: trueKeys[0],
		});
	}

	handleSubmitSequanceAddCar(values: IAddVehicleBySequenceNumber) {
		const trueKeys = Object.keys(this.form.value).filter(
			key => this.form.value[key] === true,
		);
		this.onAddNewVehicleSuccessfully.emit({
			values,
			selectedMethod: trueKeys[0],
		});
	}

	changeInput(event) {
		this.onChangeInput.emit(true);
	}
}
