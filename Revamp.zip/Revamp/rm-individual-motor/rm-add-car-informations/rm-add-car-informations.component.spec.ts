import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmAddCarInformationsComponent } from './rm-add-car-informations.component';

describe('RmAddCarInformationsComponent', () => {
  let component: RmAddCarInformationsComponent;
  let fixture: ComponentFixture<RmAddCarInformationsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmAddCarInformationsComponent]
    });
    fixture = TestBed.createComponent(RmAddCarInformationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
