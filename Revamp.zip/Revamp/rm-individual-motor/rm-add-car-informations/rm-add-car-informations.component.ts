import { TranslateService } from '@ngx-translate/core';
import {
	AfterViewInit,
	ChangeDetectorRef,
	Component,
	EventEmitter,
	inject,
	Input,
	OnChanges,
	OnInit,
	Output,
	SimpleChanges,
} from '@angular/core';
import { DropdownOptionType } from 'src/app/design-system/types/DropdownOptionType';
import { CustomOption } from 'src/app/rm-cyber-insurance/models/custom-option.model';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ObjectSchema } from 'yup';
import { TransmissionType } from '../enums/TransmissionType';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { IRiskItemAdditionalDetails } from '../models/individualMotorDto';
import { MotorAdditionalInfoFormValidationSchemaService } from '../services/motor-additional-info-form-validation-schema.service';
import { IndividualMotorService } from '../services/individual-motor.service';
import { ParkingType } from '../enums/ParkingType';

@Component({
	selector: 'art-rm-add-car-informations',
	templateUrl: './rm-add-car-informations.component.html',
	styleUrls: ['./rm-add-car-informations.component.scss'],
})
export class RmAddCarInformationsComponent
	extends BaseFormComponent<IRiskItemAdditionalDetails>
	implements AfterViewInit, OnChanges, OnInit
{
	protected languageService = inject(RMLanguageService);
	protected additionalInfoFormService = inject(
		MotorAdditionalInfoFormValidationSchemaService,
	);
	protected translationService = inject(TranslateService);

	@Input() additionalInfo: any;
	@Input() isLoading: boolean = false;

	validationSchema: ObjectSchema<IRiskItemAdditionalDetails> =
		this.additionalInfoFormService.createAddionalInfoValidationSchema();

	yesNoOptions: Array<CustomOption> = [
		new CustomOption(this.translationService.instant('COMMON.YES'), true),
		new CustomOption(this.translationService.instant('COMMON.NO'), false),
	];
	currentLang = this.languageService.activeLang();

	transmissionOptions: Array<CustomOption> = [
		new CustomOption(
			this.translateService.instant('INDIVIDUAL_MOTOR.AUTOMATIC'),
			TransmissionType.AUTOMATIC,
		),
		new CustomOption(
			this.translateService.instant('INDIVIDUAL_MOTOR.MANUAL'),
			TransmissionType.MANUAL,
		),
	];

	vehicleRepairTypeOptions: Array<DropdownOptionType> = [
		{
			Id: 1,
			Name_en: 'Out of Agency',
			value: 'Out of Agency',
		},
	];
	parkingOptions: Array<DropdownOptionType> =
		this.individualMotorService.parkingOptions;
	numOfSeatOptions: Array<DropdownOptionType> =
		this.individualMotorService.numOfSeatOptions;
	engineVolumeOptions: Array<DropdownOptionType> =
		this.individualMotorService.engineVolumeOptions;
	distanceTraveledOptions: Array<DropdownOptionType> = [];
	PurposeOfUsingVehicleList: Array<DropdownOptionType> = [];

	selectedParkingDuringNight = null;
	selectedPurpose = null;
	selectedNumberOfSeats = null;
	selectedEngineVolume = null;

	values: IRiskItemAdditionalDetails = {
		transmission: TransmissionType.AUTOMATIC,
		distanceTraveled: 0,
		engineVolume: '',
		numOfSeat: '',
		parkingDuringNight: this.parkingOptions[0].value,
		antiSlipBreakingSystem: false,
		autoBreakingSystem: false,
		cruiseCtrl: false,
		adaptiveCruiseCtrl: false,
		frontSensor: false,
		frontCamera: false,
		rearCamera: false,
		threeSixtyDegreeCamera: false,
		modificationToCar: false,
		rearParkingSensor: false,
	};

	@Output() onSubmitForm: EventEmitter<IRiskItemAdditionalDetails> =
		new EventEmitter();

	constructor(
		private individualMotorService: IndividualMotorService,
		protected formBuilderService: ArtFormBuilderService,
		private translateService: TranslateService,
		private cdr: ChangeDetectorRef,
		private fb: ArtFormBuilderService,
	) {
		super(formBuilderService);
	}

	ngOnInit(): void {
		super.ngOnInit();
		
	}
	

	ngOnChanges(changes: SimpleChanges): void {
		this.selectedParkingDuringNight = this.parkingOptions.find(
			el => el.value == this.additionalInfo.parkingDuringNight,
		);

		// this.getPurposeOfUsingVehicleList();
		this.selectedNumberOfSeats = this.numOfSeatOptions.find(
			el => el.value == this.additionalInfo.numOfSeat,
		);

		this.selectedEngineVolume = this.engineVolumeOptions.find(
			el => el.value == this.additionalInfo.engineVolume,
		);


		if ((
			changes['additionalInfo'].currentValue &&
			JSON.stringify(changes['additionalInfo'].currentValue) !==
				JSON.stringify(changes['additionalInfo'].previousValue)) && this.form
		) {
			console.info(this.additionalInfo);
			this.form.patchValue({
				transmission:
					this.additionalInfo.transmission || TransmissionType.AUTOMATIC,
				distanceTraveled: this.additionalInfo.distanceTraveled,
				engineVolume: this.additionalInfo.engineVolume,
				numOfSeat: this.additionalInfo.numOfSeat,
				parkingDuringNight: this.additionalInfo.parkingDuringNight,
				antiSlipBreakingSystem:
					this.additionalInfo.antiSlipBreakingSystem ?? false,
				autoBreakingSystem: this.additionalInfo.autoBreakingSystem ?? false,
				cruiseCtrl: this.additionalInfo.cruiseCtrl ?? false,
				adaptiveCruiseCtrl: this.additionalInfo.adaptiveCruiseCtrl ?? false,
				frontSensor: this.additionalInfo.frontSensor ?? false,
				frontCamera: this.additionalInfo.frontCamera ?? false,
				rearCamera: this.additionalInfo.rearCamera ?? false,
				threeSixtyDegreeCamera: this.additionalInfo.threeSixtyDegreeCamera
					? this.additionalInfo.threeSixtyDegreeCamera
					: false,
				modificationToCar: this.additionalInfo.modificationToCar ?? false,
				rearParkingSensor: this.additionalInfo.rearParkingSensor ?? false,
				purposeOfUsingVehicle: this.additionalInfo?.purposeOfUsingVehicle,
			});
			this.form.updateValueAndValidity();
		}
	}

	ngAfterViewInit(): void {
		this.getPurposeOfUsingVehicleList();
		this.form.patchValue({
			transmission:
				this.additionalInfo.transmission || TransmissionType.AUTOMATIC,
			distanceTraveled: this.additionalInfo.distanceTraveled,
			engineVolume: this.additionalInfo.engineVolume,
			numOfSeat: this.additionalInfo.numOfSeat,
			parkingDuringNight: this.additionalInfo.parkingDuringNight,
			antiSlipBreakingSystem:
				this.additionalInfo.antiSlipBreakingSystem ?? false,
			autoBreakingSystem: this.additionalInfo.autoBreakingSystem ?? false,
			cruiseCtrl: this.additionalInfo.cruiseCtrl ?? false,
			adaptiveCruiseCtrl: this.additionalInfo.adaptiveCruiseCtrl ?? false,
			frontSensor: this.additionalInfo.frontSensor ?? false,
			frontCamera: this.additionalInfo.frontCamera ?? false,
			rearCamera: this.additionalInfo.rearCamera ?? false,
			threeSixtyDegreeCamera: this.additionalInfo.threeSixtyDegreeCamera
				? this.additionalInfo.threeSixtyDegreeCamera
				: false,
			modificationToCar: this.additionalInfo.modificationToCar ?? false,
			rearParkingSensor: this.additionalInfo.rearParkingSensor ?? false,
			purposeOfUsingVehicle: this.additionalInfo?.purposeOfUsingVehicle,
		});
		
		this.form.updateValueAndValidity();
	}

	patchValueToForm() {
		this.getPurposeOfUsingVehicleList();
		this.form.patchValue({
			transmission:
				this.additionalInfo.transmission || TransmissionType.AUTOMATIC,
			distanceTraveled: this.additionalInfo.distanceTraveled,
			engineVolume: this.additionalInfo.engineVolume,
			numOfSeat: this.additionalInfo.numOfSeat,
			parkingDuringNight: this.additionalInfo.parkingDuringNight,
			antiSlipBreakingSystem:
				this.additionalInfo.antiSlipBreakingSystem ?? false,
			autoBreakingSystem: this.additionalInfo.autoBreakingSystem ?? false,
			cruiseCtrl: this.additionalInfo.cruiseCtrl ?? false,
			adaptiveCruiseCtrl: this.additionalInfo.adaptiveCruiseCtrl ?? false,
			frontSensor: this.additionalInfo.frontSensor ?? false,
			frontCamera: this.additionalInfo.frontCamera ?? false,
			rearCamera: this.additionalInfo.rearCamera ?? false,
			threeSixtyDegreeCamera: this.additionalInfo.threeSixtyDegreeCamera
				? this.additionalInfo.threeSixtyDegreeCamera
				: false,
			modificationToCar: this.additionalInfo.modificationToCar ?? false,
			rearParkingSensor: this.additionalInfo.rearParkingSensor ?? false,
			purposeOfUsingVehicle: this.additionalInfo?.purposeOfUsingVehicle,
		});
		this.form.updateValueAndValidity();
	}

	getPurposeOfUsingVehicleList() {
		this.individualMotorService.find('usage_type').subscribe({
			next: (res: any) => {
				this.PurposeOfUsingVehicleList = res.map(el => {
					return {
						Name_en: el.name_en,
						Name_ar: el.name_ar,
						Id: parseInt(el.id),
						value: parseInt(el.id),
					};
				});
				this.selectedPurpose = this.PurposeOfUsingVehicleList.find(
					el =>
						// el.value == parseInt(this.additionalInfo?.addl_details.purposeOfUsingVehicle),
						el.value == parseInt(this.additionalInfo?.purposeOfUsingVehicle),
				);
				console.log(this.PurposeOfUsingVehicleList)
				console.info(this.selectedPurpose);
			},
			error: err => {
				console.log(err);
			},
		});
	}

	transmissionSelected(event) {
		console.log(event);
	}

	dropdownSelected(event, controlName: string) {
		this.form.get(controlName).setValue(event.value);
		console.info(event);
	}

	optionSelected(event, controlName: string) {
		this.form.get(controlName).setValue(event);
	}

	onSubmit(values: IRiskItemAdditionalDetails): void {
		this.onSubmitForm.emit(values);
	}
}
