import { Addons, RateDetails } from '../../rm-payment/model/payment-details';
import { AddOnDetailsData, RiskItemDetails } from './individual-motor-payment';

export class PaymentSummaryMotorIndividualDto implements RateDetails {
	AnnualPremium: number;
	BasePremium: number;
	CommissionAmount: number;
	CommissionRate: number;
	GrandTotalPremium: number;
	Id: string;
	MinimumPremium: number;
	NetChange: number;
	NetPremium: number;
	OverrideNetChange: number;
	OverridePremium: number;
	PlanID: number;
	PlanType: string;
	PreadjustedNetChange: number;
	PreadjustedTermPremium: number;
	Premium: number;
	PriorPremium: number;
	PriorTermPremium: number;
	ProductID: number;
	ProratedMinimumPremium: number;
	TermPremium: number;
	TotalPremium: number;
	TransactionPremium: number;
	Type: string;
	VATAmount: number;
	VATRate: number;
	ratedManualPremium: number;
	selected: boolean;
	quotId: number;
	SchemeDiscountAmount: number;
	addons: Addons[] = [];
	currentLang: any = localStorage.getItem('selectedLang');
	NCDAmount: number;
	MultiVehicleDiscountAmount: number;
	LoyaltyDiscountAmount: number;
	SchemeDiscountAmountMotor: number;
	constructor(data: RiskItemDetails[], addonsDetails: AddOnDetailsData[]) {
		const summedPremiumDetails: any = data.reduce((acc: any, item) => {
			const premiumDetails = item.premium_details;
			Object.keys(premiumDetails).forEach(key => {
				acc[key] = (acc[key] || 0) + premiumDetails[key];
			});
			return acc;
		}, {});
		const sumOfAddons = addonsDetails.reduce(
			(sum, item) => sum + (item.addl_details.premium || 0),
			0,
		);
		this.BasePremium =
			summedPremiumDetails.PolicyPremium +
			Math.abs(summedPremiumDetails.LoyaltyDiscountAmount) +
			Math.abs(summedPremiumDetails.MultiVehicleDiscountAmount) +
			Math.abs(summedPremiumDetails.NCDAmount) +
			Math.abs(summedPremiumDetails.SchemeDiscountAmount);

		this.VATAmount = summedPremiumDetails.PolicyPremium * 0.15;
		if (sumOfAddons) {
			this.VATAmount += sumOfAddons * 0.15;
		}
		this.SchemeDiscountAmount = 0;

		this.LoyaltyDiscountAmount = -Math.abs(
			summedPremiumDetails.LoyaltyDiscountAmount,
		);
		this.MultiVehicleDiscountAmount =
			summedPremiumDetails.MultiVehicleDiscountAmount;
		this.NCDAmount = summedPremiumDetails.NCDAmount;
		this.SchemeDiscountAmountMotor = -summedPremiumDetails.SchemeDiscountAmount;

		this.Premium = this.BasePremium;
		this.NetPremium = summedPremiumDetails.PolicyPremium;
		this.TotalPremium = summedPremiumDetails.PolicyPremium;
		const uniqueObjects = addonsDetails.filter(
			(obj, index, self) =>
				index === self.findIndex(o => o.add_on_code === obj.add_on_code),
		);
		const result: any = Object.values(
			addonsDetails.reduce(
				(acc: any, item) => {
					const key = item.add_on_code;
					if (!acc[key]) {
						acc[key] = { ...item };
					} else {
						acc[key].addl_details.premium += item.addl_details.premium;
					}
					return acc;
				},
				{} as Record<number, (typeof data)[0]>,
			),
		);
		result.forEach(el => {
			this.addons.push({
				coverPremium: el.addl_details.premium,
				isSelected: '',
				coverageId: el.add_on_id?.toString(),
				name:
					this.currentLang === 'en'
						? el.addl_details.cover_name
						: el.addl_details.cover_name_ar,
			});
		});
	}
}
