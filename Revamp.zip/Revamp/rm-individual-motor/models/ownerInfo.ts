interface Address {
	BuildingNumber: string;
	DistrictID: number | null;
	District: string;
	City: string;
	PostCode: string;
	AdditionalNumber: string;
	City_L2: string;
	District_L2: string;
	ObjLatLng: string;
	ShortAddress: string;
	IsPrimaryAddress: string;
	PKAddressID: string;
	CityID: string;
	RegionID: string;
	Address1: string;
	Address2: string;
	RegionName: string;
	RegionName_L2: string;
	Latitude: string;
	Longitude: string;
	CityId: string;
	RegionId: string;
}

interface OwnerInformation {
	DateOfBirthG: string;
	EnglishFirstName: string;
	EnglishLastName: string;
	EnglishSecondName: string;
	EnglishThirdName: string;
	FamilyName: string;
	FatherName: string;
	FirstName: string;
	Gender: string;
	GrandFatherName: string;
	IdIssuePlace: string;
	LogId: number;
	SocialStatusDesc: string;
	MaritalStatusDescAr: string;
	SubtribeName: string;
	MaritalStatus: string;
	address: Address;
	isAddressFound: number;
	englishFirstName: string | null;
	englishSecondName: string | null;
	englishThirdName: string | null;
	englishLastName: string | null;
	firstName: string | null;
	secondName: string | null;
	thirdName: string | null;
	lastName: string | null;
	name: string;
}

interface SPLAddress {
	BuildingNumber: string;
	Street: string;
	DistrictID: number | null;
	City: string;
	PostCode: string;
	AdditionalNumber: string;
	City_L2: string;
	Street_L2: string;
	ObjLatLng: string;
	ShortAddress: string;
	IsPrimaryAddress: string;
	PKAddressID: string;
	CityID: string;
	RegionID: string;
	Address1: string;
	Address2: string;
	RegionName: string;
	RegionName_L2: string;
	Latitude: string;
	Longitude: string;
	CityId: string;
	RegionId: string;
}

interface Data {
	language: string;
	source: string;
	nationalIdNumber: string;
	birthOfDate: string;
	emailAddress: string;
	mobileNumber: string;
	ownerInformation: OwnerInformation;
	policyStartDate: string;
	productId: string;
	insuranceType: string;
	isSpecialDiscount: boolean;
	isPetroRabighSpecialDiscount: boolean;
	isCrownPrinceDiscount: boolean;
	isArabianDrillDiscount: boolean;
	isLUCIDEmpDiscount: boolean;
	isUmAlquraEmpDiscount: boolean;
	isSDBEmpDiscount: boolean;
	isSeeraEmpDiscount: boolean;
	isNeoleapSpecialDiscount: boolean;
	agentCode: string;
	isCareemDiscount: boolean;
	clientDetails: Record<string, any>;
	redeemedPoints: number;
	splAddress: SPLAddress;
	agentCodePayment: string;
}

interface Meta {
	status: number;
	statusCode: number;
}

export interface OwnerApiResponse {
	meta: Meta;
	data: Data;
}
