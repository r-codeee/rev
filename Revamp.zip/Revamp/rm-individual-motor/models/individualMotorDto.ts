import { ParkingType } from '../enums/ParkingType';
import { TransmissionType } from '../enums/TransmissionType';

export interface ICustomerDetailsPayload {
	id_type: number;
	id_no: string;
	dob: string;
	phone_no?: string;
	source?: string;
}

export interface IVehicleDetailsPayload {
	id_type: number;
	vehicle_id_no: string;
	model_year: string;
	owner_id: string;
	policy_holder_id: string;
}
export interface ICreateQuotePayload {
	id_no: string;
	lob_id: number;
	phone_no: string;
	email_id: string;
	addl_details: {
		type: VehicleType;
		calendar_type: string;
		policy_start_date: string;
		agent_code?: string;
	};
}
export interface IUpdateQuotePayload {
	id: number;
	source: string;
	status_id: number;
	addl_details: {
		current_stage: StageType;
		is_history: boolean;
	};
}
export interface IQuoteResponse {
	id: number;
	reference_number: string;
}
export interface IQuoteSummaryResponse {
	quote_details: IQuoteSummaryDetails;
	risk_item_details: Array<any>;
	driver_details: [];
	addons_details: [];
}
export interface IQuoteRiskItemDetail {
	id: number;
	id_type: number;
	id_no: number;
	quote_id: number;
	product_code: number;
	addl_details: IQuoteRiskItemAdditionalDetails;
	premium: number;
	premium_details: IRiskPremiumDetails;
	created_date: string;
	updated_date: string;
	is_documents_uploaded: boolean;
	is_upload_documents: boolean;
	selectedPlan: any;
}
export interface IRiskPremiumDetails {
	product_code: number;
	NCDLevel: number;
	validation_messageAr: string;
	validation_code: number;
	NCDAmount: number;
	LoyaltyDiscountAmount: number;
	MultiVehicleDiscountAmount: number;
	TotalPremium: number;
	TPLBase: number;
	VATAmount: number;
	PolicyPremium: number;
	ITDPremium: number;
	NCDRate: number;
	SchemeDiscount: number;
	SchemeDiscountAmount: number;
	LoyaltyDiscount: number;
	MultiVehicleDiscount: number;
	base_premium: number;
}
export interface IQuoteRiskItemAdditionalDetails {
	make: number;
	model: number;
	vehicle_model: string;
	plate_number: string;
	plate_no: string;
	manufacturing_year: number;
	chassis_number: string;
	cylinders: number;
	lk_vehicle_class: number;
	log_id: number;
	major_color: string;
	minor_color: string;
	owner_name: string;
	plate_text1: string;
	plate_text2: string;
	plate_text3: string;
	registration_place: string;
	vehicle_body_code: number;
	vehicle_body_description: string;
	vehicle_seats: number;
	vehicle_weight: number;
	city_ar: string;
	ncd: string;
	traffic_violations_score: string;
	accidents_record_score: string;
	demographic_information_score: string;
	vehicle_information_score: string;
	lezam_score: string;
	purposeOfUsingVehicle: string;
	Min_SI: string;
	Rec_SI: string;
	Max_SI: string;
	make_en: string;
	model_en: string;
	make_ar: string;
	model_ar: string;
	body_type: string;
	no_of_seats: string;
	eska_make: string;
	eska_model: string;
	eska_body: string;
	sequenceNumber: string;
	customNumber: string;
	id_type: number;
	manual_entry: boolean;
	deductible: number;
	distanceTraveled: number;
	engineVolume: string;
	insuredValue: string;
	transmission: TransmissionType;
	vehicleRepairType: RepairType;
	numOfSeat: string;
	adaptiveCruiseCtrl: boolean;
	antiSlipBreakingSystem: boolean;
	antiTheftAlarm: boolean;
	autoBreakingSystem: boolean;
	cruiseCtrl: boolean;
	frontCamera: boolean;
	frontSensor: boolean;
	parkingDuringNight: ParkingType;
	rearCamera: boolean;
	rearParkingSensor: boolean;
	threeSixtyDegreeCamera: boolean;
	modificationToCar: boolean;
	modificationToCarDesc: string;
	vehicleLogoUrl: string;
}
export interface IQuoteSummaryDetails {
	id: number;
	reference_number: string;
	id_type: number;
	id_no: string;
	lob_id: number;
	customer_type_id: number | string;
	status_id: number;
	tenant_id: number;
	first_name: string;
	last_name: string;
	company_name: string;
	phone_country_code: '+966';
	phone_no: string;
	email_id: string;
	created_by: string;
	updated_by: string;
	owned_by: string;
	premium: string;
	region_id: number;
	branch_id: number;
	business_channel: string;
	agent_type: string;
	addl_details: IQuoteSummaryAdditionalDetails;
	premium_details: Array<IGetRateResponse>;
	eska_details: {};
	is_renewal: boolean;
	old_policy_id: string;
	old_policy_number: string;
	is_eska_renewal: boolean;
	is_ifoundry_renewal: boolean;
	nstp_process_id: string;
	nstp_cid: string;
	created_date: string;
	updated_date: string;
	is_endorsement: boolean;
	endorsement_type: string;
	channel_type_id: string;
}
export interface IQuoteSummaryAdditionalDetails {
	type: VehicleType;
	calendar_type: string;
	policy_start_date: string;
	agent_code?: string;
	address_line_1: string;
	adddress_line_2: string;
	lat_long: string;
	building_number: string;
	short_address: string;
	street: string;
	district: string;
	city: string;
	postal_code: string;
	postal_code_addl_number: string;
	region_name_en: string;
	is_primary_address: string;
	latitude: string;
	longitude: string;
	city_id: number;
	region_id: string;
	pk_address_id: string;
	district_id: string;
	region_name_ar: string;
	city_ar: string;
	street_ar: string;
	district_ar: string;
	postal_city: string;
	postal_region: string;
	drivingLicenceType: string;
	dob: string;
	date_of_birth: string;
	first_name_en: string;
	first_name_ar: string;
	last_name_en: string;
	last_name_ar: string;
	second_name_en: string;
	third_name_en: string;
	id_issued_place: string;
	marital_status: number;
	gender: number;
	occupation: number;
	nationality: string;
	marital_status_en: string;
	current_stage: StageType;
	premium_difference: number;
	old_policy_premium: number;
}
export interface ICreateRiskItemPayload {
	id_no: number;
	quote_id: number;
}
export interface IAddRiskItemPayload {
	filter: {
		quote_id: number;
	};
	orderBy: object;
	pageSize: number;
	offSet: number;
}

export interface IAddRiskItemListResponse {
	count: number;
	data: Array<IQuoteSummaryDetails>;
}
export interface IUpdateRiskItemPayload {
	id: number;
	addl_details: IRiskItemAdditionalDetails;
}

export interface IRiskItemAdditionalDetails {
	distanceTraveled: number;
	engineVolume: string;
	numOfSeat: string;
	transmission: TransmissionType;
	antiSlipBreakingSystem: boolean;
	autoBreakingSystem: boolean;
	cruiseCtrl: boolean;
	adaptiveCruiseCtrl: boolean;
	frontSensor: boolean;
	frontCamera: boolean;
	rearCamera: boolean;
	threeSixtyDegreeCamera: boolean;
	rearParkingSensor: boolean;
	modificationToCar: boolean;
	parkingDuringNight: string | number;
}
export interface ICustomerTypeIdPayload {
	customer_type_id: number | string;
}
export interface ISearchTypePayload {
	search_type: string;
}
export interface IReferenceNumberPayload {
	reference_number: string;
}
export interface IGetRateResponse {
	vehicle_id_no: number;
	plans: {
		[key: string]: IRatePlaneItem;
	};
	driver: {};
}

export interface IRatePlaneItem {
	product_code: number;
	NCDLevel: number;
	validation_messageAr: string;
	validation_code: number;
	NCDAmount: number;
	LoyaltyDiscountAmount: number;
	MultiVehicleDiscountAmount: number;
	TotalPremium: number;
	TPLBase: number;
	VATAmount: number;
	PolicyPremium: number;
	ITDPremium: number;
	NCDRate: number;
	SchemeDiscount: number;
	SchemeDiscountAmount: number;
	LoyaltyDiscount: number;
	MultiVehicleDiscount: number;
	add_ons: {
		[ket: string]: IRatePlanAddonItem;
	};
}

export interface IRatePlanAddonItem {
	cover_id: number;
	TotalPremium: number;
	PremiumVatAmount: number;
	Premium: number;
}

export interface ILinkProductPayload {
	id: number;
	product_code: number;
}

export interface ICreateAddonsPayload {
	risk_items: Array<number>;
	add_on_code: number;
	addl_details: {
		cover_name: string;
		cover_name_ar: string;
		cover_id: number;
		applicable_products: Array<IApplicableProduct>;
	};
}
export interface IApplicableProduct {
	product_id: number;
}

export interface IQuoteProductItem {
	product_id: number;
	short_name: string;
	short_name_ar: string;
	long_name: string;
	basic_coverage: Array<IQuoteBasicCoverage>;
	applicable_add_ons: Array<IQuoteAdditionAddon>;
	commission_direct_nb: number;
	renewal_direct: number;
	broker_nb_renewal: number;
	tameeni_commission: number;
	altheqa_commission: number;
	eltezam_commission: number;
	daman_commission: number;
	bcare_commission: number;
	diamond_commission: number;
}
export interface IQuoteBasicCoverage {
	cover_id: number;
	cover_name: string;
	cover_name_ar: string;
	policy_doc_desc_en: string;
	policy_doc_desc_ar: string;
}
export interface IQuoteAdditionAddon {
	cover_id: number;
	cover_name: string;
	cover_name_ar: string;
	policy_doc_desc_en: string;
	policy_doc_desc_ar: string;
}
export interface IAddonsResponseItemWithGroup {
	add_ons: Array<IAddonsResponseItem>;
	cover_group: string;
}
export class IAddonsResponseItem {
	cover_id: number;
	cover_name: string;
	cover_name_ar: string;
	applicable_products: Array<IApplicableProduct>;

	constructor(object: any = {}) {
		this.cover_id = object?.cover_id;
		this.cover_name = object?.cover_name;
		this.cover_name_ar = object?.cover_name_ar;
		this.applicable_products = object?.applicable_products?.length
			? object.applicable_products
			: [];
	}
}
export class IAddonView extends IAddonsResponseItem {
	Premium?: number;
	PremiumVatAmount?: number;
	TotalPremium?: number;

	constructor(object: any = {}) {
		super(object);
		this.cover_id = object?.cover_id;
		this.cover_name = object?.cover_name;
		this.cover_name_ar = object?.cover_name_ar;
		this.applicable_products = object?.applicable_products?.length
			? object.applicable_products
			: [];
		this.Premium = object?.Premium;
		this.PremiumVatAmount = object?.PremiumVatAmount;
		this.TotalPremium = object?.TotalPremium;
	}
}
export interface IUserInfo {
	cookie: IUserInfoCookie;
	data: IUserInfoData;
	status: boolean;
}
export interface IUserInfoCookie {
	originalMaxAge: number;
	expires: string;
	secure: boolean;
	httpOnly: boolean;
	domain: string;
	path: string;
	sameSite: string;
}
export interface IUserInfoData {
	dcp_session: boolean;
	session_created_at: string;
	session_expiry: number;
	userInfo: {
		username: string;
		id: string;
		accountName: string;
	};
	'otp-verified': boolean;
	'dcp-token': string;
	reference_number: string;
	quote_id: number;
}

export interface ICreateDriverPayload {
	driver: {
		quote_id: number;
		id_type: number;
		id_no: string;
		first_name: string;
		last_name: string;
		addl_details: {
			first_name_ar: string;
			last_name_ar: string;
			second_name_en: string;
			third_name_en: string;
			id_issued_place: string;
			marital_status: number;
			gender: number;
			occupation: string;
			nationality: string;
			address_line_1: string;
			adddress_line_2: string;
			lat_long: string;
			building_number: string;
			short_address: string;
			street: string;
			district: string;
			city: string;
			postal_code: string;
			postal_code_addl_number: string;
			region_name_en: string;
			is_primary_address: string;
			latitude: string;
			longitude: string;
			city_id: string;
			region_id: string;
			pk_address_id: string;
			district_id: null;
			region_name_ar: string;
			city_ar: string;
			street_ar: string;
			district_ar: string;
		};
	};
	risk_items: Array<number>;
}

export interface IValidateQuoteResponse {
	valid_address: boolean;
	valid_dob: boolean;
	valid_sequence_no: [
		{
			id: number;
			valid: boolean;
			updated?: boolean;
		},
	];
	statusCode: number;
}
export interface INationalAddressResponse {
	address_line_1: string;
	adddress_line_2: string;
	lat_long: string;
	building_number: string;
	short_address: string;
	street: string;
	district: string;
	city: string;
	postal_code: string;
	postal_code_addl_number: string;
	region_name_en: string;
	is_primary_address: string;
	latitude: string;
	longitude: string;
	city_id: string;
	region_id: string;
	pk_address_id: string;
	district_id: string;
	region_name_ar: string;
	city_ar: string;
	street_ar: string;
	district_ar: string;
	Name_ar: string;
	Name_en: string;
}

export enum VehicleType {
	SINGLE = 'SINGLE',
	MULTI = 'MULTI',
}
export enum RepairType {
	AGENCY = 'Agency',
	NON_AGENCY = 'Out of Agency',
}

export enum StageType {
	SINGLE_PLAN = 'SINGLE_PLAN',
	MULTI_PLAN = 'MULTI_PLAN',
}
