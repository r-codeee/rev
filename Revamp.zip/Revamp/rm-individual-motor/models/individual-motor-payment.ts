export interface QuoteDetails {
	id: number;
	reference_number: string;
	id_type: number;
	id_no: string;
	lob_id: number;
	customer_type_id: number;
	status_id: number;
	tenant_id: string | null;
	first_name: string;
	last_name: string;
	company_name: string | null;
	phone_country_code: string;
	phone_no: string;
	email_id: string;
	created_by: string | null;
	updated_by: string | null;
	owned_by: string | null;
	premium: number;
	region_id: number;
	branch_id: number;
	business_channel: string;
	agent_type: string;
	addl_details: AdditionalDetails;
	premium_details: PremiumDetails[];
	eska_details: any; // Assuming the "eska_details" is an object, adjust based on actual structure
	is_renewal: boolean | null;
	old_policy_id: string | null;
	old_policy_number: string | null;
	is_eska_renewal: boolean;
	is_ifoundry_renewal: boolean;
	nstp_process_id: string | null;
	nstp_cid: string | null;
	created_date: string;
	updated_date: string;
	is_endorsement: boolean | null;
	endorsement_type: string | null;
	channel_type_id: number;
	sme_customer_id: string | null;
}

// Additional Details for the Quote
export interface AdditionalDetails {
	type: string;
	calendar_type: string;
	policy_start_date: string;
	address_line_1: string;
	adddress_line_2: string;
	lat_long: string;
	building_number: string;
	short_address: string;
	street: string;
	district: string;
	city: string;
	postal_code: string;
	postal_code_addl_number: string;
	region_name_en: string;
	is_primary_address: string;
	latitude: string;
	longitude: string;
	city_id: number;
	region_id: string;
	pk_address_id: string;
	district_id: string | null;
	region_name_ar: string;
	city_ar: string;
	street_ar: string;
	district_ar: string;
	postal_city: string;
	postal_region: string;
	drivingLicenceType: string;
	dob: string;
	date_of_birth: string;
	first_name_en: string;
	first_name_ar: string;
	last_name_en: string;
	last_name_ar: string;
	second_name_en: string;
	third_name_en: string;
	id_issued_place: string;
	marital_status: number;
	gender: number;
	occupation: string;
	nationality: string;
	current_stage: string;
}

// Premium Details per Vehicle
export interface PremiumDetails {
	vehicle_id_no: number;
	PolicyPremium: number;
	ITDPremium: number;
	plans: Record<string, PlanDetails>;
	driver: any; // Adjust based on actual structure
}

// Plan Details for each vehicle plan
export interface PlanDetails {
	product_code: number;
	NCDLevel: number;
	validation_messageAr: string;
	validation_code: number;
	NCDAmount: number;
	LoyaltyDiscountAmount: number;
	MultiVehicleDiscountAmount: number;
	TotalPremium: number;
	TPLBase: number;
	VATAmount: number;
	PolicyPremium: number;
	ITDPremium: number;
	NCDRate: number;
	SchemeDiscount: number;
	SchemeDiscountAmount: number;
	LoyaltyDiscount: number;
	MultiVehicleDiscount: number;
	add_ons: Record<string, AddOnDetails>;
}

// Add-on details for each plan
export interface AddOnDetails {
	cover_id: number;
	TotalPremium: number;
	PremiumVatAmount: number;
	Premium: number;
}

// Risk Item Details for the vehicle
export interface RiskItemDetails {
	id: number;
	id_type: number;
	id_no: string;
	quote_id: number;
	product_code: number;
	addl_details: RiskItemAdditionalDetails;
	premium: number;
	premium_details: PremiumDetails;
	created_date: string;
	updated_date: string;
	is_documents_uploaded: boolean;
	is_upload_documents: boolean;
}

// Risk Item Additional Details
export interface RiskItemAdditionalDetails {
	make: number;
	model: number;
	vehicle_model: string;
	plate_number: string;
	plate_no: string;
	manufacturing_year: number;
	chassis_number: string;
	cylinders: number;
	lk_vehicle_class: number;
	log_id: number;
	major_color: string;
	minor_color: string;
	owner_name: string;
	plate_text1: string;
	plate_text2: string;
	plate_text3: string;
	registration_place: string;
	vehicle_body_code: number;
	vehicle_body_description: string;
	vehicle_seats: number;
	vehicle_weight: number;
	city_ar: string;
	ncd: string;
	traffic_violations_score: string;
	accidents_record_score: string;
	demographic_information_score: string;
	vehicle_information_score: string;
	lezam_score: string;
	purposeOfUsingVehicle: string;
	Min_SI: string;
	Rec_SI: string;
	Max_SI: string;
	make_en: string;
	model_en: string;
	make_ar: string;
	model_ar: string;
	body_type: string;
	no_of_seats: string;
	eska_make: string;
	eska_model: string;
	eska_body: string;
	city_id: number;
	sequenceNumber: string;
	id_type: number;
	manual_entry: boolean;
	deductible: number;
	distanceTraveled: number;
	engineVolume: string;
	insuredValue: string;
	transmission: string;
	vehicleRepairType: string;
	numOfSeat: string;
	adaptiveCruiseCtrl: boolean;
	antiSlipBreakingSystem: boolean;
	antiTheftAlarm: boolean;
	autoBreakingSystem: boolean;
	cruiseCtrl: boolean;
	frontCamera: boolean;
	frontSensor: boolean;
	parkingDuringNight: string;
	rearCamera: boolean;
	rearParkingSensor: boolean;
	threeSixtyDegreeCamera: boolean;
	modificationToCar: boolean;
	modificationToCarDesc: string;
}
export interface AddOnDetailsData {
	add_on_id: number;
	add_on_code: number;
	risk_id: string[];
	premium: number;
	addl_details: {
		cover_name: string;
		cover_name_ar: string;
		cover_id: number;
		applicable_products: {
			product_id: number;
		}[];
		premium: number;
	};
	premium_details: {
		TotalPremium: string;
		PremiumVatAmount: string;
		Premium: number;
	};
	totalCount: number;
}
export interface PaymentApiResponse {
	addons_details: AddOnDetailsData[];
	driver_details: [];
	quote_details: QuoteDetails;
	risk_item_details: RiskItemDetails[];
}
export interface QuoteUpdatePayload {
	id: number;
	source?: string;
	status_id: number;
	addl_details: AdditionalDetailsPayload;
}
interface AdditionalDetailsPayload {
	coupon_code?: string;
	agent_code?: string;
	current_stage?: string;
	is_history?: boolean;
}
export interface PaymentDecision {
	reference_number: string;
	status?: 'PP';
	comment?: string;
	source?: 'b2c';
}
export interface InitiatePayload {
	reference_number: string;
	selected_language: string;
	device_type: string;
	payment_method: string;
	frontend_cb_success_url: string;
	frontend_cb_partial_url: string;
}
