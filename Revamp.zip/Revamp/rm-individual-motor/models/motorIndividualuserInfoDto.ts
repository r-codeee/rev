import { UserInfo } from '../../rm-payment/model/payment-details';
import { QuoteDetails, RiskItemDetails } from './individual-motor-payment';
import moment from 'moment';
import { inject, Inject } from '@angular/core';
import { ARTStorageService } from '../../utils/services/shared/storage.service';
export enum Gender {
	Female = 2,
	male = 1,
}
export enum MaritalStatus {
	Single = 1,
	married = 6,
}
export class MotorIndividualuserInfoDto implements UserInfo {
	address: string;
	amount: string;
	createdAt: string;
	dateOfBirth: string;
	dateOfBirthG: string;
	email: string;
	englishFirstName: string;
	englishLastName: string;
	englishSecondName: string;
	englishThirdName: string;
	familyName: string;
	fatherName: string;
	firstName: string;
	fullName: string;
	gender: string;
	grandFatherName: string;
	groupType: string;
	id: number;
	idIssuePlace: string;
	isGuestUser: any;
	isMasterOtpVerified: any;
	isVerified: boolean;
	logId: number;
	maritalStatus: string;
	mobileNumber: string;
	nationalId: string;
	policyEndDate: string;
	policyId: any;
	policyNo: any;
	policyStartDate: string;
	productType: string;
	quotationId: any;
	quotationNo: any;
	socialStatusDesc: string;
	sourceSystem: any;
	status: any;
	subtribeName: string;
	updatedAt: string;
	emailAddress: string;
	vehcielList: any[];
	staticPlan = [
		{ PRODUCT_NAME: 'Wafi Basic', PRODUCT_CODE: 600460 },
		{ PRODUCT_NAME: 'Wafi Smart', PRODUCT_CODE: 600462 },
		{ PRODUCT_NAME: 'Comprehensive', PRODUCT_CODE: 600461 },
	];
	product_code: number;
	constructor(data: QuoteDetails, riskItemDetails: RiskItemDetails[]) {
		this.productType = '';
		this.quotationId = data.id;
		this.nationalId = data?.id_no;
		this.address =
			data.addl_details.address_line_1 +
			data.addl_details.region_name_en +
			data.addl_details.adddress_line_2;
		this.dateOfBirth = data.addl_details.date_of_birth;
		this.dateOfBirthG = data.addl_details.date_of_birth;
		this.policyStartDate = data.addl_details.policy_start_date;
		const start = moment(this.policyStartDate, 'DD-MM-YYYY');
		this.policyEndDate = start
			.add(1, 'y')
			.subtract(1, 'd')
			.format('DD-MM-YYYY');
		this.emailAddress = data.email_id;
		this.mobileNumber = data.phone_no;
		this.englishFirstName = data.first_name;
		this.englishLastName = data.last_name;
		this.englishSecondName = data.last_name;
		this.englishThirdName = data.last_name;
		this.familyName = data.last_name;
		this.fatherName = data.last_name;
		this.firstName = data.first_name;
		this.fullName = data.first_name + '  ' + data.last_name;
		this.gender = Gender[data.addl_details.gender];
		this.grandFatherName = '';
		this.idIssuePlace = data.addl_details.id_issued_place;
		this.logId = 0;
		this.vehcielList = riskItemDetails.map(data => {
			return {
				makeEn: data.addl_details.make_en,
				modelEn: data.addl_details.model_en,
				makeAr: data.addl_details.make_ar,
				modelAr: data.addl_details.model_ar,
				make: data.addl_details.make,
				eska_make: data.addl_details.eska_make,
				premium: data.premium,
				policyPremium: data.premium_details.PolicyPremium,
				coverageValue: data?.premium_details.ITDPremium,
				model: data.addl_details.model,
				vehicle_model: data.addl_details.vehicle_model,
				manufacture_year: data.addl_details.manufacturing_year,
				plate: data.addl_details.plate_number,
				color: data.addl_details.major_color,
				sequence: data.id_no,
				deductible: data.addl_details.deductible,
				repair_type: data.addl_details.vehicleRepairType,
				vehicle_value:
					data.addl_details.insuredValue || data.addl_details.Rec_SI,
				productTypr: this.staticPlan.find(
					el => el.PRODUCT_CODE === data?.product_code,
				)?.PRODUCT_NAME,
			};
		});
		this.maritalStatus = MaritalStatus[data.addl_details.marital_status];
		this.socialStatusDesc = '';
		this.subtribeName = '';
		this.productType = this.staticPlan.find(
			el => el.PRODUCT_CODE === riskItemDetails[0]?.product_code,
		)?.PRODUCT_NAME;
		this.product_code = riskItemDetails[0]?.product_code;
		// this.storage.Setvalue('policyPaymentCoverage', this.productType);
	}
}
