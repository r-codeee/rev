import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmMotorIndividualPremiumCalculationComponent } from './rm-motor-individual-premium-calculation.component';

describe('RmMotorIndividualPremiumCalculationComponent', () => {
  let component: RmMotorIndividualPremiumCalculationComponent;
  let fixture: ComponentFixture<RmMotorIndividualPremiumCalculationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmMotorIndividualPremiumCalculationComponent]
    });
    fixture = TestBed.createComponent(RmMotorIndividualPremiumCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
