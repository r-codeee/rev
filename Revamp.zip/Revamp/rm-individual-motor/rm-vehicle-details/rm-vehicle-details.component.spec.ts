import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmVehicleDetailsComponent } from './rm-vehicle-details.component';

describe('RmVehicleDetailsComponent', () => {
  let component: RmVehicleDetailsComponent;
  let fixture: ComponentFixture<RmVehicleDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmVehicleDetailsComponent]
    });
    fixture = TestBed.createComponent(RmVehicleDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
