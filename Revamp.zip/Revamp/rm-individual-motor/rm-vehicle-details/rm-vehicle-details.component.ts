import {
	AfterViewInit,
	Component,
	EventEmitter,
	Input,
	OnChanges,
	Output,
	inject,
	SimpleChanges,
} from '@angular/core';
import { CustomOption } from 'src/app/rm-cyber-insurance/models/custom-option.model';
import { CoverageType } from '../enums/CoverageType';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import * as yup from 'yup';
import { ObjectSchema } from 'yup';
import { IVehicleCoverage } from '../types/IVehicle';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { RepairType } from '../models/individualMotorDto';
import { TranslateService } from '@ngx-translate/core';

@Component({
	selector: 'art-rm-vehicle-details',
	templateUrl: './rm-vehicle-details.component.html',
	styleUrls: ['./rm-vehicle-details.component.scss'],
})
export class RmVehicleDetailsComponent
	extends BaseFormComponent<IVehicleCoverage>
	implements AfterViewInit, OnChanges
{
	@Input() vehicleFormData: IVehicleCoverage;
	@Input() selectedVehicleData: any;
	@Input() selectedVehicleRiskId: any;
	@Input() selectedCoverageType: CoverageType;
	@Input() title: string;
	@Input() maxInsured: string = '0';
	@Input() minInsured: string = '0';
	@Input() isLoading: boolean = false;

	@Output() onSubmitForm: EventEmitter<IVehicleCoverage> = new EventEmitter();
	protected translationService = inject(TranslateService);
	protected readonly String = String;

	validationSchema!: ObjectSchema<any>;

	// repairType: null,
	// deductibleAmount: null,
	// coverageValue: null,
	// marketValue: null,
	values: IVehicleCoverage = {
			distanceTraveled: null,
            engineVolume: "",
            numOfSeat: "",
            transmission: "",
            no_of_seats: "",
            antiSlipBreakingSystem: false,
            autoBreakingSystem: false,
            cruiseCtrl: false,
            adaptiveCruiseCtrl: false,
            frontSensor: false,
            frontCamera: false,
            rearCamera: false,
            threeSixtyDegreeCamera: false,
            rearParkingSensor: false,
            parkingDuringNight: "",
            antiTheftAlarm: false,
            modificationToCar: false,
            insuredValue: null,
            vehicleRepairType: "",
            deductible: null,
            coverageValue: null,
	};

	CoverageType = CoverageType;
	repairTypeOptions: Array<CustomOption> = [
		new CustomOption(this.translationService.instant('INDIVIDUAL_MOTOR.AGENCY'), RepairType.AGENCY),
		new CustomOption(this.translationService.instant('INDIVIDUAL_MOTOR.NON_AGENCY'), RepairType.NON_AGENCY),
	];

	constructor(protected formBuilderService: ArtFormBuilderService) {
		super(formBuilderService);
	}

	ngOnChanges(changes: SimpleChanges): void {
		this.createValidationSchema();
		let productCode = this.selectedVehicleData.product_code || this.selectedVehicleData.selectedPlan.product_code
		let coverageValue = this.selectedVehicleData?.premium_details?.ITDPremium || this.selectedVehicleData?.premium_details?.find(el => el.product_code == productCode).ITDPremium;
			this.vehicleFormData = {
				distanceTraveled:this.selectedVehicleData?.addl_details?.distanceTraveled,
				engineVolume:this.selectedVehicleData?.addl_details?.engineVolume,
				numOfSeat:this.selectedVehicleData?.addl_details?.numOfSeat,
				transmission:this.selectedVehicleData?.addl_details?.transmission,
				no_of_seats:this.selectedVehicleData?.addl_details?.numOfSeat,
				antiSlipBreakingSystem:this.selectedVehicleData?.addl_details?.antiSlipBreakingSystem,
				autoBreakingSystem:this.selectedVehicleData?.addl_details?.autoBreakingSystem,
				cruiseCtrl:this.selectedVehicleData?.addl_details?.cruiseCtrl,
				adaptiveCruiseCtrl:this.selectedVehicleData?.addl_details?.adaptiveCruiseCtrl,
				frontSensor:this.selectedVehicleData?.addl_details?.frontSensor,
				frontCamera:this.selectedVehicleData?.addl_details?.frontCamera,
				rearCamera:this.selectedVehicleData?.addl_details?.rearCamera,
				threeSixtyDegreeCamera:this.selectedVehicleData?.addl_details?.threeSixtyDegreeCamera,
				rearParkingSensor:this.selectedVehicleData?.addl_details?.rearParkingSensor,
				parkingDuringNight:this.selectedVehicleData?.addl_details?.parkingDuringNight,
				antiTheftAlarm:this.selectedVehicleData?.addl_details?.antiTheftAlarm,
				modificationToCar:this.selectedVehicleData?.addl_details?.modificationToCar,

				vehicleRepairType:this.selectedVehicleData?.addl_details?.vehicleRepairType,
				deductible:this.selectedVehicleData?.addl_details?.deductible
				? this.selectedVehicleData?.addl_details?.deductible
				: this.deductibleDefaultValue(
						this.selectedVehicleData?.addl_details?.Rec_SI,
					) ?? 500,
				coverageValue: coverageValue,
				insuredValue:
					this.selectedVehicleData?.addl_details?.insuredValue ||
					this.selectedVehicleData?.addl_details?.Rec_SI,
			};
			if((changes['selectedVehicleRiskId'] && changes['selectedVehicleRiskId'].currentValue != changes['selectedVehicleRiskId'].previousValue) && this.form){
				this.form.patchValue(this.vehicleFormData);
			}
	}

	ngAfterViewInit(): void {
		this.form.patchValue(this.vehicleFormData);
	}

	getDeductibleMaxValue = x => {
		x = Number(x);
		let val = 0;
		if (x > 60000) {
			val = 25000;
		}
		if (x > 45000 && x <= 60000) {
			val = 20000;
		}
		if (x > 30000 && x <= 45000) {
			val = 15000;
		}
		if (x <= 30000) {
			val = 10000;
		}
		return val;
	};

	deductibleDefaultValue = x => {
		x = Number(x);
		let val = 2000;
		if (x > 60000) {
			val = 25000;
		}
		if (x > 45000 && x <= 60000) {
			val = 20000;
		}
		if (x > 30000 && x <= 45000) {
			val = 15000;
		}
		if (x <= 30000) {
			val = 10000;
		}
		return val;
	};

	private createValidationSchema(): void {
		const minInsured = Number(this.minInsured);
		const maxInsured = Number(this.maxInsured);

		this.validationSchema = yup.object().shape({
			vehicleRepairType: yup.string().required().oneOf(Object.values(RepairType)),
			deductible: yup
				.number()
				.required()
				.min(500)
				.max(
					this.getDeductibleMaxValue(
						this.selectedVehicleData?.addl_details.insuredValue ||
							this.selectedVehicleData?.addl_details.Rec_SI,
					),
				),
			coverageValue: yup.number().required(),
			insuredValue: yup
				.number()
				.required('Sum Insured is required')
				.min(minInsured)
				.max(maxInsured),
		});
	}

	selectRepairType(value) {
		this.formBuilderService.setControlValue(this.form, 'vehicleRepairType', value);
	}

	get isSmart() {
		return this.selectedCoverageType == CoverageType.WAFI_SMART;
	}

	onSubmit(values: IVehicleCoverage): void {
		this.onSubmitForm.emit(values as IVehicleCoverage);
	}
}
