export enum TransmissionType {
	AUTOMATIC = 'Automatic',
	MANUAL = 'manual',
}
