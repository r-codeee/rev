export enum ParkingType {
	DRIVEWAY = 'Driveway',
	STREET = 'Street',
	GARAGE = 'Garage',
}
