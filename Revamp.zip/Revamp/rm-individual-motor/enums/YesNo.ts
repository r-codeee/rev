export enum YESNO {
	YES = 'yes',
	NO = 'no',
}
