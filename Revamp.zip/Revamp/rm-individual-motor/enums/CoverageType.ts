import { Comprehensive } from './../../utils/services/shared/product';
export enum CoverageType {
	TPL = 'Third Party Liability',
	WAFI_BASIC = 'WAFI Basic',
	WAFI_SMART = 'WAFI Smart',
	COMPREHENSIVE = 'Comprehensive',
}
