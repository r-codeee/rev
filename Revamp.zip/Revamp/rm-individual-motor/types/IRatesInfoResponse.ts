import { IAddons, IProductAddons, IVehicle } from './IVehicle';

export interface IRatesSummary {
	name: string;
	nameAR: string;
	totalPremuim: string;
	totalPrice: string;
	productId: string;
}

export interface IRatesInfoResponseData {
	coverage: number;
	vehicleAndDriverInfo: Array<IVehicle>;
	rateSummmary: Array<IRatesSummary>;
	ownerInformation: Array<IIndividualOwnerInformation>;
	finalRateSummary: IFinalRateSummary;
	productAddons: IProductAddons;
}

export interface IRatesInfoResponse {
	data: IRatesInfoResponseData;
}

interface IFinalRateSummary {
	basePremium: string;
	ncdAmount: string;
	premiumNCD: string;
	totalPremium: string;
	vat: string;
	loyaltyDiscountAmount: string;
	multiVehicleDiscountAmount: string;
	schemeDiscountAmount: string;
	totalDiscount: string;
	totalAddons: ITotalAddons;
	individualVehicleAmount: IIndividualVehicleAmount[];
	redeemedPoints: number;
}
interface ITotalAddons {
	sumOfAddons: number;
}

interface IIndividualVehicleAmount {
	vehicleId: string;
	totalPremium: number;
}

interface IIndividualOwnerInformation {
	DateOfBirthH: string;
	EnglishFirstName: string;
	EnglishLastName: string;
	EnglishSecondName: string;
	EnglishThirdName: string;
	FirstName: string;
	LastName: string;
	SecondName: string;
	ThirdName: string;
	DateOfBirthG: string;
}
