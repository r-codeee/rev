export interface IAddVehicleBySequenceNumber {
	sequenceNumber: string;
}

export interface IAddVehicleByOwnershipNumber {
	nationalIdNumber: string;
	sequenceNumber: string;
}

export interface IAddVehicleByCustomNumber {
	nationalIdNumber: string;
	customNumber: string;
	vehicleProductionYear: number;
}
