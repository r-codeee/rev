import { boolean } from 'yup';
import { ParkingType } from '../enums/ParkingType';
import { TransmissionType } from '../enums/TransmissionType';
import { YESNO } from '../enums/YesNo';
import { RepairType } from '../models/individualMotorDto';
import { IRatesSummary } from './IRatesInfoResponse';

export interface IVehicleInformation {
	VehicleMaker: string;
	VehicleMakerEn: string;
	VehicleModel: string;
	VehicleModelEn: string;
	PlateNumber: string;
	PlateText1: string;
	PlateText2: string;
	PlateText3: string;
	vehicleLogoUrl: string;
	customNumber: string;
}
interface IVehicleDetails {
	PLATE_NUMBER: string;
	VEHICLE_MAKE: string;
	VEHICLE_MODEL: string;
	ICONS: string;
}
export interface IRenewalVehilce {
	POLICY_ID: number;
	POLICY_NUMBER: string;
	CUSTOMER_TYPE: string;
	CUST_EMAIL_ADDRESS: string;
	CUSTOMER_NAME: string;
	CUST_CONTACT_NUMBER: number;
	POLICY_EXPIRY_DATE: string;
	POLICY_ISSUE_DATE: string;
	PRODUCT_ID: number;
	POLICY_BASE_PREMIUM: string;
	TOTAL_PREMIUM: string;
	NAJM_UPLOAD_STATUS: string;
	CREATION_DATE: string;
	UPDATED_DATE: string;
	AGENT_ID: number;
	AGENT_NAME: string;
	SEGMENT_CODE: string;
	BROKER_AGENT_ID: number;
	PRODUCT_NAME: string;
	NATIONAL_ID: string;
	DATE_OF_BIRTH: string;
	MOTOR_CATEGORY: number;
	NO_OF_VEHICLES: number;
	VEHICLE_DETAILS: string;
	DAYS_DIFFERENCE: string;
	STATUS: string;
	PLATE_NUMBER: string;
	VEHICLE_MAKE: string[];
	VEHICLE_MODEL: string[];
	ICONS: string[];
	PRODUCT_CODE: number;
}
export interface IPolicyList {
	count: number;
	customer_info: IUserInfo;
	list: IRenewalVehilce[];
	status: boolean;
	total_count: number;
}
export interface IUserInfo {
	customer_name: string;
	company_name?: string;
	contact_number: number;
	email: string;
	first_name_en: string;
	first_name_ar: string;
}
export interface ICustomerInfo {
	customer_name: string;
	contact_number: number;
	email: string;
}
export interface IVehicle {
	id?: number;
	model?: string;
	customNumber?: string;
	sequenceNumber?: string;
	coverage?: number;
	isCustom?: boolean;
	plateNo?: string;
	addons?: Array<unknown>;
	drivers?: Array<unknown>;
	vehicleMaker?: string;
	vehicleModel?: string;
	title?: string;
	vehicleProductionYear?: number;
	usageType?: number;
	fullPlatNumber?: string;
	information?: IVehicleInformation;
	selectedPlan?: IRatesSummary;
	PlateNumber?: string;
	includeAgencyCover?: 'no' | 'yes';
	sumInsured?: number;
	deductibles?: number;
	samaAdditionalInfo?: IAddCarInformation;
	vehicleId?: string;
	subjectId?: string;
	rateSummmary?: Array<IRatesSummary>;
	usageTypePlateDescription?: string;
	id_no?: number;
}

// repairType: RepairType;
// deductibleAmount: number;
// coverageValue: number;
// marketValue: number;

export interface IVehicleCoverage {
	distanceTraveled: number;
	engineVolume: string;
	numOfSeat: string;
	transmission: string;
	no_of_seats: string;
	antiSlipBreakingSystem: boolean;
	autoBreakingSystem: boolean;
	cruiseCtrl: boolean;
	adaptiveCruiseCtrl: boolean;
	frontSensor: boolean;
	frontCamera: boolean;
	rearCamera: boolean;
	threeSixtyDegreeCamera: boolean;
	rearParkingSensor: boolean;
	parkingDuringNight: string;
	antiTheftAlarm: boolean;
	modificationToCar: boolean;
	vehicleRepairType: string;
	deductible: number;
	coverageValue: number;
	insuredValue: number;
}

export interface IAddCarInformation {
	transmission: TransmissionType;
	parking: ParkingType;
	modification: string;
	isModification: boolean;
}

export interface IAddDriverFormValues {
	nationalIdNumber: string;
	dateOfBirth: Date;
	ignoreAddressError: boolean;
	manualAddress: unknown;
	address: number;
	riskItems: [];
}
export interface IAddDriver {
	nationalIdNumber: string;
	dateOfBirth: Date;
	riskItems: number[];
}

export interface IAddons {
	vehicleId: string;
	id: string;
	name: string;
	description: string;
	price: string;
	Title: string;
	ItemID: string;
	Alt: string;
	Image: string;
	active: boolean;
	isAllSelected: boolean;
	isSelected: boolean;
}
export interface IProductAddons {
	productId: string;
	addons: IAddons[];
}
