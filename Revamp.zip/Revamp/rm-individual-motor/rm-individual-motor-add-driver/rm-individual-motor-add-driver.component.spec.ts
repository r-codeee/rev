import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorAddDriverComponent } from './rm-individual-motor-add-driver.component';

describe('RmIndividualMotorAddDriverComponent', () => {
  let component: RmIndividualMotorAddDriverComponent;
  let fixture: ComponentFixture<RmIndividualMotorAddDriverComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorAddDriverComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorAddDriverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
