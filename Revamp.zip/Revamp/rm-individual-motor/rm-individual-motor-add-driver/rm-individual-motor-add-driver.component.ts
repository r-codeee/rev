import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';
import {
	Component,
	ElementRef,
	EventEmitter,
	Input,
	OnChanges,
	Output,
	SimpleChanges,
	TemplateRef,
	ViewChild,
	ViewContainerRef,
} from '@angular/core';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import { ObjectSchema } from 'yup';
import * as yup from 'yup';
import { IAddDriver, IAddDriverFormValues } from '../types/IVehicle';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { UtilityService } from 'src/app/utils/services/shared/utility.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonModalComponent } from 'src/app/design-system/common-modal/rm-common-modal.component';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { ICustomerDetailsPayload } from '../models/individualMotorDto';
import moment from 'moment';

@Component({
	selector: 'art-rm-individual-motor-add-driver',
	templateUrl: './rm-individual-motor-add-driver.component.html',
	styleUrls: ['./rm-individual-motor-add-driver.component.scss'],
})
export class RmIndividualMotorAddDriverComponent
	extends BaseFormComponent<IAddDriver>
	implements OnChanges
{
	protected readonly IconComponent = IconComponent;
	@Input() quotaId = '';
	@Input() selectedVehicleRiskId;
	@Input() nationalIdLabelKey = '';
	@Input() nationalIdSubLabelKey = '';
	@Input() driverListFull = [];
	driverList = [];
	@Input() vehicleList = [];
	serverErrMsg = '';
	drivers = [];
	vehiclesOptions = [];
	selectedVehicles = [];
	currentDOB = '';
	isLoading = false;

	validationSchema: ObjectSchema<IAddDriver> = yup.object().shape({
		nationalIdNumber: this.validationRulesService.nationalIdValidationRule2(),
		dateOfBirth: this.validationRulesService.dateOfBirthValidationRule(),
		riskItems: yup.array().required(),
	});

	values: IAddDriver = {
		nationalIdNumber: '',
		dateOfBirth: null,
		riskItems: [],
	};

	@Output() onSubmitForm: EventEmitter<boolean> = new EventEmitter();
	@Output() onRemoveDriver: EventEmitter<any> = new EventEmitter();
	@Output() onUnlinkDriver: EventEmitter<any> = new EventEmitter();

	currentLang: string;

	@ViewChild('multiVehicles') tooltipTemplate!: TemplateRef<any>;
	private overlayRef!: OverlayRef;

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private validationRulesService: ArtValidationRulesService,
		private utilService: UtilityService,
		private individualMotorService: IndividualMotorService,
		private ngbModal: NgbModal,
		private overlay: Overlay,
		private viewContainerRef: ViewContainerRef,
	) {
		super(formBuilderService);
		const lang = localStorage.getItem('selectedLang');
		this.currentLang = lang || 'en';
	}
	ngOnChanges(changes: SimpleChanges): void {
		console.info(this.vehicleList);
		this.vehiclesOptions = this.vehicleList.map(el => {
			return {
				make_en: el.addl_details.make_en,
				make_ar: el.addl_details.make_ar,
				plateNumber: el.addl_details.plate_number,
				id: el.id,
			};
		});
		if (changes['driverListFull'] && (changes['driverListFull']?.currentValue != changes['driverListFull']?.previousValue)) {
			if(this.driverListFull.length > 0){
				this.driverList = this.driverListFull;
				this.driverList.forEach(driver => {
					driver.risk_items = driver.risk_items.map(id =>
						this.vehicleList.find(obj => obj.id == id),
					);
				});
				this.driverList =  this.driverList.filter(
					(item: any) =>
						item.risk_items.filter((vehi: any) => vehi.id == parseInt(this.selectedVehicleRiskId) ).length >0,
				);
			}else{
				this.driverList = []
			}
			console.log(this.driverList)	
		}

		if (changes['selectedVehicleRiskId']?.currentValue != changes['selectedVehicleRiskId']?.previousValue) {
			if(this.driverListFull.length > 0){
				this.driverList =  this.driverListFull.filter(
					(item: any) =>
						item.risk_items.filter((vehi: any) => vehi.id == parseInt(this.selectedVehicleRiskId) ).length >0,
				);
			}else{
				this.driverList = []
			}
			console.log(this.driverList)	
		}
	}
	resetform() {
		this.form.reset();
	}

	onSelectVehicle(values) {
		this.selectedVehicles = values;
		this.form.get('riskItems').patchValue([...this.selectedVehicles]);
		this.form.updateValueAndValidity();
		this.serverErrMsg = '';
	}

	onSubmit(values: IAddDriver): void {
		const data = { ...values, riskItems: [...this.selectedVehicles] };
		console.info(data);
		this.individualMotorService.refresh.next(true)
		if (this.selectedVehicles.length > 0) {
			this.isLoading = true;
			this.getCustomerDetails(data).then(res => {
				const payload: any = {
					driver: {
						quote_id: this.quotaId,
						id_no: data.nationalIdNumber,
						first_name: res.customer_details.first_name_en,
						last_name: res.customer_details.last_name_en,
						id_type: 1,
						addl_details: { ...res.customer_details, ...res.address_details },
					},
					risk_items: this.selectedVehicles,
				};
				this.createDriver(payload)
					.then(res => {
						if (res?.message) {
							this.serverErrMsg = res?.message;
						} else {
							this.onSubmitForm.emit(true);
						}
						this.isLoading = false;
					})
					.catch(err => {
						this.serverErrMsg = err?.message;
						this.isLoading = false;
					})
					.finally(() => (this.isLoading = false));
			});
			this.resetform();
		}
	}

	getCustomerDetails(data: IAddDriver): Promise<any> {
		return new Promise((resolve, reject) => {
			const payload: ICustomerDetailsPayload = {
				id_no: data.nationalIdNumber,
				dob: moment(data.dateOfBirth).format('MM-YYYY'),
				id_type: 1,
			};
			this.individualMotorService.getCustomerDetails(payload).subscribe({
				next: res => {
					resolve(res);
				},
				error: err => {
					this.isLoading = false;
					this.serverErrMsg = err?.error?.error_msg?.error;
				},
			});
		});
	}

	createDriver(payload: any): Promise<any> {
		return new Promise((resolve, reject) => {
			this.individualMotorService.createDriver(payload).subscribe({
				next: res => {
					resolve(res);
				},
				error: err => {
					this.isLoading = false;
					this.serverErrMsg = err?.message;
				},
			});
		});
	}

	removeDriver(value: any) {
		let deleteModalRef = this.ngbModal.open(CommonModalComponent, {
			centered: true,
			windowClass: 'custom-common-model-width',
		});
		deleteModalRef.componentInstance.btncustomClasses = 'background-bg-error';
		deleteModalRef.componentInstance.variant = 'error';
		deleteModalRef.componentInstance.fontAwesomeClass =
			'fa-solid fa-triangle-exclamation';
		deleteModalRef.componentInstance.btnConfirmLabel = 'COMMON.CONFRIM_DELETE';
		deleteModalRef.componentInstance.btnCloseLabel = 'COMMON.CANCEL_DELETE';
		deleteModalRef.componentInstance.desc = 'INDIVIDUAL_MOTOR.DELETE_CONFIRM';
		deleteModalRef.result.then(
			data => {
				// on close

				this.deleteDriver(value)
					.then(() => {
						this.onRemoveDriver.emit(true);
					})
					.catch(err => {
						this.serverErrMsg = err.error_msg;
						this.onRemoveDriver.emit(false);
					});
			},
			reason => {
				// on dismiss
				console.log('reason', reason);
			},
		);
	}

	unlinkDriver(value) {
		this.individualMotorService.unlinkDriver(value).subscribe({
			next: res => {
				this.onUnlinkDriver.emit(true);
			},
			error: err => {
				this.onUnlinkDriver.emit(false);
			},
		});
	}

	deleteDriver(driverId: any): Promise<void> {
		const payload = {
			id: driverId,
		};
		return new Promise((resolve, reject) => {
			this.individualMotorService.deleteDriver(payload).subscribe({
				next: res => {
					resolve(res);
				},
				error: err => {
					this.isLoading = false;
					this.serverErrMsg = err.error_msg;
				},
			});
		});
	}

	getVehicaleMake(data) {
		return this.currentLang == 'en'
			? data.risk_items[0].addl_details.make_en +
					' - ' +
					data.risk_items[0].addl_details.model_en
			: data.risk_items[0].addl_details.make_ar +
					' - ' +
					data.risk_items[0].addl_details.model_ar;
	}

	getVehicalePlateNumber(data) {
		return data.risk_items[0].addl_details.plate_number;
	}

	showTooltip(origin: ElementRef) {
		if (!this.overlayRef) {
			this.overlayRef = this.overlay.create({
				positionStrategy: this.overlay
					.position()
					.flexibleConnectedTo(origin)
					.withPositions([
						{
							originX: 'center',
							originY: 'top',
							overlayX: 'center',
							overlayY: 'bottom',
						},
					]),
				hasBackdrop: false,
			});
		}

		const tooltipPortal = new TemplatePortal(
			this.tooltipTemplate,
			this.viewContainerRef,
		);
		this.overlayRef.attach(tooltipPortal);
	}

	hideTooltip() {
		this.overlayRef?.detach();
	}

	onInputChange(value) {
		this.serverErrMsg = '';
	}
}
