import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorQuotationComponent } from './rm-individual-motor-quotation.component';

describe('RmIndividualMotorQuotationComponent', () => {
  let component: RmIndividualMotorQuotationComponent;
  let fixture: ComponentFixture<RmIndividualMotorQuotationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorQuotationComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorQuotationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
