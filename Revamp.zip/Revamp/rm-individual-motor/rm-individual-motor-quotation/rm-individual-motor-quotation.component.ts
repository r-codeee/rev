import { Component, inject, Input } from '@angular/core';
import { IPlanCard } from 'src/app/rm-shared-components/types/PlanCard';
import { IndividualMotorService } from '../services/individual-motor.service';

@Component({
	selector: 'app-rm-individual-motor-quotation',
	templateUrl: './rm-individual-motor-quotation.component.html',
	styleUrls: ['./rm-individual-motor-quotation.component.scss'],
})
export class RmIndividualMotorQuotationComponent {
	breadcrumbItems = [
		{ label_ar: 'الرئيسية', label_en: 'Home', link: '/' },
		{
			label_ar: 'منتجات الأفراد',
			label_en: 'Individual Products',
			link: '/revamp-individual-motor',
		},
		{
			label: 'Motor Insurance',
			label_en: 'Motor Insurance',
			label_ar: 'تأمين السيارات',
			link: '/revamp-individual-motor/quotation',
		},
	];

	currentUrl = 'revamp-individual-motor/quotation';
	private individualMotor = inject(IndividualMotorService);
	addCarMethods = this.individualMotor.ADD_CAR_METHODS;
	plans = this.individualMotor.PLANS.slice(-2);

	@Input() customClass = '';
	@Input() bgColor = '';
	@Input() imgUrl = '';
	@Input() title = '';
}
