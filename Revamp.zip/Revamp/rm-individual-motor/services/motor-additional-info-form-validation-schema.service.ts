import { inject, Injectable } from '@angular/core';
import * as yup from 'yup';
import { TransmissionType } from '../enums/TransmissionType';
import { IRiskItemAdditionalDetails } from '../models/individualMotorDto';
import { ParkingType } from '../enums/ParkingType';

@Injectable()
export class MotorAdditionalInfoFormValidationSchemaService {
	createAddionalInfoValidationSchema(): yup.ObjectSchema<IRiskItemAdditionalDetails> {
		return yup.object().shape({
			transmission: yup
				.string()
				.required()
				.oneOf(Object.values(TransmissionType)),
			parkingDuringNight: yup
				.string()
				.required()
				.oneOf(Object.values(ParkingType)),
			distanceTraveled: yup.number().notRequired().max(500000),
			engineVolume: yup.string().notRequired(),
			numOfSeat: yup.string().notRequired(),
			antiSlipBreakingSystem: yup.boolean().notRequired(),
			autoBreakingSystem: yup.boolean().notRequired(),
			cruiseCtrl: yup.boolean().notRequired(),
			adaptiveCruiseCtrl: yup.boolean().notRequired(),
			frontSensor: yup.boolean().notRequired(),
			frontCamera: yup.boolean().notRequired(),
			rearCamera: yup.boolean().notRequired(),
			threeSixtyDegreeCamera: yup.boolean().notRequired(),
			modificationToCar: yup.boolean().notRequired(),
			rearParkingSensor: yup.boolean().notRequired(),
		});
	}
}
