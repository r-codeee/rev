import { inject, Injectable } from '@angular/core';
import * as yup from 'yup';
import { AddNewCarMethods } from '../enums/AddNewCarMethods';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import { TransmissionType } from '../enums/TransmissionType';

@Injectable({
	providedIn: 'root', // If using providedIn: 'root', no need to explicitly add it to providers in modules
})
export class IndividualMotorQuotationFormValidationSchemaService {
	AddNewCarMethods: AddNewCarMethods;
	artValidationRulesService = inject(ArtValidationRulesService);

	createIndividualMotorQuotationValidationSchema() {
		return yup.object().shape({
			nationalId: this.artValidationRulesService.nationalIdValidationRule2(),
			dateOfBirth: this.artValidationRulesService.dateOfBirthValidationRule(),
			mobileNumber: this.artValidationRulesService.phoneNumberValidationRule(),
			email: this.artValidationRulesService.emailIdValidationRule(),
			agentCode: yup
				.string()
				.optional()
				.matches(/^[a-zA-Z0-9]*$/i),
			multiVehicle: yup.boolean().optional(),
			[AddNewCarMethods.SEQUENCE_NUMBER]: yup
				.boolean()
				.when(['nationalId', 'dateOfBirth', 'mobileNumber', 'email'], {
					is: (
						nationalId: string,
						dateOfBirth: Date,
						mobileNumber: number,
						email: string,
					) => Boolean(nationalId || dateOfBirth || mobileNumber || email),
					then: schema => schema.required(),
					otherwise: schema => schema.notRequired(),
				}),
			[AddNewCarMethods.OWNERSHIP_TRANSFER]: yup
				.boolean()
				.when(['nationalId', 'dateOfBirth', 'mobileNumber', 'email'], {
					is: (
						nationalId: string,
						dateOfBirth: Date,
						mobileNumber: number,
						email: string,
					) => Boolean(nationalId || dateOfBirth || mobileNumber || email),
					then: schema => schema.required(),
					otherwise: schema => schema.notRequired(),
				}),
			// [AddNewCarMethods.CUSTOM_NUMBER]: yup.boolean().required(),
			[AddNewCarMethods.CUSTOM_NUMBER]: yup
				.boolean()
				.when(['nationalId', 'dateOfBirth', 'mobileNumber', 'email'], {
					is: (
						nationalId: string,
						dateOfBirth: Date,
						mobileNumber: number,
						email: string,
					) => Boolean(nationalId || dateOfBirth || mobileNumber || email),
					then: schema => schema.required(),
					otherwise: schema => schema.notRequired(),
				}),

			iqamaNo: yup.string().when(AddNewCarMethods.OWNERSHIP_TRANSFER, {
				is: true,
				then: schema => schema.required().matches(/^[0-9]*$/),
				otherwise: schema => schema.notRequired(),
			}),

			sequenceNumber: yup
				.string()
				.when(
					[
						AddNewCarMethods.SEQUENCE_NUMBER,
						AddNewCarMethods.OWNERSHIP_TRANSFER,
					],
					{
						is: (seqNum, ownershipTransfer) =>
							seqNum === true || ownershipTransfer === true,
						then: schema =>
							schema
								.max(10)
								.matches(/^[0-9]*$/)
								.required(),
						otherwise: schema => schema.notRequired(),
					},
				),
			policyStartDate: yup.date().min(new Date()).required(),
			customNumber: yup.string().when(AddNewCarMethods.CUSTOM_NUMBER, {
				is: true,
				then: schema =>
					schema
						.max(10)
						.matches(/^[0-9]*$/)
						.required(),
				otherwise: schema => schema.notRequired(),
			}),

			vehicleProductionYear: yup
				.string()
				.when([AddNewCarMethods.CUSTOM_NUMBER], {
					is: true,
					then: schema => schema.required().matches(/^[0-9]{4}$/),
					otherwise: schema => schema.notRequired(),
				}),
		});
	}
	createRenewalValidationSchema() {
		return yup.object().shape({
			nationalId: this.artValidationRulesService.nationalIdValidationRule(),
			dateOfBirth: this.artValidationRulesService.dateOfBirthValidationRule(),
		});
	}
	createUpdateInformationValidationSchema() {
		return yup.object().shape({
			nationalAddress: yup.string().required(),
			dateOfBirth: this.artValidationRulesService.dateOfBirthValidationRule(),
		});
	}
	createUpdateSequenceNumverValidationSchema() {
		return yup.object().shape({
			sequenceNumber: yup
				.string()
				.min(9)
				.max(10)
				.matches(/^[0-9]*$/)
				.required(),
		});
	}
}
