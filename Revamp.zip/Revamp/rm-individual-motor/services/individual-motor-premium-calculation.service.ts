import { Injectable } from '@angular/core';

@Injectable({
	providedIn: 'root',
})
export class IndividualMotorPremiumCalculationService {
	constructor() {}

	initializeProduct(
		riskItemDetails: any,
		rateResponse: any,
		products: any,
		mode?: string,
	) {
		// Update every risk item in riskItemDetails
		return riskItemDetails.map(riskItem => {
			// Find the matching premium detail by vehicle_id_no
			if (
				riskItem.selectedPlan === undefined ||
				riskItem.selectedPlan === null
			) {
				const filteredValidRates = this.getFilteredValidRates(
					rateResponse,
					products,
				);
				const filteredValidRatesForCarSelected =
					this.drawProductForSelectedVehicle(
						filteredValidRates,
						riskItem.id_no,
					);

				const HigherPlan =
					filteredValidRatesForCarSelected &&
					this.getHigherPlan(filteredValidRatesForCarSelected);

				const PolicyPremium = riskItem.premium_details.PolicyPremium;
				// Return updated risk item with selected plan and premium details if a match is found
				return {
					...riskItem,
					selectedPlan: riskItem.product_code
						? {
								...products.find(el => el.product_id == riskItem.product_code),
								PolicyPremium,
							}
						: { ...HigherPlan, PolicyPremium },
					premium_details: filteredValidRatesForCarSelected
						? filteredValidRatesForCarSelected
						: null, // Handle case where no match is found
				};
			}
		});
	}

	drawProductForSelectedVehicle(
		filteredValidRates,
		selecvtedVehicleDataID: any,
	) {
		return filteredValidRates?.find(
			premiumDetail => premiumDetail.vehicle_id_no === selecvtedVehicleDataID,
		)?.plans;
	}

	getFilteredValidRates(rateReponse, products) {
		const filteredRates = rateReponse
			.map(
				(vehicle: {
					plans: { [s: string]: unknown } | ArrayLike<unknown>;
					vehicle_id_no: any;
				}) => {
					// Filter plans with validation_code === 0
					const validPlans = Object.values(vehicle.plans)
						.filter((plan: any) => plan.validation_code === 0)
						.map((plan: any) => {
							// Find the matching product by product_code
							const matchingProduct = products.find(
								product => product.product_id === plan.product_code,
							);

							// Merge the product data with the plan
							return {
								...plan,
								...(matchingProduct || null), // Include product data or null if no match
							};
						});

					return {
						vehicle_id_no: vehicle.vehicle_id_no,
						plans: validPlans,
					};
				},
			)
			.filter(vehicle => vehicle.plans.length > 0);

		return filteredRates;
	}

	getHigherPlan(plans) {
		if (!Array.isArray(plans) || plans.length === 0) {
			throw new Error('plans must be a non-empty array.');
		}
		return plans.reduce((highest, current) => {
			if (current.PolicyPremium > highest.PolicyPremium) {
				return current;
			} else {
				return highest;
			}
		});
	}
}
