import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { cloneDeep } from 'lodash';
import pick from 'lodash/pick';
import { firstValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';

import { IRatesInfoResponse } from 'src/app/rm-individual-motor/types/IRatesInfoResponse';
import { IVehicle } from 'src/app/rm-individual-motor/types/IVehicle';

import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { environment } from 'src/environments/environment';

@Injectable({
	providedIn: 'root',
})
export class MultiMotorService {
	motorMultiApi = `${environment.motorPurchaseApi}/v1/multiMotorPolicies`;
	private http = inject(HttpClient);
	private individualMotorService = inject(IndividualMotorService);

	constructor(private languageService: RMLanguageService) {}

	updateMultiMotorPurchaseDetails(payload) {
		const headers = {
			language: this.languageService.activeLang(),
		};
		return this.http
			.post(this.motorMultiApi, payload, {
				headers,
			})
			.pipe(catchError(this.individualMotorService.errorHandler));
	}

	constructUpdateMultiMotorPayload({
		addCarFormValues,
		storageData,
		existedVehicleList,
		newVehicleInfo,
	}) {
		const newCarInfo = cloneDeep(newVehicleInfo.data);
		if ('customNumber' in addCarFormValues) {
			newCarInfo.customNumber = addCarFormValues.customNumber;
			newCarInfo.isCustom = true;
			newCarInfo.title = 'CustomNo';
		}
		return {
			...pick(storageData, [
				'agentCode',
				'dateOfBirth',
				'emailAddress',
				'insuranceType',
				'mobileNumber',
				'nationalId',
				'policyStartDate',
				'privacyPolicyConsent',
			]),
			source: 'web',
			vehicleType: 'multi',
			vehicles: [
				...existedVehicleList.map((vehicle: IVehicle) =>
					pick(vehicle, [
						'customNumber',
						'vehicleMaker',
						'vehicleModel',
						'isCustom',
						'vehicleProductionYear',
						'title',
						'addons',
						'usageType',
						'drivers',
					]),
				),
				{
					...pick(newCarInfo, [
						'VehicleMaker',
						'VehicleModel',
						'customNumber',
						'isCustom',
						'title',
					]),
					addons: [],
					drivers: [],
					usageType: 283,
					vehicleProductionYear: newCarInfo.ModelYear,
				},
			],
		};
	}
}
