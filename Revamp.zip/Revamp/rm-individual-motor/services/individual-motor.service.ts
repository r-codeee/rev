import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal, WritableSignal } from '@angular/core';
import {
	BehaviorSubject,
	catchError,
	firstValueFrom,
	map,
	Observable,
	of,
	retry,
	Subject,
	throwError,
} from 'rxjs';
import { ICardData } from 'src/app/design-system/motor-card-with-radio/motor-card-with-radio.component';
import { AddNewCarMethods } from 'src/app/rm-individual-motor/enums/AddNewCarMethods';
import {
	IAddVehicleByCustomNumber,
	IAddVehicleBySequenceNumber,
} from 'src/app/rm-individual-motor/types/IAddNewVehicle';
import {
	IPolicyList,
	IVehicle,
	IVehicleInformation,
} from 'src/app/rm-individual-motor/types/IVehicle';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { PlanCardType } from 'src/app/rm-shared-components/enums/PlanCardType';
import { HttpHelpersService } from 'src/app/rm-shared-components/services/http-helpers.service';
import { IPlanCard } from 'src/app/rm-shared-components/types/PlanCard';
import { isLoaderNotReq } from 'src/app/utils/services/shared/loader-interceptor.service';
import { environment } from 'src/environments/environment';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { RateDetails, UserInfo } from '../../rm-payment/model/payment-details';
import {
	InitiatePayload,
	PaymentApiResponse,
	PaymentDecision,
	QuoteUpdatePayload,
} from '../models/individual-motor-payment';
import { MotorIndividualuserInfoDto } from '../models/motorIndividualuserInfoDto';
import { PaymentSummaryMotorIndividualDto } from '../models/paymentSummaryMotorIndividualDto';
import { IRatesInfoResponse } from '../types/IRatesInfoResponse';
import {
	isApigeeAuthCodeAPI,
	isIndividualMotorAPI,
	isIvidualMotorEndorsementsAPI,
	isRevampMotorSMEAPI,
} from 'src/app/utils/helpers/token-interceptor.service';
import { LOGIN } from 'src/app/shared/app.constant';
import {
	IAddonsResponseItem,
	IAddonsResponseItemWithGroup,
	IAddRiskItemListResponse,
	IAddRiskItemPayload,
	ICreateAddonsPayload,
	ICreateDriverPayload,
	ICreateQuotePayload,
	ICreateRiskItemPayload,
	ICustomerDetailsPayload,
	ICustomerTypeIdPayload,
	IGetRateResponse,
	ILinkProductPayload,
	INationalAddressResponse,
	IQuoteProductItem,
	IQuoteSummaryResponse,
	IReferenceNumberPayload,
	ISearchTypePayload,
	IUpdateQuotePayload,
	IUpdateRiskItemPayload,
	IUserInfo,
	IValidateQuoteResponse,
	IVehicleDetailsPayload,
} from '../models/individualMotorDto';
import { boolean, string } from 'yup';
import { DropdownOptionType } from 'src/app/design-system/types/DropdownOptionType';
import { ParkingType } from '../enums/ParkingType';
import {
	ADD_CAR_METHODS,
	ENGINE_VOLUME_OPTIONS,
	NUM_OF_SEAT_OPTIONS,
	PARKING_OPTIONS,
	PLANS,
} from '../constants/constant';
import { tap } from 'rxjs/operators';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import {
	PaymentMethodStructure,
	PaymentTypes,
} from '../../rm-payment/model/paymentMethodTypes';
import {
	otherPayment,
	PaymentCards,
	paymentMethodsGeneral,
	wallets,
} from '../../rm-payment/config/payment-methods-list.config';

@Injectable({
	providedIn: 'root',
})
export class IndividualMotorService {
	STORAGE_KEY = 'individualMotorSession';
	motorPurchaseApi = `${environment.motorPurchaseApi}/v1/motorPolicies`;
	loopbackApi = `${environment.loopbackApi}`;
	neutrinousApi = environment.neutrinosApi;
	addAddons$ = new Subject();
	isAddonsAdded = new Subject<{ isAdded: boolean; cover_id: number }>();
	private http = inject(HttpClient);
	private httpHelpersService = inject(HttpHelpersService);
	protected languageService = inject(RMLanguageService);
	protected storage = inject(ARTStorageService);
	protected authService = inject(AuthService);
	activePolicyRefId: WritableSignal<string> = signal(
		this.storage.GetValue(this.STORAGE_KEY)?.referenceId,
	);
	siteCoreBaseUrl: string = environment.sitecoreApi;
	currentLang = this.languageService.activeLang();
	ADD_CAR_METHODS: Array<ICardData> = ADD_CAR_METHODS;
	PLANS: Array<IPlanCard> = PLANS;
	parkingOptions: Array<DropdownOptionType> = PARKING_OPTIONS;
	numOfSeatOptions: Array<DropdownOptionType> = NUM_OF_SEAT_OPTIONS;
	engineVolumeOptions: Array<DropdownOptionType> = ENGINE_VOLUME_OPTIONS;
	checkMokaff = new Subject();
	addonsData = new BehaviorSubject({});
	refresh = new BehaviorSubject(false);

	getdistanceTraveledOptions(
		max: number = 500000,
		step: number = 10,
	): Array<DropdownOptionType> {
		const distanceTraveledOptions: Array<DropdownOptionType> = [];
		for (let i = 0; i <= max; i += step) {
			distanceTraveledOptions.push({ Name_en: `${i}`, Id: i, value: i });
		}

		return distanceTraveledOptions;
	}

	getCarLogos() {
		return this.http.get<any>(this.motorPurchaseApi + '/carLogos');
	}

	getVehicleMakersFromDCP() {
		const lang = this.currentLang === 'en' ? 'E' : 'A';

		return this.http
			.get<any>(
				`${environment.motorPurchaseApi}` + '/v1/vehicleMakes?language=' + lang,
				{
					context: isLoaderNotReq(),
				},
			)
			.pipe(
				map(response => {
					return response.data.filter(
						item =>
							item.MakeID !== '' &&
							item.MakeNameEN !== '' &&
							item.MakeNameAR !== '',
					);
				}),
				catchError(this.errorHandler),
			);
	}

	getVehicleInfo(
		vehicleParams: IAddVehicleBySequenceNumber | IAddVehicleByCustomNumber,
	) {
		const params = this.httpHelpersService.toHttpParams(vehicleParams);

		return this.http
			.get(this.motorPurchaseApi + '/vehicleInfo', {
				headers: { language: 'en' },
				params,
			})
			.pipe(catchError(this.errorHandler));
	}

	// {userInfo:UserInfo,paymentInfo:RateDetails}

	getPaymentDetails(body: { reference_number: string }): Observable<any> {
		return this.http
			.post<PaymentApiResponse>(this.neutrinousApi + 'quote/summary/v1', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(
				map(
					payment => ({
						userInfo: new MotorIndividualuserInfoDto(
							payment.quote_details,
							payment.risk_item_details,
						),
						paymentInfo: new PaymentSummaryMotorIndividualDto(
							payment.risk_item_details,
							payment.addons_details,
						),
					}),
					catchError(this.errorHandler),
				),
			);
	}
	getCarsDetails(body: {
		reference_number: string;
	}): Observable<IQuoteSummaryResponse> {
		return this.http.post<IQuoteSummaryResponse>(
			this.neutrinousApi + 'quote/summary/v2',
			body,
			{
				context: isIndividualMotorAPI(),
				withCredentials: true,
			},
		);
	}
	updateQuotation(body: QuoteUpdatePayload): Observable<any> {
		return this.http
			.post<{ id: number; reference_number: string }>(
				this.neutrinousApi + 'quote/update',
				body,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(map(payment => catchError(this.errorHandler)));
	}
	getPaymentOption(reference_number: string): Observable<any> {
		return this.http
			.post<{ device_type: ''; reference_number: string }>(
				this.neutrinousApi + 'payment/options',
				{ device_type: '', reference_number: reference_number },
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(
				map((res: any) => {
					const paymentMethod: PaymentMethodStructure = {
						otherMethods: [],
						cards: [],
						wallet: [],
					};
					const mappingDictionary: { [key: string]: string } = {
						AMEX: 'AMEX',
						EMKAN: 'Emkan',
						MADA: 'MADA',
						MASTER: 'MASTER',
						MOKAFAA: 'Mokafaa',
						SADAD_VS: 'Sadad',
						STC_PAY: 'STC',
						TABBY: 'Tabby',
						URPAY: 'urpay',
						VISA: 'VISA',
					};

					const mappedArray = res[0].payment_options.map(item => ({
						...item,
						payment_type:
							mappingDictionary[item.payment_type] || item.payment_type,
					}));
					mappedArray.forEach(payment => {
						if (PaymentCards.includes(payment.payment_type)) {
							paymentMethod.cards = paymentMethodsGeneral.payment.cards;
						}
						if (otherPayment.includes(payment.payment_type)) {
							paymentMethod.otherMethods.push(
								paymentMethodsGeneral.payment[payment.payment_type],
							);
						}
						if (wallets.includes(payment.payment_type)) {
							paymentMethod.wallet.push(
								paymentMethodsGeneral.payment[payment.payment_type],
							);
						}
					});
					return paymentMethod;
				}),
				catchError(this.errorHandler),
			);
	}

	paymentDecision(body: PaymentDecision): Observable<any> {
		return this.http
			.post(this.neutrinousApi + 'quote/customer/decision', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(map(payment => catchError(this.errorHandler)));
	}
	paymentInitiate(body: InitiatePayload): Observable<any> {
		return this.http
			.post(this.neutrinousApi + 'payment/initiate', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(tap(payment => catchError(this.errorHandler)));
	}
	autherizeMokafaa(body: any): Observable<any> {
		return this.http
			.post(this.neutrinousApi + 'v1/mokafaa/authorize', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(tap(payment => catchError(this.errorHandler)));
	}

	validateOtpOfMokafaa(body: any): Observable<any> {
		return this.http
			.post(this.neutrinousApi + 'v1/mokafaa/otp_validation', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(tap(payment => catchError(this.errorHandler)));
	}
	paymentEnquiry(body) {
		return this.http
			.post(this.neutrinousApi + 'payment/balance/enquiry', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(tap(payment => catchError(this.errorHandler)));
	}
	concatPlatNumber(vehicleInfo: IVehicleInformation) {
		return (
			vehicleInfo.PlateNumber +
			' ' +
			vehicleInfo.PlateText1 +
			' ' +
			vehicleInfo.PlateText2 +
			' ' +
			vehicleInfo.PlateText3
		);
	}

	recalculate(req, referenceId) {
		const headers = {
			language: this.currentLang,
		};
		return this.http
			.put(this.motorPurchaseApi + `/${referenceId}/recalculate`, req, {
				headers,
			})
			.pipe(catchError(this.errorHandler));
	}

	recalculateMultiVehical(req, referenceId) {
		const headers = {
			language: this.currentLang,
		};
		return this.http
			.put(
				this.motorPurchaseApi +
					`/v1/multiMotorPolicies/${referenceId}/recalculate`,
				req,
				{ headers },
			)
			.pipe(catchError(this.errorHandler));
	}

	getRevampVehicleUsageType(): Observable<any> {
		const headers = {
			language: this.currentLang,
		};
		// if (environment.offline) {
		//   return of(usageTypes);
		// }
		return this.http
			.get<any>(this.motorPurchaseApi + '/v1/motorPolicies/usageTypes', {
				headers,
			})
			.pipe(catchError(this.errorHandler));
	}

	addAdditionalInformation(
		referenceId,
		payload,
		langSelected,
		vehicleType: string = 'single',
		vehicleId: number = 0,
	) {
		const headers = new HttpHeaders({
			language: langSelected == 'en' ? 'en' : 'ar',
		});
		if (vehicleType === 'multi') {
			return this.http.post<any>(
				`${environment.motorPurchaseApi}/v1/multiMotorPolicies/${referenceId}/${vehicleId}/save/additionalinfo`,
				payload,
				{ headers },
			);
		} else {
			return this.http.post<any>(
				`${environment.motorPurchaseApi}/v1/motorPolicies/${referenceId}/save/additionalinfo`,
				payload,
				{ headers },
			);
		}
	}

	checkRenewalStatus(payload) {
		return this.http
			.post<any>(this.neutrinousApi + 'customer/renewals/status', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	getPolicyRenewalList() {
		return this.http
			.post<any>(
				this.neutrinousApi + 'customer/renewals/policy',
				{},
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	sendRenewalOTP() {
		return this.http
			.post<any>(this.neutrinousApi + 'renewal-verify-otp', null, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	verifyRenewalOTP(payload) {
		return this.http
			.post<any>(this.neutrinousApi + 'verify-user', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	// New Neutrinous APIs
	getCacheData() {
		return this.http
			.post<any>(this.neutrinousApi + '/util/cache/data', null, {
				context: isIndividualMotorAPI(),
			})
			.pipe(catchError(this.errorHandler));
	}

	getCacheDataWithCredential() {
		return this.http
			.post<any>(this.neutrinousApi + '/util/cache/data', null, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	guestLogin() {
		const guestUserData = {
			username: 'app',
			password: LOGIN.GUEST_PASSWORD,
			id: 'guest',
		};
		return this.http.post<any>(
			this.siteCoreBaseUrl + '/guestlogin',
			guestUserData,
		);
	}

	getCustomerDetails(payload: ICustomerDetailsPayload) {
		let url = `${environment.neutrinosApi}customer/details`;
		return this.http
			.post<any>(url, payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	getVehicleDetails(payload: IVehicleDetailsPayload) {
		return this.http
			.post<any>(environment.neutrinosApi + '/vehicle/details', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	downloadPolicy(policyId: number, segment_id: string) {
		let payload = {
			policy_id: policyId,
			segment_id: segment_id,
		};

		return this.http
			.post<any>(environment.neutrinosApi + '/policy/download', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
				responseType: 'arraybuffer' as 'json',
			})
			.pipe(retry(1), catchError(this.errorHandler));
	}
	createQuote(payload: ICreateQuotePayload) {
		return this.http
			.post<any>(this.neutrinousApi + 'quote/create', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	createRiskItem(payload: ICreateRiskItemPayload) {
		return this.http
			.post<ICreateRiskItemPayload>(
				this.neutrinousApi + 'risk_item/create',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	createDriver(payload: any) {
		return this.http
			.post<any>(this.neutrinousApi + 'driver/create', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	unlinkDriver(payload: any) {
		return this.http
			.post<any>(this.neutrinousApi + 'driver/unlink', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	getDriverList(payload: any) {
		return this.http
			.post<any>(this.neutrinousApi + 'driver/list', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	deleteDriver(payload: any) {
		return this.http
			.post<any>(this.neutrinousApi + 'driver/delete', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	updateRiskItem(payload: IUpdateRiskItemPayload) {
		return this.http
			.post<IUpdateRiskItemPayload>(
				this.neutrinousApi + 'risk_item/update',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	addRiskItemTolist(payload: IAddRiskItemPayload) {
		return this.http
			.post<IAddRiskItemListResponse>(
				this.neutrinousApi + 'risk_item/list',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	quoteSummary(reference_number) {
		const payload: IReferenceNumberPayload = {
			reference_number: reference_number,
		};
		return this.http
			.post<IQuoteSummaryResponse>(
				this.neutrinousApi + 'quote/summary',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getProducts(customer_type_id) {
		const payload: ICustomerTypeIdPayload = {
			customer_type_id: customer_type_id,
		};
		return this.http
			.post<Array<IQuoteProductItem>>(
				this.neutrinousApi + 'master_data/products',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getAddons(customer_type_id: number | string) {
		const payload: ICustomerTypeIdPayload = {
			customer_type_id: customer_type_id,
		};
		return this.http
			.post<Array<IAddonsResponseItemWithGroup>>(
				this.neutrinousApi + 'master_data/add-ons',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getVehicleImage(imgId: string) {
		return this.http
			.get(`${this.neutrinousApi}vehicle/image/${imgId}`, {
				responseType: 'blob', // Ensure response is treated as a binary blob
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	getUserInfo() {
		return this.http
			.get<any>(this.neutrinousApi + 'userInfo', {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	deleteUserInfo() {
		return this.http
			.post<any>(this.neutrinousApi + 'delete/userInfo', null, {
				context: isRevampMotorSMEAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	resetUserInfo() {
		return this.http
			.post<any>(
				this.neutrinousApi + 'delete/userInfo',
				{},
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getPolicyListrenewal() {
		return this.http
			.get<IPolicyList>(
				this.neutrinousApi + 'policy-list?offset=&limit=&filter=&desc=true',
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}
	getPolicyRenew(old_policy_id: number, old_policy_number: string) {
		const payload = {
			old_policy_id,
			old_policy_number,
		};
		return this.http
			.post<any>(this.neutrinousApi + 'policy/renew', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	find(search_type) {
		const payload: ISearchTypePayload = {
			search_type: search_type,
		};
		return this.http
			.post<ISearchTypePayload>(
				this.neutrinousApi + 'master_data/find',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	updateQuote(payload: IUpdateQuotePayload) {
		return this.http
			.post<{ id: number; reference_number: string }>(
				this.neutrinousApi + 'quote/update',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getRate(payload: IReferenceNumberPayload) {
		return this.http
			.post<Array<IGetRateResponse>>(
				this.neutrinousApi + 'motor/get-rate',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(retry(1), catchError(this.errorHandler));
	}

	quoteCalculatePremium(payload: { id: number }) {
		return this.http
			.post<{ status: boolean; premium: number }>(
				this.neutrinousApi + 'quote/calculate-premium',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	calculateRewardpoints(payload: {
		reference_number: string;
		journey?: string;
	}) {
		return this.http
			.post<any>(this.neutrinousApi + 'calculate_earn_rewardpoints', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	linkProduct(payload: ILinkProductPayload) {
		return this.http
			.post<{ id: number }>(
				this.neutrinousApi + 'risk_item/link_product',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	createAddons(payload: ICreateAddonsPayload) {
		return this.http
			.post<ICreateAddonsPayload>(
				this.neutrinousApi + 'addons/create',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	getAddonsList(payload: { quote_id: number }) {
		return this.http
			.post<{ quote_id: number }>(this.neutrinousApi + 'addons/list', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	deleteAddons(payload: { id: Array<number> }) {
		return this.http
			.post<{ id: Array<number> }>(
				this.neutrinousApi + 'addons/delete',
				payload,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	uploadImageSms(payload: { reference_number: string }) {
		return this.http
			.post<any>(this.neutrinousApi + 'quote/upload-image-sms', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	uploadImageComprehensive(payload) {
		return this.http
			.post<any>(this.neutrinousApi + 'upload', payload, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	QR_code(payload: { reference_number: string }) {
		// New  api for revamp to generate QR code is 'vehicle/image/qr_data'

		return this.http
			.get<any>(this.neutrinousApi + 'vehicle/image_qr_data', {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	viewQuote(referenceId: string) {
		return this.http
			.post<{
				phone_no: string;
				txId: string;
			}>(
				this.neutrinousApi + `view-quote/${referenceId}`,
				{
					lang: this.currentLang,
				},
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	verifyOtp(TxId: string, value: string) {
		return this.http
			.post<any>(
				this.neutrinousApi + '/verify-user',
				{
					TxId: TxId,
					value: value,
				},
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}
	requiredFiles(body) {
		return this.http
			.post<any>(this.neutrinousApi + '/quote/customer/required-files', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	companyInfo(payload: {
		unifiedNumber: string;
		nationalId: string;
		mobileNumber: string;
	}) {
		const httpOptions = {
			context: isIndividualMotorAPI(),
			withCredentials: true,
		};
		return this.http
			.post<any>(this.neutrinousApi + 'sme/company-info', payload, httpOptions)
			.pipe(retry(1), catchError(this.errorHandler));
	}
	updateLocal(reference_number) {
		const httpOptions = {
			context: isIndividualMotorAPI(),
			withCredentials: true,
		};
		let payload  = {
			"reference_number":reference_number,
			"selected_language":this.languageService.activeLang()
		}

		return this.http
			.post<any>(
				this.neutrinousApi + `quote/locale`,
				payload,
				httpOptions,
			)
			.pipe(retry(1), catchError(this.errorHandler));
	}
	sendFirstOtp(referenceNumber: string) {
		const httpOptions = {
			context: isIndividualMotorAPI(),
			withCredentials: true,
		};
		const payload = { lang: localStorage.getItem('selectedLang') };
		return this.http
			.post<any>(
				this.neutrinousApi + `send-first-otp/${referenceNumber}`,
				payload,
				httpOptions,
			)
			.pipe(retry(1), catchError(this.errorHandler));
	}

	verifyFirstOtp(payload: { TxId: string; value: string }) {
		const httpOptions = {
			context: isIndividualMotorAPI(),
			withCredentials: true,
		};

		return this.http
			.post<any>(
				this.neutrinousApi + `verify-stage-one-otp`,
				payload,
				httpOptions,
			)
			.pipe(retry(1), catchError(this.errorHandler));
	}
	verifYCoupon(body) {
		const httpOptions = {
			context: isIndividualMotorAPI(),
			withCredentials: true,
		};

		return this.http
			.post<any>(this.neutrinousApi + `apply/coupon`, body, httpOptions)
			.pipe(retry(1), catchError(this.errorHandler));
	}
	exportAsPDF(reference_number: string) {
		const httpOptions = {
			context: isRevampMotorSMEAPI(),
			withCredentials: true,
		};
		return this.http
			.post(
				this.neutrinousApi + 'quote/summary-pdf',
				{ reference_number },
				{ ...httpOptions, responseType: 'blob' },
			)
			.pipe(retry(1), catchError(this.errorHandler));
	}

	generateAuthCode() {
		const path = '/dcp-oauth/authorizationcode?response_type=code&client_id=';
		const redirect = '&redirect_uri=https://b';
		let url = `${environment.apigeeUrlNutrunos}${path}${environment.apigeeClientIDNutrunos}${redirect}`;
		return this.http.get<any>(url);
	}
	generateAccessToken(authorizationCode): Observable<any> {
		// const path ='/dcp-oauth/accesstoken?grant_type=authorization_code&client_id=DsJFUrAADg1tZIvjHdGMgfEC40ToAEag';
		const path = `/dcp-oauth/accesstoken?grant_type=authorization_code&client_id=${environment.apigeeClientIDNutrunos}`;
		let apigeeAuth = environment.apigeeAuthNutrunos;
		let url = `${environment.apigeeUrlNutrunos}${path}`;
		let payload = new URLSearchParams();
		payload.set('code', authorizationCode);
		payload.set('grant_type', 'authorization_code');
		payload.set('redirect_uri', 'https://b');
		// this.authService.setPaymentAuthToken(apigeeAuth);
		localStorage.setItem('Pay_Token', apigeeAuth);
		sessionStorage.setItem('Pay_session_token', apigeeAuth);
		return this.http
			.post(url, payload.toString(), {
				context: isApigeeAuthCodeAPI(),
			})
			.pipe(catchError(this.errorHandler));
	}

	validateQuoteInfo(body: {
		reference_number: string;
	}): Observable<IValidateQuoteResponse> {
		return this.http
			.post<any>(this.neutrinousApi + 'renewals/quote/validate', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}

	UpdateQuoteInfo(
		body: any,
	): Observable<{ success: boolean; statusCode: number }> {
		return this.http
			.post<any>(this.neutrinousApi + 'renewals/quote/update', body, {
				context: isIndividualMotorAPI(),
				withCredentials: true,
			})
			.pipe(catchError(this.errorHandler));
	}
	getAddressList(body: {
		id_no: string;
	}): Observable<Array<INationalAddressResponse>> {
		return this.http
			.post<Array<INationalAddressResponse>>(
				this.neutrinousApi + 'addressinfo/list/id',
				body,
				{
					context: isIndividualMotorAPI(),
					withCredentials: true,
				},
			)
			.pipe(catchError(this.errorHandler));
	}

	errorHandler(error) {
		let errorMessage = '';
		if (error.error instanceof ErrorEvent) {
			errorMessage = error.error.message;
		} else {
			errorMessage = error.error;
		}
		return throwError(errorMessage);
	}

	handleSelectCar(quoteDetails: any, vehicleDetails: IVehicle) {
		const selectedVehicleData = quoteDetails.risk_item_details.find(
			el => el.id_no == vehicleDetails.id_no,
		);
		let filteredValidRatesForCarSelected = selectedVehicleData.premium_details;
		return {
			selectedVehicle: vehicleDetails.id_no,
			selectedVehicleRiskId: vehicleDetails.id,
			filteredValidRatesForCarSelected,
			selectedProduct: selectedVehicleData.selectedPlan || vehicleDetails.selectedPlan,
			selectedCarAdditionalInfo: selectedVehicleData.addl_details,
		};
	}
}
