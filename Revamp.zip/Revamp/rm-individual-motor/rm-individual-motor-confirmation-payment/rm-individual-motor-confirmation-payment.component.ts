import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { IndividualMotorService } from '../services/individual-motor.service';
import moment from 'moment/moment';

@Component({
	selector: 'art-rm-individual-motor-confirmation-payment',
	templateUrl: './rm-individual-motor-confirmation-payment.component.html',
	styleUrls: ['./rm-individual-motor-confirmation-payment.component.scss'],
})
export class IndividualMotorConfirmationPaymentComponent {
	private readonly STORAGE_KEY = 'motorindividualSession';
	private readonly storage = inject(ARTStorageService);
	private router = inject(Router);
	// @TODO : Will come from localStorage..
	customerData = {
		name: 'John Doe',
		policyName: 'Motor insurance ',
		policyId: '123456789',
		paymentAmount: '1000',
		paymentCurrency: 'SAR',
		paymentFrom: '21-05-2023',
		paymentTo: '21-05-2023',
		refNumber: '',
		productIcon: 'car',
	};
	private motorIndividualService = inject(IndividualMotorService);
	refId;
	private state = inject(ARTStorageService);
	private translateService = inject(TranslateService);
	currentLang = localStorage.getItem('selectedLang');
	ngOnInit() {
		// @TODO : Get the customer data from local storage
		// this.customerData = this.storage.GetValue(this.STORAGE_KEY);

		const storagedata = this.state.GetValue(
			this.motorIndividualService.STORAGE_KEY,
		);
		this.refId = storagedata.reference_number || this.storage.GetValue('referenceId') ;
	
		this.customerData['name'] = this.state.GetValue('name');
		this.customerData['productIcon'] = 'art-motor-product-icon';
		this.customerData['policyName'] = this.translateService.instant(
			'INDIVIDUAL_MOTOR.MOTOR_INSURANCE_POLICY',
		);
		this.customerData['paymentCurrency'] =
			this.translateService.instant('COMMON.SAR');
		this.customerData['policyId'] = this.state.GetValue('policyId');
		this.customerData['plan'] = this.state.GetValue('policyPaymentCoverage');

		this.customerData['paymentFrom'] = this.state.GetValue('paymentFrom');
		this.customerData['paymentTo'] = this.state.GetValue('paymentTo');
		this.customerData['refNumber'] = this.state.GetValue('paymentRefNo');
		this.customerData['paymentAmount'] = this.state.GetValue('totalPremiumVal');
	}

	downloadPDF() {
		this.motorIndividualService.exportAsPDF(this.refId).subscribe(
				(response: Blob) => {
					const url = window.URL.createObjectURL(response);
					const a = document.createElement('a');
					a.href = url;
					a.download = 'summary.pdf';
					document.body.appendChild(a);
					a.click();
					document.body.removeChild(a);
					window.URL.revokeObjectURL(url);
				},
				(error) => {
					console.error('Error downloading PDF:', error);
				}
			);
		}

	navigateToTrakeRequest($event: any) {
		this.router.navigate(['/revamp-individual-motor/track-request']);
	}

	private getName(customer_details: any) {
		return this.currentLang == 'ar'
			? `${customer_details.first_name_ar}  ${customer_details.last_name_ar}`
			: `${customer_details.first_name_en}  ${customer_details.last_name_en}`;
	}
}
