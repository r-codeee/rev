import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RmIndividualMotorPaymentComponent } from 'src/app/rm-individual-motor/rm-individual-motor-payment/rm-individual-motor-payment.component';
import { RmIndividualMotorStepperComponent } from 'src/app/rm-individual-motor/rm-individual-motor-stepper/rm-individual-motor-stepper.component';
import { RmMotorIndividualPremiumCalculationComponent } from 'src/app/rm-individual-motor/rm-motor-individual-premium-calculation/rm-motor-individual-premium-calculation.component';
import { RmIndividualMotorHomeComponent } from './rm-individual-motor-home/rm-individual-motor-home.component';
import { RMIndividualMotorTrackRequestComponent } from './rm-individual-motor-track-request/rm-individual-motor-track-request.component';
import { RmIndividualMotorQuotationComponent } from './rm-individual-motor-quotation/rm-individual-motor-quotation.component';
import { IndividualMotorConfirmationPaymentComponent } from './rm-individual-motor-confirmation-payment/rm-individual-motor-confirmation-payment.component';
import { RmIndividualMotorOtpComponent } from './rm-individual-motor-otp/rm-individual-motor-otp.component';
import { individualMotorGuard } from './guards/individual-motor.guard';
import { RmIndividualMotorQuotationOtpComponent } from './rm-individual-motor-quotation-otp/rm-individual-motor-quotation-otp.component';
import { RmRenewalOtpComponent } from './rm-renewal/rm-renewal-otp/rm-renewal-otp.component';
import { RmRenewalListVehiclesComponent } from './rm-renewal/rm-renewal-list-vehicles/rm-renewal-list-vehicles.component';
import { RmRenewPolicyComponent } from './rm-renewal/rm-renew-policy/rm-renew-policy.component';
import { RmIndividualRenewalPaymentComponent } from './rm-renewal/rm-individual-renewal-payment/rm-individual-renewal-payment.component';
import { MotorIndividualPaymentFailiureComponent } from './motor-individual-payment-failiure/motor-individual-payment-failiure.component';
import { RmIndividualMotorScanQrStepperComponent } from './rm-individual-motor-scan-qr/rm-individual-motor-scan-qr-stepper/rm-individual-motor-scan-qr-stepper.component';
import { QrCarsListComponent } from './rm-individual-motor-scan-qr/qr-cars-list/qr-cars-list.component';
import { QrCarsPhotoComponent } from './rm-individual-motor-scan-qr/qr-cars-photo/qr-cars-photo.component';
import { CarsQrUploadedComponent } from './rm-individual-motor-scan-qr/cars-qr-uploaded/cars-qr-uploaded.component';
import { QrOtpScreenComponent } from './rm-individual-motor-scan-qr/qr-otp-screen/qr-otp-screen.component';
import { RmUpdateInformationComponent } from './rm-renewal/rm-update-information/rm-update-information.component';

const routes: Routes = [
	{
		path: '',
		component: RmIndividualMotorHomeComponent,
	},
	{
		path: 'quotation',
		component: RmIndividualMotorQuotationComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'motor-individual-quotation-stepper',
		component: RmIndividualMotorStepperComponent,
		data: { showHeader: false, showFooter: false },
		children: [
			{
				path: '',
				redirectTo: 'premium-calculation',
				pathMatch: 'full',
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'premium-calculation',
				component: RmMotorIndividualPremiumCalculationComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'payment',
				component: RmIndividualMotorPaymentComponent,
				data: { showHeader: false, showFooter: false },
			},
		],
		canActivate: [individualMotorGuard],
	},
	{
		path: 'qr-code-vehicle-upload',
		component: QrOtpScreenComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'motor-individual-qr-stepper',
		component: RmIndividualMotorScanQrStepperComponent,
		data: { showHeader: false, showFooter: false },
		children: [
			{
				path: '',
				redirectTo: 'cars-list',
				pathMatch: 'full',
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'cars-list',
				component: QrCarsListComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'car-photos',
				component: QrCarsPhotoComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'cars-upload',
				component: CarsQrUploadedComponent,
				data: { showHeader: false, showFooter: false },
			},
		],
	},
	{
		path: 'renewal',
		children: [
			{
				path: '',
				redirectTo: 'policies',
				pathMatch: 'full',
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'policies',
				component: RmRenewalListVehiclesComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'premium-calculation',
				component: RmRenewPolicyComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'payment',
				component: RmIndividualRenewalPaymentComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'update-information',
				component: RmUpdateInformationComponent,
				data: { showHeader: false, showFooter: false },
			},
		],
	},
	{
		path: 'revamp-individual-motor-otp',
		component: RmIndividualMotorOtpComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'revamp-renewal-otp',
		component: RmRenewalOtpComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'revamp-individual-motor-quotation-otp',
		component: RmIndividualMotorQuotationOtpComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'track-request',
		component: RMIndividualMotorTrackRequestComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'payment-confirmation',
		component: IndividualMotorConfirmationPaymentComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'payment-failure',
		component: MotorIndividualPaymentFailiureComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: '**',
		component: RmIndividualMotorHomeComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class RMIndividualMotorRoutingModule {}
