import { Pipe, PipeTransform } from '@angular/core';
import { Languages } from 'src/app/RM-enums/languages';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { IQuoteRiskItemAdditionalDetails } from './models/individualMotorDto';

@Pipe({
	name: 'vehicleMakerModel',
	standalone: true,
})
export class VehicleMakerModelPipe implements PipeTransform {
	constructor(private languageService: RMLanguageService) {}

	transform(vehicleInfo: IQuoteRiskItemAdditionalDetails): string {
		if (!vehicleInfo) return '';

		return this.languageService.activeLang() === Languages.AR
			? `${vehicleInfo.make_ar} - ${vehicleInfo.model_ar}`
			: `${vehicleInfo.make_en} - ${vehicleInfo.model_en}`;
	}
}
