import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { DropdownOptionType } from './../../design-system/types/DropdownOptionType';
import { SvgIconComponent } from './../../design-system/svg-icon/svg-icon.component';
import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';
import { Router } from '@angular/router';
import { GetIndividualQuotationFormValues } from './../../rm-shared-components/types/GetIndividualQuoteFormValues';
import { AfterViewInit, Component, inject } from '@angular/core';
import * as moment from 'moment';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { IndividualMotorQuotationFormValidationSchemaService } from '../services/individual-motor-quotation-form-validation-schema.service';
import { AddNewCarMethods } from '../enums/AddNewCarMethods';
import { ICardData } from 'src/app/design-system/motor-card-with-radio/motor-card-with-radio.component';
import { delay, switchMap, tap } from 'rxjs';
import {
	ICreateQuotePayload,
	ICreateRiskItemPayload,
	ICustomerDetailsPayload,
	IVehicleDetailsPayload,
	VehicleType,
} from '../models/individualMotorDto';
import { AppComponent } from '../../app.component';
import { TranslateService } from '@ngx-translate/core';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

export interface ICustomVehicleInfo {
	VehicleMaker: string;
	ModelYear: number;
	VehicleModel: string;
}

@Component({
	selector: 'art-individual-motor-form',
	templateUrl: './individual-motor-form.component.html',
	styleUrls: ['./individual-motor-form.component.scss'],
})
export class IndividualMotorFormComponent
	extends BaseFormComponent<GetIndividualQuotationFormValues>
	implements AfterViewInit
{
	values: GetIndividualQuotationFormValues = {
		nationalId: '',
		dateOfBirth: null,
		mobileNumber: '',
		email: '',
		policyStartDate: this.getTomorrowDate(),
		iqamaNo: '',
		agentCode: '',
		customNumber: null,
		sequenceNumber: null,
		vehicleProductionYear: null,
		[AddNewCarMethods.SEQUENCE_NUMBER]: null,
		[AddNewCarMethods.OWNERSHIP_TRANSFER]: null,
		[AddNewCarMethods.CUSTOM_NUMBER]: null,
		multiVehicle: false,
	};

	protected readonly AddNewCarMethods = AddNewCarMethods;
	private individualMotor = inject(IndividualMotorService);
	addCarMethods = this.individualMotor.ADD_CAR_METHODS;

	validationSchema =
		this.quoteFormValidationSchemaService.createIndividualMotorQuotationValidationSchema();

	submitted: boolean = false;
	currentLang = localStorage.getItem('selectedLang');
	serverErrMsg: string = '';
	nationalIdSuffixComponent = SvgIconComponent;
	iconComponent = IconComponent;
	nationalIdSuffixComponentInputs = { icon: 'nationalId', size: 'xs' };
	iconComponentEmailInputs = { icon: 'email', size: 'xs' };
	years: Array<DropdownOptionType> = [];
	vehicleMakers = [];
	customVehicleInfo: ICustomVehicleInfo;
	motorDetailsDisabled = true;
	isLoading: boolean;

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private individualMotorService: IndividualMotorService,
		private translateService: TranslateService,
		private lanugageService: RMLanguageService,
		private storage: ARTStorageService,
		private router: Router,
		private quoteFormValidationSchemaService: IndividualMotorQuotationFormValidationSchemaService,
		private appComponent: AppComponent,
	) {
		super(formBuilderService);
		this.currentLang = this.lanugageService.activeLang();
		this.setYears();
		this.guestLogin();
		this.storage.RemoveValue(this.individualMotorService.STORAGE_KEY)
	}

	ngAfterViewInit(): void {
		this.onFormValueChanges();
	}

	onFormValueChanges(): void {
		this.form
			.get('nationalId')
			?.valueChanges.subscribe(() => this.toggleMotorDetailsControls());
		this.form
			.get('dateOfBirth')
			?.valueChanges.subscribe(() => this.toggleMotorDetailsControls());
		this.form
			.get('mobileNumber')
			?.valueChanges.subscribe(() => this.toggleMotorDetailsControls());
		this.form
			.get('email')
			?.valueChanges.subscribe(() => this.toggleMotorDetailsControls());
	}

	setYears() {
		const currenYear = new Date().getFullYear();
		for (let i = currenYear; i >= 1907; i--) {
			this.years.push({ Name_ar: `${i}`, Name_en: `${i}`, Id: i, value: i });
		}
	}

	getTomorrowDate() {
		const today = new Date();
		// Set the date to tomorrow by adding one day
		const tomorrow = new Date(today);
		tomorrow.setDate(today.getDate() + 1);
		return tomorrow;
	}

	vehicleProductionYearChange(event) {
		this.form.patchValue({ vehicleProductionYear: event.value });
	}

	isValidPolicyDetailsFields() {
		const { nationalId, dateOfBirth, mobileNumber, email } = this.form.value;
		return nationalId && dateOfBirth && mobileNumber && email;
	}

	handleSelectAddCarMethod(selectedMethod: ICardData) {
		if (this.isValidPolicyDetailsFields()) {
			this.addCarMethods = this.addCarMethods.map(method => {
				if (method.id === selectedMethod.id) {
					this.form.get(method.id).setValue(true);
					return {
						...method,
						active: true,
					};
				}
				this.form.get(method.id).setValue(false);
				return { ...method, active: false };
			});

			this.getCustomerDetails();
		} else {
			this.resetCarMethodsFields();
		}
	}

	resetCarMethodsFields() {
		this.addCarMethods = this.addCarMethods.map(method => {
			this.form.get(method.id).setValue(null);
			method.active = false;
			return method;
		});
	}

	getVehicleMakers() {
		this.individualMotorService
			.getVehicleMakersFromDCP()
			.subscribe(response => {
				const makersDataToSort = response;
				makersDataToSort.sort((a, b) =>
					a.MakeNameEN > b.MakeNameEN
						? 1
						: b.MakeNameEN > a.MakeNameEN
							? -1
							: 0,
				);
				this.vehicleMakers = makersDataToSort;
			});
	}

	// Helper function to parse the date string
	parseDateString(dateString: string): Date | null {
		const parts = dateString.split('-');
		if (parts.length === 3) {
			const day = parseInt(parts[0], 10);
			const month = parseInt(parts[1], 10) - 1; // Month is zero-based
			const year = parseInt(parts[2], 10);
			return new Date(year, month, day);
		}
		return null;
	}

	onSubmit(values: GetIndividualQuotationFormValues) {
		this.submitted = true;
		this.isLoading = true;
		const payload: IVehicleDetailsPayload = {
			id_type: values.CUSTOM_NUMBER ? 11 : 10,
			vehicle_id_no: values.customNumber || values.sequenceNumber,
			model_year: values.CUSTOM_NUMBER ? values.vehicleProductionYear : null,
			owner_id: values.iqamaNo || values.nationalId,
			policy_holder_id: values.nationalId,
		};

		this.getVehicleDetails(payload);
	}

	toggleMotorDetailsControls(): void {
		const { nationalId, dateOfBirth, mobileNumber, email } = this.form.controls;
		if (
			nationalId.value &&
			dateOfBirth.value &&
			mobileNumber.value &&
			email.value &&
			nationalId.valid &&
			dateOfBirth.valid &&
			mobileNumber.valid &&
			email.valid
		) {
			this.motorDetailsDisabled = false;
		} else {
			this.motorDetailsDisabled = true;
		}
	}

	// New Neutrinous APIs
	guestLogin() {
		this.individualMotor
			.guestLogin()
			.pipe(
				tap((res: any) => {
					localStorage.removeItem('dcp-token');
					localStorage.setItem('dcp-token', res.token);
				}),
				// Added Delay here to make sure that getCacheData is called after Pay_Token is updated in local storage
				delay(1200),
				switchMap(() => this.individualMotor.getCacheDataWithCredential()),
			)
			.subscribe({
				next: res => {
					this.appComponent.setApigee();
				},
				error: error => {
					this.serverErrMsg = error?.message || error;
					this.appComponent.setApigee();
					if(this.serverErrMsg.includes('Unknown Error') || this.serverErrMsg == undefined  ||  typeof this.serverErrMsg == 'object'){
						this.serverErrMsg = this.translateService.instant('motorSME.oops')
					}

				},
			});
	}

	getCustomerDetails() {
		this.serverErrMsg = '';
		const payload: ICustomerDetailsPayload = {
			id_type: this.form.value.nationalId.startsWith('1') ? 1 : 2,
			id_no: this.form.value.nationalId,
			dob: moment(this.form.value.dateOfBirth).format('MM-YYYY'),
			phone_no: '966' + this.form.value.mobileNumber,
			source: 'b2c',
		};
		this.individualMotor.getCustomerDetails(payload).subscribe({
			next: res => {
				this.storage.mergeIntoExistValue(
					this.individualMotorService.STORAGE_KEY,
					{
						customerDetailsResponse: res,
						customerDetailsPayload: payload,
					},
				);
			},
			error: err => {
				this.resetCarMethodsFields();
				this.serverErrMsg = err?.message || err?.error || err?.Response?.ErrorMessage || err.error_msg || err;
				console.log(typeof this.serverErrMsg)
				if(typeof this.serverErrMsg == 'object'){
					this.serverErrMsg = this.translateService.instant('COMMON.PLEASE_CHECK_ENTERED_DATA_THEN_TRY_AGAIN_LATER')
				}
			},
		});
	}

	getVehicleDetails(payload: IVehicleDetailsPayload) {
		this.serverErrMsg = '';
		this.individualMotor.getVehicleDetails(payload).subscribe({
			next: res => {
				this.storage.mergeIntoExistValue(
					this.individualMotorService.STORAGE_KEY,
					{
						vehicleDetailsResponse: res,
						vehicleDetailsPayload: payload,
					},
				);
				this.createQuote();
			},
			error: err => {
				this.serverErrMsg = err?.message || err?.error || err.error_msg || err;
				this.isLoading = false;
				if(this.serverErrMsg.includes('Unknown Error') || this.serverErrMsg == undefined  ||  typeof this.serverErrMsg == 'object'){
					this.serverErrMsg = this.translateService.instant('COMMON.PLEASE_CHECK_ENTERED_DATA_THEN_TRY_AGAIN_LATER')
				}
			},
		});
	}

	createQuote() {
		const payload: ICreateQuotePayload = {
			id_no: this.form.value.nationalId,
			lob_id: 1,
			phone_no: this.form.value.mobileNumber,
			email_id: this.form.value.email,
			addl_details: {
				type: VehicleType.SINGLE,
				calendar_type: 'G',
				policy_start_date: moment(this.form.value.policyStartDate).format(
					'DD-MM-YYYY',
				),
				agent_code: this.form.value.agentCode,
			},
		};
		this.individualMotor.createQuote(payload).subscribe({
			next: res => {
				this.storage.mergeIntoExistValue(
					this.individualMotorService.STORAGE_KEY,
					{
						quoteResponse: res,
						quotePayload: payload,
					},
				);
				const RiskPayload: ICreateRiskItemPayload = {
					id_no: Number(
						this.form.value.customNumber || this.form.value.sequenceNumber,
					),
					quote_id: res.id,
				};
				this.createRiskItem(RiskPayload);
				this.isLoading = false;
			},
			error: err => {
				this.isLoading = false;
				this.serverErrMsg = err?.message || err?.error || err;
				if(this.serverErrMsg.includes('Unknown Error') || this.serverErrMsg == undefined  ||  typeof this.serverErrMsg == 'object'){
					this.serverErrMsg = this.translateService.instant('COMMON.PLEASE_CHECK_ENTERED_DATA_THEN_TRY_AGAIN_LATER')
				}
			},
		});
	}

	createRiskItem(riskPayload: ICreateRiskItemPayload) {
		this.individualMotor.createRiskItem(riskPayload).subscribe({
			next: res => {
				this.storage.mergeIntoExistValue(
					this.individualMotorService.STORAGE_KEY,
					{
						riskResponse: res,
						riskPayload: riskPayload,
					},
				);
				this.router.navigateByUrl(
					'/revamp-individual-motor/revamp-individual-motor-quotation-otp',
				);
			},
			error: err => {
				this.serverErrMsg = err?.message || err?.error || err;
				console.log(this.serverErrMsg);
				if(this.serverErrMsg.includes('Unknown Error') || this.serverErrMsg == undefined  ||  typeof this.serverErrMsg == 'object'){
					this.serverErrMsg = this.translateService.instant('COMMON.PLEASE_CHECK_ENTERED_DATA_THEN_TRY_AGAIN_LATER')
				}
			},
		});
	}
  openPrivacy() {
    if (this.currentLang == "ar") {
      window.open("/ar/سياسة-الخصوصية", "_blank");
    } else {
      window.open("/en/privacy-policy", "_blank");
    }
  }
}
