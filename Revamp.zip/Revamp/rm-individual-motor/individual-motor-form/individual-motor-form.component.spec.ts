import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualMotorFormComponent } from './individual-motor-form.component';

describe('IndividualMotorFormComponent', () => {
  let component: IndividualMotorFormComponent;
  let fixture: ComponentFixture<IndividualMotorFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IndividualMotorFormComponent]
    });
    fixture = TestBed.createComponent(IndividualMotorFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
