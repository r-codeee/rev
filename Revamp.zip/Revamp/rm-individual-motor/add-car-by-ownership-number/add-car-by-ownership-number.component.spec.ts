import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCarByOwnershipNumberComponent } from './add-car-by-sequence-number.component';

describe('AddCarByOwnershipNumberComponent', () => {
  let component: AddCarByOwnershipNumberComponent;
  let fixture: ComponentFixture<AddCarByOwnershipNumberComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddCarByOwnershipNumberComponent]
    });
    fixture = TestBed.createComponent(AddCarByOwnershipNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
