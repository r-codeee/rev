import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IconComponent } from '../../design-system/icon/icon.component';
import {
	IAddVehicleByOwnershipNumber,
	IAddVehicleBySequenceNumber,
} from '../types/IAddNewVehicle';
import { BaseFormComponent } from '../../../art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from '../../../art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from '../../../art-forms/services/art-validation-rules.service';
import * as yup from 'yup';
import { ObjectSchema } from 'yup';

@Component({
	selector: 'art-add-car-by-ownership-number',
	templateUrl: './add-car-by-ownership-number.component.html',
	styleUrls: ['./add-car-by-ownership-number.component.scss'],
})
export class AddCarByOwnershipNumberComponent extends BaseFormComponent<IAddVehicleByOwnershipNumber> {
	@Input() isLoading = false;
	@Input() nationalIdLabelKey = '';
	@Input() nationalIdSubLabelKey = '';
	@Input() isOwnershipTransfer: boolean = false;

	@Output() onSubmitForm: EventEmitter<IAddVehicleByOwnershipNumber> =
		new EventEmitter();

	@Output() onChangeInput: EventEmitter<boolean> = new EventEmitter();

	protected readonly IconComponent = IconComponent;

	validationSchema: ObjectSchema<IAddVehicleByOwnershipNumber> = yup
		.object()
		.shape({
			nationalIdNumber: this.validationRulesService.nationalIdValidationRule(),
			sequenceNumber: this.validationRulesService.ownershipValidationRule(),
		});

	values: IAddVehicleByOwnershipNumber = {
		nationalIdNumber: '',
		sequenceNumber: '',
	};

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private validationRulesService: ArtValidationRulesService,
	) {
		super(formBuilderService);
	}

	onSubmit(values: IAddVehicleByOwnershipNumber): void {
		this.onSubmitForm.emit(values);
	}

	changeInput(event) {
		this.onChangeInput.emit(true);
	}
}
