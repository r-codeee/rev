import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { StepperService } from 'src/app/design-system/services/stepper.service';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { NavigationEnd, Router } from '@angular/router';

@Component({
	selector: 'art-rm-individual-motor-stepper',
	templateUrl: './rm-individual-motor-stepper.component.html',
	styleUrls: ['./rm-individual-motor-stepper.component.scss'],
})
export class RmIndividualMotorStepperComponent implements OnInit, OnDestroy {
	protected stepperService = inject(StepperService);
	protected translateService = inject(TranslateService);
	private routerSubscription: Subscription;
	protected router = inject(Router);
	steps = [
		{
			titleKey: 'COMMON.PREMIUM_CALCULATION',
			url: '/revamp-individual-motor/motor-individual-quotation-stepper/premium-calculation',
			isActive: true,
			isValid: false,
		},
		{
			titleKey: 'COMMON.REVIEW_AND_PAYMENT',
			url: '/revamp-individual-motor/motor-individual-quotation-stepper/payment',
			isActive: false,
			isValid: false,
		},
	];

	ngOnInit() {
		this.updateSteps(this.router.url);

		this.routerSubscription = this.router.events.subscribe(event => {
			if (event instanceof NavigationEnd) {
				this.updateSteps(event.urlAfterRedirects || event.url);
			}
		});
	}

	updateSteps(currentUrl: string) {
		let thisActive = false;
		this.steps.forEach((step, index) => {
			if (step.url === currentUrl) {
				thisActive = true;
				step.isActive = true;
			} else {
				step.isActive = !thisActive;
				step.isValid = !thisActive;
			}
		});

		this.stepperService.setStepsData(this.steps);
	}

	ngOnDestroy() {
		// Cleanup subscription on component destruction
		if (this.routerSubscription) {
			this.routerSubscription.unsubscribe();
		}
	}
}
