import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorStepperComponent } from './rm-individual-motor-stepper.component';

describe('RmIndividualMotorStepperComponent', () => {
  let component: RmIndividualMotorStepperComponent;
  let fixture: ComponentFixture<RmIndividualMotorStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorStepperComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
