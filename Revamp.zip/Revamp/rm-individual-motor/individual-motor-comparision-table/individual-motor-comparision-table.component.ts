import {
	Component,
	computed,
	EventEmitter,
	Inject,
	Input,
	signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ArtButtonComponent } from '../../design-system/art-button/art-button.component';
import { ArtComparisonCard } from '../../design-system/rm-comparison-card/rm-comparison-card';
import { ArtDeviderCard } from '../../design-system/rm-devider-card/rm-devider-card';
import { CoverageType } from '../enums/CoverageType';
import { IconButtonComponent } from '../../design-system/icon-button/icon-button.component';
import { BenefitsStyles, ComparisonTableHelperService, TableColumn, TableRow } from 'src/app/services/comparison-table-helper.service';
import { RmComparisonTableComponent } from '../../design-system/rm-comparison-table/rm-comparison-table';

@Component({
	selector: 'art-individual-motor-comparision-table',
	standalone: true,
	imports: [
		CommonModule,
		ArtButtonComponent,
		ArtComparisonCard,
		ArtDeviderCard,
		TranslateModule,
		IconButtonComponent,
		RmComparisonTableComponent,
	],
	templateUrl: './individual-motor-comparision-table.component.html',
	styleUrls: ['./individual-motor-comparision-table.component.scss'],
})
export class IndividualMotorComparisionTableComponent {
	@Input() title: string;
	@Input() mode: number;
	submit = new EventEmitter();
	benifitsData: any = [];
	selectedValue: any;
	currentLang: any;
	benefits = new Set<{ Name: string }>();
	allPlans = signal<any>({});
	coverageData = [];
	protected readonly CoverageType = CoverageType;
	tableData: TableColumn[];
	rowLabels: TableRow[];
	currentProductValue = (id: any) =>
		computed(() => this.allPlans()[id]?.PolicyPremium);
	discountValue = (id: any) => computed(() => this.allPlans()[id]?.basePremium);

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: any,
		private dialogRef: MatDialogRef<IndividualMotorComparisionTableComponent>,
		private translateService: TranslateService,
		private comparisonTableHelper: ComparisonTableHelperService,
	) {
		this.currentLang = localStorage.getItem('selectedLang');
		this.translateService.use(this.currentLang);
		this.selectedValue = data.selectedPlan;
		console.log(this.data.allMapedPlans);
		this.allPlans.set(this.data.allMapedPlans);
		this.mapData(data);
	}

	ngOnInit(): void {}

	onClose() {
		this.dialogRef.close(this.data.selectedPlan);
	}

	onUpgrade({ event, data }) {
		this.selectedValue = this.data.rates.find(
			rate => rate.short_name === data || rate.short_name_ar === data,
		);
		this.dialogRef.close(this.selectedValue);
	}

	getPlanImage(plan) {
		return `${plan.short_name.replace(/\s+/g, '-').toLowerCase()}-product`;
	}

	getFormattedNumber(num) {
		if (!num) {
			return;
		}
		return new Intl.NumberFormat('en-US', {
			minimumIntegerDigits: 1,
			minimumFractionDigits: 2,
			maximumFractionDigits: 2,
		}).format(num);
	}

	private mapData(data) {
		const uniqueCoverages = new Map();
		data.rates.forEach(rate =>
			rate.basic_coverage.forEach(cov => {
				const key =
					this.currentLang === 'ar' ? cov.cover_name_ar : cov.cover_name;
				if (!uniqueCoverages.has(key)) uniqueCoverages.set(key, cov);
			}),
		);

		this.benifitsData = Array.from(uniqueCoverages.keys()).map(Name => ({
			Name,
		}));

		this.coverageData = data.rates.map(rate =>
			this.benifitsData.map(benefit => ({
				Name: benefit.Name,
				Value: rate.basic_coverage.some(
					cov =>
						(this.currentLang === 'ar' ? cov.cover_name_ar : cov.cover_name) ===
						benefit.Name,
				),
			})),
		);
		this.tableData = this.mapDataToTableRows(this.data.rates);
		this.rowLabels.push({ name: 'componentData', isCustomComponent: true });
		this.tableData.forEach((col: any) => {
			const planeNameCamelCase = (col.Name as string).toLowerCase();
			col.benefits['componentData'] = {
				value: '',
				componentData:
					col.Name === this.selectedValue.short_name_ar ||
					col.Name === this.selectedValue.short_name
						? null
						: {
								component: ArtButtonComponent,
								fallbackTriggers: [{ name: 'onClick', data: col.Name }],
								config: {
									text:
									this.translateService.instant('COMMON.SELECT') + ' ' +
										(this.currentLang === 'ar' ? col.short_name_ar : PlanCategoryEnum[col.short_name] ),
									type: 'button',
									size: 'lg',
								},
							},
			};
		});
	}

	mapDataToTableRows(rates) {
		this.rowLabels = this.benifitsData.map(el => {
			return { name: el.Name };
		});

		return rates.map((item, index) => {
			return {
				...item,
				Name: this.currentLang === 'ar' ? item.short_name_ar : item.short_name,
				subtitle: this.translateService.instant(
					'HI.COVERED_UP_TO_THE_OVERALL_ANNUAL',
				),
				oldAmount: this.getFormattedNumber(
					this.discountValue(item.product_id)(),
				),
				currentAmount: this.getFormattedNumber(
					this.currentProductValue(item.product_id)(),
				),
				note:
					CoverageType.WAFI_BASIC === item.short_name
						? null
						: this.translateService.instant(PlanNameMapEnum[item.short_name]),
				noteStyle: BenefitsStyles[NoteStyleMapping[item.short_name]],
				currency: 'SAR',
				startIcon: this.comparisonTableHelper.getPlanIcon(
					(item.short_name as string).toLowerCase(),
				),
				benefits: this.coverageData[index].reduce((acc, { Name, Value }) => {
					acc[Name] = { value: Value };

					return acc;
				}, {}),
			};
		});
	}
}

export enum PlanNameMapEnum {
	'WAFI Basic'= '',
	'WAFI Smart' = 'INDIVIDUAL_MOTOR.POPULAR',
	'Comprehensive' = 'INDIVIDUAL_MOTOR.RECOMMENDED',
	'Third Party Liability' = 'Third Party Liability',
}

export enum PlanCategoryEnum {
	'Comprehensive' = 'Comprehensive',
	'WAFI Smart' = 'Smart',
	'WAFI Basic' = 'Basic'
}

export enum NoteStyleMapping {
	'WAFI Smart' = 'POPULAR',
	'Comprehensive' = 'RECOMMENDED'
}