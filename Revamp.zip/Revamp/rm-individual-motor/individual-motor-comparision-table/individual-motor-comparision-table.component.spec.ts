import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualMotorComparisionTableComponent } from './individual-motor-comparision-table.component';

describe('IndividualMotorComparisionTableComponent', () => {
  let component: IndividualMotorComparisionTableComponent;
  let fixture: ComponentFixture<IndividualMotorComparisionTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [IndividualMotorComparisionTableComponent]
    });
    fixture = TestBed.createComponent(IndividualMotorComparisionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
