import { Pipe, PipeTransform } from '@angular/core';
// import { CoveragePlan } from '../models/coverage-plan.model'; // Adjust the import based on your model location

@Pipe({
	name: 'sortCoveragePlans',
})
export class SortCoveragePlansPipe implements PipeTransform {
	transform(plans: any[]): any[] {
		return plans.sort((a, b) => a.PolicyPremium - b.PolicyPremium);
	}
}
