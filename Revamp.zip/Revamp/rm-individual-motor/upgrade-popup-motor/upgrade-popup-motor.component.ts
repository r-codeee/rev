import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
@Component({
	selector: 'app-upgrade-popup-motor',
	standalone: true,
	imports: [CommonModule, IconComponent, ArtButtonComponent, TranslateModule],
	templateUrl: './upgrade-popup-motor.component.html',
	styleUrls: ['./upgrade-popup-motor.component.scss'],
})
export class UpgradePopupMotorComponent {
	@Input() btncustomClasses;
	@Input() desc;
	@Input() btnConfirmLabel;
	@Input() btnCloseLabel;
	@Input() btnClass;
	@Input() variant;
	@Input() popupTitle;
	@Input() popupSubTitle;
	@Input() upgradeBtnLabel;
	@Input() upgradToPlanAmount: number = 0;
	@Input() PlanSelectName = '';
	@Input() upgradToPlanName = '';

	currentLang: string;
	@Output() confirm: EventEmitter<any> = new EventEmitter();
	@Output() skip: EventEmitter<boolean> = new EventEmitter();
	@Output() upgrade: EventEmitter<string> = new EventEmitter();
	checkClassTwoBulkUpdate: boolean;
	constructor(private readonly ngbactivemodl: NgbActiveModal) {
		const lang = localStorage.getItem('selectedLang');
		this.currentLang = lang || 'en';
	}
	onUpgrade() {
		this.upgrade.emit(this.upgradToPlanName);
	}
	onDismissModal() {
		this.ngbactivemodl.dismiss();
	}
	skipAndProceed() {
		this.skip.emit(true);
	}
	upgradeToMultiTrip(tripDuration, tierName) {
		this.confirm.emit({ tripDuration: tripDuration, tierName: tierName });
	}
}
