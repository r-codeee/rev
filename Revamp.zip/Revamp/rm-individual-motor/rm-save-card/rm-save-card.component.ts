import { Component, inject, Input, OnInit } from '@angular/core';
import { LanguageService } from 'src/app/utils/services/shared/language.service';

@Component({
	selector: 'art-rm-save-card',
	templateUrl: './rm-save-card.component.html',
	styleUrls: ['./rm-save-card.component.scss'],
})
export class RmSaveCard implements OnInit {
	@Input() value: number = 0;
	private readonly langService = inject(LanguageService);
	currentLang = 'ar';

	constructor() {
		this.langService.getLangObs().subscribe(lang => {
			if (lang) {
				this.currentLang = lang;
			}
		});
	}

	ngOnInit() {}
}
