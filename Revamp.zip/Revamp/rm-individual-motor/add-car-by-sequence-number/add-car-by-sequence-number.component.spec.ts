import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCarBySequenceNumberComponent } from './add-car-by-sequence-number.component';

describe('AddCarBySequenceNumberComponent', () => {
  let component: AddCarBySequenceNumberComponent;
  let fixture: ComponentFixture<AddCarBySequenceNumberComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddCarBySequenceNumberComponent]
    });
    fixture = TestBed.createComponent(AddCarBySequenceNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
