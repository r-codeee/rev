import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { IAddVehicleBySequenceNumber } from 'src/app/rm-individual-motor/types/IAddNewVehicle';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import * as yup from 'yup';
import { ObjectSchema } from 'yup';

@Component({
	selector: 'art-add-car-by-sequence-number',
	templateUrl: './add-car-by-sequence-number.component.html',
	styleUrls: ['./add-car-by-sequence-number.component.scss'],
})
export class AddCarBySequenceNumberComponent extends BaseFormComponent<IAddVehicleBySequenceNumber> {
	@Input() isLoading = false;
	@Input() nationalIdLabelKey = '';
	@Input() nationalIdSubLabelKey = '';
	@Output() onSubmitForm: EventEmitter<IAddVehicleBySequenceNumber> =
		new EventEmitter();

	@Output() onChangeInput: EventEmitter<boolean> = new EventEmitter();

	protected readonly IconComponent = IconComponent;

	validationSchema: ObjectSchema<IAddVehicleBySequenceNumber> = yup
		.object()
		.shape({
			sequenceNumber:
				this.validationRulesService.sequenceNumberValidationRule(),
		});

	values: IAddVehicleBySequenceNumber = {
		sequenceNumber: '',
	};

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private validationRulesService: ArtValidationRulesService,
	) {
		super(formBuilderService);
	}

	onSubmit(values: IAddVehicleBySequenceNumber): void {
		this.onSubmitForm.emit(values);
	}

	changeInput(event) {
		this.onChangeInput.emit(true);
	}
}
