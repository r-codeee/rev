import { CanActivateFn, Router } from '@angular/router';
import { IndividualMotorService } from '../services/individual-motor.service';
import { inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

export const individualMotorGuard: CanActivateFn = (route, state) => {
	const storage: ARTStorageService = inject(ARTStorageService);
	const individualMotorService: IndividualMotorService = inject(
		IndividualMotorService,
	);
	const router: Router = inject(Router);
	// Check if referenceId is found
	const individualMotorData = storage.GetValue(
		individualMotorService.STORAGE_KEY,
	);
	if (individualMotorData?.quoteResponse.reference_number) {
		return true;
	}

	// Redirect to Individual Motor Quotation page
	router.navigate(['/revamp-individual-motor/quotation']);
};
