export const queryKeys = {
	getRatesInfo: (refId: string) => ['getRatesInfo', refId],
};
