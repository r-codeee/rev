import { DropdownOptionType } from 'src/app/design-system/types/DropdownOptionType';
import { ParkingType } from '../enums/ParkingType';
import { PlanCardType } from 'src/app/rm-shared-components/enums/PlanCardType';
import { IPlanCard } from 'src/app/rm-shared-components/types/PlanCard';
import { ICardData } from 'src/app/design-system/motor-card-with-radio/motor-card-with-radio.component';
import { AddNewCarMethods } from '../enums/AddNewCarMethods';

export const PARKING_OPTIONS: Array<DropdownOptionType> = [
	{
		Name_ar: 'شارع',
		Name_en: ParkingType.STREET,
		Id: 1,
		value: ParkingType.STREET,
	},
	{
		Name_ar: 'ممر',
		Name_en: ParkingType.DRIVEWAY,
		Id: 2,
		value: ParkingType.DRIVEWAY,
	},
	{
		Name_ar: 'مرآب',
		Name_en: ParkingType.GARAGE,
		Id: 3,
		value: ParkingType.GARAGE,
	},
];
export const NUM_OF_SEAT_OPTIONS: Array<DropdownOptionType> = [
	{
		Name_en: '2',
		Id: 1,
		value: '2',
	},
	{
		Name_en: '4',
		Id: 2,
		value: '4',
	},
	{
		Name_en: '5',
		Id: 3,
		value: '5',
	},
	{
		Name_en: '7',
		Id: 4,
		value: '7',
	},
	{
		Name_en: '9',
		Id: 5,
		value: '9',
	},
	{
		Name_en: '13',
		Id: 6,
		value: '13',
	},
	{
		Name_en: '13 >',
		Id: 7,
		value: '13 >',
	},
];

export const ENGINE_VOLUME_OPTIONS: Array<DropdownOptionType> = [
	{
		Name_en: '1.3',
		Id: 1,
		value: '1.3',
	},
	{
		Name_en: '1.5',
		Id: 2,
		value: '1.5',
	},
	{
		Name_en: '2',
		Id: 3,
		value: '2',
	},
	{
		Name_en: '2.3',
		Id: 4,
		value: '2.3',
	},
	{
		Name_en: '2.5',
		Id: 5,
		value: '2.5',
	},
	{
		Name_en: '3',
		Id: 6,
		value: '3',
	},
	{
		Name_en: '3.2',
		Id: 7,
		value: '3.2',
	},
	{
		Name_en: '3.5',
		Id: 8,
		value: '3.5',
	},
	{
		Name_en: '4',
		Id: 9,
		value: '4',
	},
	{
		Name_en: '4.2',
		Id: 10,
		value: '4.2',
	},
	{
		Name_en: '4.5',
		Id: 11,
		value: '4.5',
	},
	{
		Name_en: '5',
		Id: 12,
		value: '5',
	},
	{
		Name_en: '5.2',
		Id: 13,
		value: '5.2',
	},
	{
		Name_en: '5.5',
		Id: 14,
		value: '5.5',
	},
	{
		Name_en: '6',
		Id: 15,
		value: '6',
	},
	{
		Name_en: '6.5 >',
		Id: 16,
		value: '6.5 >',
	},
];

export const PLANS: Array<IPlanCard> = [
	{
		planDisplayName: 'INDIVIDUAL_MOTOR.WAFI_BASIC',
		planName: 'Basic',
		iconName: 'basic',
		CoverageName: '',
	},
	{
		planDisplayName: 'INDIVIDUAL_MOTOR.WAFI_SMART',
		planName: 'Smart',
		iconName: 'smart',
		CoverageName: 'INDIVIDUAL_MOTOR.MOST_POPULAR',
		type: PlanCardType.POPULAR,
	},
	{
		planDisplayName: 'INDIVIDUAL_MOTOR.COMPREHENSIVE_PLAN',
		planName: 'Comprehensive',
		iconName: 'comprehensive',
		CoverageName: 'INDIVIDUAL_MOTOR.RECOMMENDED',
		type: PlanCardType.RECOMMENDED,
	},
];

export const ADD_CAR_METHODS: Array<ICardData> = [
	{
		id: AddNewCarMethods.SEQUENCE_NUMBER,
		title: 'INDIVIDUAL_MOTOR.SEQUENCE_NUMBER',
		icon: 'Sequence-car',
		description: 'INDIVIDUAL_MOTOR.PRE_OWNED_CAR',
		active: false,
	},
	{
		id: AddNewCarMethods.OWNERSHIP_TRANSFER,
		title: 'INDIVIDUAL_MOTOR.OWNERSHIP_TRANSFER',
		icon: 'art-left-right-arrows',
		description: 'INDIVIDUAL_MOTOR.I_OWN_CAR',
		active: false,
	},
	{
		id: AddNewCarMethods.CUSTOM_NUMBER,
		title: 'INDIVIDUAL_MOTOR.CUSTOM_NUMBER',
		icon: 'art-dashed-line',
		description: 'INDIVIDUAL_MOTOR.I_OWN_CAR',
		active: false,
	},
];
