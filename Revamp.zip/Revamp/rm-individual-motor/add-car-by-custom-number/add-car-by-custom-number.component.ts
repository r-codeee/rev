import { Component, EventEmitter, Input, Output } from '@angular/core';
import { IAddVehicleByCustomNumber } from 'src/app/rm-individual-motor/types/IAddNewVehicle';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import * as yup from 'yup';
import { ObjectSchema } from 'yup';
import * as moment from 'moment';

type AddVehicleByCustomNumberFormValues = Omit<
	IAddVehicleByCustomNumber,
	'nationalIdNumber'
>;

@Component({
	selector: 'art-add-car-by-custom-number',
	templateUrl: './add-car-by-custom-number.component.html',
	styleUrls: ['./add-car-by-custom-number.component.scss'],
})
export class AddCarByCustomNumberComponent extends BaseFormComponent<AddVehicleByCustomNumberFormValues> {
	@Input() isLoading: boolean;
	maxVehicleProductionYear = moment().add(1, 'years').year();

	@Output() onSubmitForm: EventEmitter<IAddVehicleByCustomNumber> =
		new EventEmitter();

	@Output() onChangeInput: EventEmitter<any> = new EventEmitter();

	protected readonly String = String;

	validationSchema: ObjectSchema<AddVehicleByCustomNumberFormValues> = yup
		.object()
		.shape({
			customNumber: this.validationRulesService.customNumberValidationRule(),
			vehicleProductionYear: yup.number().max(this.maxVehicleProductionYear),
		});

	values: AddVehicleByCustomNumberFormValues = {
		customNumber: '',
		vehicleProductionYear: null,
	};

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private validationRulesService: ArtValidationRulesService,
	) {
		super(formBuilderService);
	}

	onSubmit(values: AddVehicleByCustomNumberFormValues): void {
		this.onSubmitForm.emit(values as IAddVehicleByCustomNumber);
	}
	changeInput(event) {
		this.onChangeInput.emit(true);
	}
}
