import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCarByCustomNumberComponent } from './add-car-by-custom-number.component';

describe('AddCarByCustomNumberComponent', () => {
  let component: AddCarByCustomNumberComponent;
  let fixture: ComponentFixture<AddCarByCustomNumberComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddCarByCustomNumberComponent]
    });
    fixture = TestBed.createComponent(AddCarByCustomNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
