import { Component, inject, OnInit } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { IndividualMotorService } from '../services/individual-motor.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SendVehicleImagesComponent } from 'src/app/design-system/send-vehicle-images/send-vehicle-images.component';
import { Router } from '@angular/router';

@Component({
	selector: 'app-rm-individual-motor-otp',
	templateUrl: './rm-individual-motor-otp.component.html',
	styleUrls: ['./rm-individual-motor-otp.component.scss'],
})
export class RmIndividualMotorOtpComponent implements OnInit {
	constructor(
		private individualMotor: IndividualMotorService,
		private readonly ngbModal: NgbModal,
	) {}
	isRenewalPolicy;
	private storage = inject(ARTStorageService);
	redirectUrl: string;
	referenceId: string;
	apiLoading = false;
	firstName: string;
	sendVechilImagModalRef;
	showQrCode = this.storage.GetValue('showQrCode');
	private router = inject(Router);
	ngOnInit(): void {
		this.isRenewalPolicy = this.storage.GetValue('is-Renewal-Policy');
		const storageData = this.storage.GetValue(this.individualMotor.STORAGE_KEY);
		this.referenceId = storageData.quoteResponse.reference_number;
	}

	onOTPVerified() {
		if (this.showQrCode) {
			this.GR_code();
		} else {
			this.redirectUrl =
				'/revamp-individual-motor/motor-individual-quotation-stepper/payment';
			this.router.navigate([
				'/revamp-individual-motor/motor-individual-quotation-stepper/payment',
			]);
		}
	}

	GR_code() {
		this.apiLoading = true;
		let payload = {
			reference_number: this.referenceId,
		};

		this.individualMotor.QR_code(payload).subscribe({
			next: res => {
				this.openUpgradePopup(res);
				this.apiLoading = false;
			},
			error: err => {
				this.apiLoading = false;
			},
		});
	}

	openUpgradePopup(res) {
		this.sendVechilImagModalRef = this.ngbModal.open(
			SendVehicleImagesComponent,
			{
				centered: true,
				windowClass: 'upload-popup',
				backdrop: 'static',
				beforeDismiss: () => false,
			},
		);

		this.sendVechilImagModalRef.componentInstance.customerName = this.firstName;

		this.sendVechilImagModalRef.componentInstance.QR_data = res.data;
		this.sendVechilImagModalRef.componentInstance.SendVehicleImages.subscribe(
			event => {
				this.apiLoading = true;
				let payload = {
					reference_number: this.referenceId,
				};

				this.sendVechilImagModalRef.componentInstance.error = false;
				this.sendVechilImagModalRef.componentInstance.status = false;
				this.individualMotor.uploadImageSms(payload).subscribe({
					next: res => {
						if (res.status) {
							this.sendVechilImagModalRef.componentInstance.status = res.status;
						}

						this.apiLoading = false;
					},
					error: err => {
						this.sendVechilImagModalRef.componentInstance.error = true;
						this.apiLoading = false;
					},
				});
			},
		);

		this.sendVechilImagModalRef.componentInstance.skip.subscribe(() => {
			// Do not close the modal
			console.log('Skip clicked, modal remains open.');
		});
	}
}
