import { Component } from '@angular/core';

@Component({
	selector: 'art-rm-individual-motor-quotation-otp',
	templateUrl: './rm-individual-motor-quotation-otp.component.html',
	styleUrls: ['./rm-individual-motor-quotation-otp.component.scss'],
})
export class RmIndividualMotorQuotationOtpComponent {}
