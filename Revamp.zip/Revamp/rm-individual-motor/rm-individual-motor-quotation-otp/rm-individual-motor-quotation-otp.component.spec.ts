import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorQuotationOtpComponent } from './rm-individual-motor-quotation-otp.component';

describe('RmIndividualMotorQuotationOtpComponent', () => {
  let component: RmIndividualMotorQuotationOtpComponent;
  let fixture: ComponentFixture<RmIndividualMotorQuotationOtpComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorQuotationOtpComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorQuotationOtpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
