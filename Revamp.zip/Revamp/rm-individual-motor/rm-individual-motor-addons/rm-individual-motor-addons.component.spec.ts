import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorAddonsComponent } from './rm-individual-motor-addons.component';

describe('RmIndividualMotorAddonsComponent', () => {
  let component: RmIndividualMotorAddonsComponent;
  let fixture: ComponentFixture<RmIndividualMotorAddonsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorAddonsComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorAddonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
