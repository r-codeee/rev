import { Component, EventEmitter, inject, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { IAddonView } from '../models/individualMotorDto';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { Subscription } from 'rxjs';
import { IndividualMotorService } from '../services/individual-motor.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Component({
	selector: 'app-rm-individual-motor-addons',
	templateUrl: './rm-individual-motor-addons.component.html',
	styleUrls: ['./rm-individual-motor-addons.component.scss'],
})
export class RmIndividualMotorAddonsComponent implements OnChanges{
	@Input() addons: Array<any> = [];
	@Input() selectedAddons: Array<any> = [];
	@Input() selectedVehicleRiskId;
	@Input() addonsSelectedData: Array<any> = [];
	selectedAddon: IAddonView;
	currentLang ;
	@Output() addonsSelected = new EventEmitter<any>();
	@Output() addonsDeleted = new EventEmitter<any>();
	isProcessing: boolean = false;
	private individualMotor = inject(IndividualMotorService);

	constructor(private readonly langService: LanguageService,private readonly languageService: RMLanguageService,) {}
	ngOnChanges(changes: SimpleChanges): void {
		if(changes?.selectedVehicleRiskId?.currentValue != changes?.selectedVehicleRiskId?.previousValue){
			let result = this.addons.map(item => {
				let elm = this.addonsSelectedData.find(
					addon =>
						addon.addl_details.cover_id == item.cover_id &&
						addon.risk_id[0] == this.selectedVehicleRiskId,
				);
				if (elm) {
					return { ...item, isSelected: 1, };
				} else {
					return { ...item,isSelected: 0, };
				}
			});
			this.addons = result;
		}
	}
	private sub = new Subscription();
	ngOnInit() {
		this.languageService.toggleLang.subscribe(res => {
			if (res) {
				this.currentLang = this.languageService.activeLang();
			}
		});
		this.currentLang = this.languageService.activeLang();
		this.currentLang  = this.langService.currentLang;
		this.selectedAddon = this.addons[0];
	}

	// new function to map the seleceted addons to the all addons

	listenToAddAddon() {
		this.sub.add(
			this.individualMotor.addAddons$.subscribe((res: any) => {
				const addon = this.addons.find(el => el.cover_id === res?.cover_id);
				this.selectAddons(addon);
			}),
		);
	}

	selectAddons(data) {
		const index = this.addons.findIndex(addon =>
			addon.cover_id == data?.value?.cover_id
				? data?.value?.cover_id
				: data?.cover_id,
		);

		if (index === -1) return;
		const addon = this.addons[index];
		if (data.isChecked) {
			addon.isSelected = 1;
			this.addonsSelected.emit(addon);
		} else if (!data.isChecked) {
			addon.isSelected = 0;
			this.addonsDeleted.emit(addon);
		}
	}

	onshowBenefits(addon) {
		console.log(addon);
	}
}
