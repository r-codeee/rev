import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorPaymentComponent } from './rm-individual-motor-payment.component';

describe('RmIndividualMotorPaymentComponent', () => {
  let component: RmIndividualMotorPaymentComponent;
  let fixture: ComponentFixture<RmIndividualMotorPaymentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorPaymentComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
