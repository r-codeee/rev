import { Component, inject, OnInit, signal } from '@angular/core';
import { RateDetails, UserInfo } from '../../rm-payment/model/payment-details';
import { concatMap, switchMap } from 'rxjs';
import { ARTStorageService } from '../../utils/services/shared/storage.service';
import { paymentMethods } from '../../rm-payment/config/payment-methods-list.config';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { IndividualMotorService } from '../services/individual-motor.service';
import { QuoteUpdatePayload } from '../models/individual-motor-payment';
import { PaymentMethodStructure } from '../../rm-payment/model/paymentMethodTypes';

@Component({
	selector: 'art-rm-individual-motor-payment',
	templateUrl: './rm-individual-motor-payment.component.html',
	styleUrls: ['./rm-individual-motor-payment.component.scss'],
})
export class RmIndividualMotorPaymentComponent implements OnInit {
	keys = signal<string[]>([
		'fullName',
		'mobileNumber',
		'emailAddress',
		'address',
	]);
	keysCoverage = signal<string[]>(['productType']);
	protected insuranceData!: UserInfo;
	protected selectedPremium!: RateDetails;
	private state = inject(ARTStorageService);
	protected readonly TransactionTypes = TransactionTypes;
	paymentMethods: PaymentMethodStructure = paymentMethods;
	motorIndividualService = inject(IndividualMotorService);
	ngOnInit(): void {
		this.getPaymentMethods();
		this.getPayment();
	}

	private getPayment() {
		this.state.GetValue('referenceId');
		console.log(
			this.state.GetValue(this.motorIndividualService.STORAGE_KEY)
				?.reference_number,
		);
		this.motorIndividualService
			.getUserInfo()
			.pipe(
				switchMap(res => {
					return this.motorIndividualService.getPaymentDetails({
						reference_number: this.state.GetValue(
							this.motorIndividualService.STORAGE_KEY,
						)?.reference_number,
					});
				}),
			)
			.pipe(
				concatMap(res => {
					console.log(res, 'nuetrinous');
					//	debugger;
					this.insuranceData = res.userInfo;
					this.insuranceData['mobileNumber'] = this.insuranceData[
						'mobileNumber'
					].startsWith('+966')
						? this.insuranceData['mobileNumber']
						: '+966 ' + this.insuranceData['mobileNumber'];
					console.log('asj', this.insuranceData);
					this.selectedPremium = res.paymentInfo;
					this.selectedPremium['PlanType'] = this.insuranceData['productType'];
					this.state.Setvalue(
						'policyPaymentCoverage',
						this.insuranceData?.productType,
					);

					return this.motorIndividualService.getUserInfo();
				}),
			)
			.pipe(
				concatMap(calc => {
					return this.motorIndividualService.quoteCalculatePremium({
						id: this.insuranceData.quotationId,
					});
				}),
			)
			.pipe(
				concatMap(premimum => {
					this.selectedPremium.TotalPremium = premimum?.premium;
					return this.motorIndividualService.getRate({
						reference_number: this.state.GetValue(
							this.motorIndividualService.STORAGE_KEY,
						)?.reference_number,
					});
				}),
			)

			.pipe(
				concatMap(res => {
					const payload: QuoteUpdatePayload = {
						id: this.insuranceData.quotationId,
						source: 'btc',
						status_id: 1,
						addl_details: {
							current_stage: 'SINGLE_PAYMENT_SCREEN',
							is_history: true,
						},
					};
					return this.motorIndividualService.updateQuotation(payload);
				}),
			)
			.subscribe(update => {
				console.log('update', update);
				this.state.Setvalue(
					'totalPremiumVal',
					this.selectedPremium?.TotalPremium,
				);
				this.state.Setvalue('policyId', this.insuranceData.quotationId);
				this.state.Setvalue('name', this.insuranceData.fullName);
				this.state.Setvalue('paymentFrom', this.insuranceData.policyStartDate);
				this.state.Setvalue('paymentTo', this.insuranceData.policyEndDate);
				this.state.Setvalue(
					'paymentAmount',
					this.selectedPremium?.TotalPremium,
				);
			});
	}
	refreshData(ev) {
		if (ev) {
			this.getPayment();
		}
	}
	private getPaymentMethods() {
		const refNum = this.state.GetValue(
			this.motorIndividualService.STORAGE_KEY,
		)?.reference_number;
		this.motorIndividualService.getPaymentOption(refNum).subscribe(res => {
			this.paymentMethods = res;
		});
	}
}
