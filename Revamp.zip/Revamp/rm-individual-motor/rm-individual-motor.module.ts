import { NgModule } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { AlertComponent } from 'src/app/design-system/alert/alert.component';
import { AnimationComponent } from 'src/app/design-system/animation/animation.component';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { LoadingHideDirective } from 'src/app/design-system/directives/loading-hide.directive';
import { DoYouNeedHelpComponent } from 'src/app/design-system/do-you-need-help/do-you-need-help.component';
import { FeatureBenefitsComponent } from 'src/app/design-system/feature-benefits/feature-benefits.component';
import { IconButtonComponent } from 'src/app/design-system/icon-button/icon-button.component';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { InsuranceOverviewComponent } from 'src/app/design-system/insurance-overview/insurance-overview.component';
import { ManageYourPolicyOnlineSectionComponent } from 'src/app/design-system/manage-your-policy-online-section/manage-your-policy-online-section.component';
import { PhoneBasicInputComponent } from 'src/app/design-system/phone-basic-input/phone-basic-input.component';
import { ProductFAQComponent } from 'src/app/design-system/product-FAQ/product-FAQ.component';
import { ProductInsuranceSideMenuComponent } from 'src/app/design-system/product-insurance-side-menu/product-insurance-side-menu.component';
import { ProductServicesComponent } from 'src/app/design-system/product-services/product-services.component';
import { QuotationFormPageComponent } from 'src/app/design-system/quotation-form-page/quotation-form-page.component';
import { StepperFooterComponent } from 'src/app/design-system/stepper-footer/stepper-footer.component';
import { StepperComponent } from 'src/app/design-system/stepper/stepper.component';
import { SwitchBusinessIndividualComponent } from 'src/app/design-system/switch-business-individual/switch-business-individual.component';
// tslint:disable-next-line:max-line-length
import { IndividualMotorCoverageComponent } from 'src/app/rm-individual-motor/rm-individual-motor-home/individual-motor-coverage/individual-motor-coverage.component';
import { VehicleMakerModelPipe } from 'src/app/rm-individual-motor/vehicle-maker-model.pipe';
import { RmHeaderComponent } from 'src/app/rm-payment/components/rm-header/rm-header.component';
import { GetQuoteFormComponent } from 'src/app/rm-shared-components/get-quote-form/get-quote-form.component';
import { MotorCoverageOverviewComponent } from 'src/app/rm-shared-components/motor-coverage-overview/motor-coverage-overview.component';
import { PickLocalizedNamePipe } from 'src/app/rm-shared-components/pipes/pick-localized-name.pipe';
import { ProductHomeComponent } from 'src/app/rm-shared-components/product-home/product-home.component';
import { ArtFormsModule } from 'src/art-forms/art-forms.module';

import { RmCustomOptionsComponent } from '../design-system/rm-custom-options/rm-custom-options.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RmDateInputComponent } from '../design-system/rm-date-input/rm-date-input.component';
import { ArtComparisonCard } from '../design-system/rm-comparison-card/rm-comparison-card';
import { ArtDeviderCard } from '../design-system/rm-devider-card/rm-devider-card';
import { ArtProductSummaryCard } from '../design-system/rm-product-summary-card/rm-product-summary-card';
import { ArtProductPlanCard } from '../design-system/rm-product-plan-card/rm-product-plan-card';
import { MatExpansionModule } from '@angular/material/expansion';
import { RMIndividualMotorRoutingModule } from './rm-individual-motor-routing.module';
import { RmIndividualMotorHomeComponent } from './rm-individual-motor-home/rm-individual-motor-home.component';
import { RmIndividualMotorFAQComponent } from './rm-individual-motor-home/rm-individual-motor-FAQ/rm-individual-motor-FAQ.component';
import { RmIndividualMotorFeatureBenefitsComponent } from './rm-individual-motor-home/rm-individual-motor-feature-benefits/rm-individual-motor-feature-benefits.component';
import { GetIndividualMotorQuoteFormComponent } from './rm-individual-motor-home/rm-individual-motor-overview/get-individual-motor-quote-form/get-individual-motor-quote-form.component';
import { RmIndividualMotorServicesComponent } from './rm-individual-motor-home/rm-individual-motor-services/rm-individual-motor-services.component';
import { RmIndividualMotorOverviewComponent } from './rm-individual-motor-home/rm-individual-motor-overview/rm-individual-motor-overview.component';
import { ShariahAndInsuranceAuthorityComponent } from '../design-system/shariah-and-insurance-authority/shariah-and-insurance-authority.component';
import { RmIndividualMotorOtpComponent } from './rm-individual-motor-otp/rm-individual-motor-otp.component';
import { RMOtpModule } from '../rm-otp/rm-otp.module';
import { DiscoverProductComponent } from '../design-system/discover-product/discover-product.component';
import { RmIndividualMotorQuotationComponent } from './rm-individual-motor-quotation/rm-individual-motor-quotation.component';
import { BreadcrumbComponent } from '../design-system/breadcrumb/breadcrumb.component';
import { MotorCardWithRadioComponent } from '../design-system/motor-card-with-radio/motor-card-with-radio.component';
import { IndividualMotorConfirmationPaymentComponent } from './rm-individual-motor-confirmation-payment/rm-individual-motor-confirmation-payment.component';
import { RmPaymentConfirmationPageComponent } from '../rm-payment-confirmation-page/rm-payment-confirmation-page.component';
import { RMIndividualMotorTrackRequestComponent } from './rm-individual-motor-track-request/rm-individual-motor-track-request.component';
import { ArtTrackRequest } from '../design-system/rm-track-request/rm-track-request.component';
import { MotorPlanCardComponent } from '../design-system/motor-plan-card/motor-plan-card.component';
import { RmMotorIndividualPremiumCalculationComponent } from './rm-motor-individual-premium-calculation/rm-motor-individual-premium-calculation.component';
import { RmIndividualMotorPaymentComponent } from './rm-individual-motor-payment/rm-individual-motor-payment.component';
import { RmIndividualMotorStepperComponent } from './rm-individual-motor-stepper/rm-individual-motor-stepper.component';
import { CarInformationComponent } from './car-information/car-information.component';
import { AddNewCarFormComponent } from './add-new-car-form/add-new-car-form.component';
import { CarsListOfCardComponent } from './cars-list-of-card/cars-list-of-card.component';
import { AddCarBySequenceNumberComponent } from './add-car-by-sequence-number/add-car-by-sequence-number.component';
import { IndividualMotorFormComponent } from './individual-motor-form/individual-motor-form.component';
import { IndividualMotorQuotationFormValidationSchemaService } from './services/individual-motor-quotation-form-validation-schema.service';
import { CustomDropdownComponent } from '../design-system/custom-dropdown/custom-dropdown.component';
import { AddCarByCustomNumberComponent } from './add-car-by-custom-number/add-car-by-custom-number.component';
import { CarDetailsCardComponent } from './car-details-card/car-details-card.component';
import { AddNewCarMultiButtonComponent } from 'src/app/rm-individual-motor/add-new-car-multi-button/add-new-car-multi-button.component';
import { RmVehicleDetailsComponent } from './rm-vehicle-details/rm-vehicle-details.component';
import { RmAddCarInformationsComponent } from './rm-add-car-informations/rm-add-car-informations.component';
import { RmPaymentComponent } from '../rm-payment/components/rm-payment/rm-payment.component';
import { RmIndividualMotorAddonsComponent } from './rm-individual-motor-addons/rm-individual-motor-addons.component';
import { RmIndividualMotorAddDriverComponent } from './rm-individual-motor-add-driver/rm-individual-motor-add-driver.component';
import { RmAccordionComponent } from '../design-system/rm-accordion/rm-accordion.component';
import { CheckboxInputWithTextComponent } from '../design-system/checkbox-input-with-text/checkbox-input-with-text.component';
import { StepperFooterWithExpandableAdditionalInfoComponent } from '../design-system/stepper-footer-with-expandable-additional-info/stepper-footer-with-expandable-additional-info.component';
import { MotorAdditionalInfoFormValidationSchemaService } from './services/motor-additional-info-form-validation-schema.service';
import { RmHeaderDesktopCommonComponent } from '../design-system/rm-header-desktop-common/rm-header-desktop-common.component';
import { RmIndividualMotorQuotationOtpComponent } from './rm-individual-motor-quotation-otp/rm-individual-motor-quotation-otp.component';
import { RenewalPopupComponent } from './rm-renewal/renewal-popup/renewal-popup.component';
import { RmRenewalOtpComponent } from './rm-renewal/rm-renewal-otp/rm-renewal-otp.component';
import { RmRenewalStepperComponent } from './rm-renewal/rm-renewal-stepper/rm-renewal-stepper.component';
import { RmRenewalListVehiclesComponent } from './rm-renewal/rm-renewal-list-vehicles/rm-renewal-list-vehicles.component';
import { RmRenewPolicyComponent } from './rm-renewal/rm-renew-policy/rm-renew-policy.component';
import { OtpComponent } from '../design-system/otp/otp.component';
import { RmIndividualRenewalPaymentComponent } from './rm-renewal/rm-individual-renewal-payment/rm-individual-renewal-payment.component';
import { SendVehicleImagesComponent } from '../design-system/send-vehicle-images/send-vehicle-images.component';
import { RMIndividualMotorModalComponent } from './rm-individual-motor-modal/rm-individual-motor-modal.component';
import { QRCodeComponent } from 'angularx-qrcode';
import { RmTabbyCard } from './rm-tabby-card/rm-tabby-card.component';
import { RmCustomOptionsControlComponent } from '../design-system/rm-custom-options-control/rm-custom-options-control.component';
import { SortCoveragePlansPipe } from './pipes/sort-coverage-plans.pipe';
import { CustomDropdownMultiselectComponent } from '../design-system/custom-dropdown-multiselect/custom-dropdown-multiselect.component';
import { AddCarByOwnershipNumberComponent } from './add-car-by-ownership-number/add-car-by-ownership-number.component';
import { RmIndividualMotorScanQrStepperComponent } from './rm-individual-motor-scan-qr/rm-individual-motor-scan-qr-stepper/rm-individual-motor-scan-qr-stepper.component';
import { QrCarsListComponent } from './rm-individual-motor-scan-qr/qr-cars-list/qr-cars-list.component';
import { QrCarsPhotoComponent } from './rm-individual-motor-scan-qr/qr-cars-photo/qr-cars-photo.component';
import { ArtCarsQrListComponent } from './rm-individual-motor-scan-qr/art-cars-qr-list/art-cars-qr-list.component';
import { LivePhotoCameraComponent } from './rm-individual-motor-scan-qr/qr-cars-photo/live-photo-camera/live-photo-camera.component';
import { CarsQrUploadedComponent } from './rm-individual-motor-scan-qr/cars-qr-uploaded/cars-qr-uploaded.component';
import { RmDriverListCard } from '../design-system/rm-driver-list-card/rm-driver-list-card.component';
import { RmVehicleListDetailsPopupComponent } from './rm-vehicle-list-details-popup/rm-vehicle-list-details-popup.component';
import { QrOtpScreenComponent } from './rm-individual-motor-scan-qr/qr-otp-screen/qr-otp-screen.component';
import { RmSaveCard } from './rm-save-card/rm-save-card.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { RmUpdateInfoPopupComponent } from './rm-renewal/rm-update-info-popup/rm-update-info-popup.component';
import { RmUpdateInformationComponent } from './rm-renewal/rm-update-information/rm-update-information.component';
import { RmSuccessPopupComponent } from './rm-renewal/rm-success-popup/rm-success-popup.component';
import { RmUpdateSequenceNumberPopupComponent } from './rm-renewal/rm-update-sequence-number-popup/rm-update-sequence-number-popup.component';
import { RmRewardCardComponent } from '../design-system/rm-reward-card/rm-reward-card.component';

@NgModule({
	declarations: [
		RmIndividualMotorHomeComponent,
		RmIndividualMotorOverviewComponent,
		RmIndividualMotorFeatureBenefitsComponent,
		RmIndividualMotorServicesComponent,
		RmIndividualMotorFAQComponent,
		GetIndividualMotorQuoteFormComponent,
		RmIndividualMotorOtpComponent,
		RmIndividualMotorQuotationComponent,
		IndividualMotorConfirmationPaymentComponent,
		RMIndividualMotorTrackRequestComponent,
		RmMotorIndividualPremiumCalculationComponent,
		RmIndividualMotorPaymentComponent,
		RmIndividualMotorStepperComponent,
		CarInformationComponent,
		AddNewCarFormComponent,
		CarsListOfCardComponent,
		AddCarBySequenceNumberComponent,
		IndividualMotorFormComponent,
		CarInformationComponent,
		AddNewCarFormComponent,
		CarsListOfCardComponent,
		AddCarBySequenceNumberComponent,
		AddCarByCustomNumberComponent,
		CarDetailsCardComponent,
		AddNewCarMultiButtonComponent,
		RmVehicleDetailsComponent,
		RmAddCarInformationsComponent,
		RmIndividualMotorAddonsComponent,
		RmIndividualMotorAddDriverComponent,
		RmIndividualMotorQuotationOtpComponent,
		RenewalPopupComponent,
		RmRenewalOtpComponent,
		RmRenewalStepperComponent,
		RmRenewalListVehiclesComponent,
		RmRenewPolicyComponent,
		RmIndividualRenewalPaymentComponent,
		RmTabbyCard,
		IndividualMotorCoverageComponent,
		SortCoveragePlansPipe,
		RmIndividualMotorScanQrStepperComponent,
		QrCarsListComponent,
		QrCarsPhotoComponent,
		AddCarByOwnershipNumberComponent,
		RmVehicleListDetailsPopupComponent,
		LivePhotoCameraComponent,
		CarsQrUploadedComponent,
		QrOtpScreenComponent,
		RmSaveCard,
		RmUpdateInfoPopupComponent,
		RmUpdateInformationComponent,
		RmSuccessPopupComponent,
		RmUpdateSequenceNumberPopupComponent,
	],
	imports: [
		ArtFormsModule,
		CommonModule,
		RMIndividualMotorRoutingModule,
		SwitchBusinessIndividualComponent,
		TranslateModule,
		InsuranceOverviewComponent,
		ManageYourPolicyOnlineSectionComponent,
		ProductInsuranceSideMenuComponent,
		FeatureBenefitsComponent,
		ProductServicesComponent,
		ProductFAQComponent,
		DoYouNeedHelpComponent,
		FormsModule,
		ReactiveFormsModule,
		RmCustomOptionsComponent,
		ArtButtonComponent,
		RmDateInputComponent,
		ArtProductPlanCard,
		ArtProductSummaryCard,
		ArtComparisonCard,
		ArtDeviderCard,
		MatExpansionModule,
		BasicInputComponent,
		PhoneBasicInputComponent,
		IconComponent,
		GetQuoteFormComponent,
		AnimationComponent,
		LoadingHideDirective,
		StepperComponent,
		StepperFooterComponent,
		StepperFooterWithExpandableAdditionalInfoComponent,
		ShariahAndInsuranceAuthorityComponent,
		RMOtpModule,
		DiscoverProductComponent,
		BreadcrumbComponent,
		MotorCardWithRadioComponent,
		RmPaymentConfirmationPageComponent,
		ArtTrackRequest,
		MotorPlanCardComponent,
		RmHeaderComponent,
		CustomDropdownComponent,
		AlertComponent,
		NgOptimizedImage,
		IconButtonComponent,
		PickLocalizedNamePipe,
		VehicleMakerModelPipe,
		RmPaymentComponent,
		QuotationFormPageComponent,
		RmAccordionComponent,
		CheckboxInputWithTextComponent,
		RmHeaderDesktopCommonComponent,
		ProductHomeComponent,
		OtpComponent,
		SendVehicleImagesComponent,
		RMIndividualMotorModalComponent,
		QRCodeComponent,
		RmCustomOptionsControlComponent,
		CustomDropdownMultiselectComponent,
		MotorCoverageOverviewComponent,
		ArtCarsQrListComponent,
		RmDriverListCard,
		SlickCarouselModule,
		RmRewardCardComponent
	],
	providers: [
		IndividualMotorQuotationFormValidationSchemaService,
		MotorAdditionalInfoFormValidationSchemaService,
	],
})
export class RMIndividualMotorModule {}
