import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
	selector: 'art-add-new-car-multi-button',
	templateUrl: './add-new-car-multi-button.component.html',
	styleUrls: ['./add-new-car-multi-button.component.scss'],
})
export class AddNewCarMultiButtonComponent {
	@Input() countOfAddedCars = 1;
	allowedCountOfCars = 5;

	@Output() clickAddNewCar = new EventEmitter();

	handleClick() {
		if (this.countOfAddedCars >= this.allowedCountOfCars) return;
		this.clickAddNewCar.emit();
		
	}
}
