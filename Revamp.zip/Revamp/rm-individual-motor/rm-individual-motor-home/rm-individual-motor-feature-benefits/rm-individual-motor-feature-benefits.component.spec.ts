import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorFeatureBenefitsComponent } from './rm-individual-motor-feature-benefits.component';

describe('RmIndividualMotorFeatureBenefitsComponent', () => {
	let component: RmIndividualMotorFeatureBenefitsComponent;
	let fixture: ComponentFixture<RmIndividualMotorFeatureBenefitsComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [RmIndividualMotorFeatureBenefitsComponent],
		});
		fixture = TestBed.createComponent(
			RmIndividualMotorFeatureBenefitsComponent,
		);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
