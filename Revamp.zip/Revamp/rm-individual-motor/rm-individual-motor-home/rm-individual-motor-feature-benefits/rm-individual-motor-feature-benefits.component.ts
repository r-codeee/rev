import { Component } from '@angular/core';
import { FeatureBenefitType } from 'src/app/design-system/types/FeatureBenefitType';

@Component({
	selector: 'art-individual-motor-feature-benefits',
	templateUrl: './rm-individual-motor-feature-benefits.component.html',
	styleUrls: ['./rm-individual-motor-feature-benefits.component.scss'],
})
export class RmIndividualMotorFeatureBenefitsComponent {
	description = 'INDIVIDUAL_MOTOR.BENEFITS_DESCRIPTION';
	benefits: Array<FeatureBenefitType> = [
		{
			icon: 'fa-light fa-cars',
			title: 'INDIVIDUAL_MOTOR.FEATURE_1_TITLE',
			description: 'INDIVIDUAL_MOTOR.FEATURE_1_DESC',
		},
		{
			icon: 'fa-light fa-tags',
			title: 'INDIVIDUAL_MOTOR.FEATURE_2_TITLE',
			description: 'INDIVIDUAL_MOTOR.FEATURE_2_DESC',
		},
		{
			icon: 'fa-light fa-badge-percent',
			title: 'INDIVIDUAL_MOTOR.FEATURE_3_TITLE',
			description: 'INDIVIDUAL_MOTOR.FEATURE_3_DESC',
		},
	];
}
