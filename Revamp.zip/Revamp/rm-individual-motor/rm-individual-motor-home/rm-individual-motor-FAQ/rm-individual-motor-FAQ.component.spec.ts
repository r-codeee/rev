import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RmIndividualMotorFAQComponent } from './rm-individual-motor-FAQ.component';

describe('RmIndividualMotorFAQComponent', () => {
	let component: RmIndividualMotorFAQComponent;
	let fixture: ComponentFixture<RmIndividualMotorFAQComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [RmIndividualMotorFAQComponent],
		});
		fixture = TestBed.createComponent(RmIndividualMotorFAQComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
