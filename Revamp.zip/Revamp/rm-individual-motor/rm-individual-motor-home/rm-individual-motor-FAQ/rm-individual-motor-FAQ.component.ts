import { Component } from '@angular/core';

@Component({
	selector: 'art-individual-motor-FAQ',
	templateUrl: './rm-individual-motor-FAQ.component.html',
	styleUrls: ['./rm-individual-motor-FAQ.component.scss'],
})
export class RmIndividualMotorFAQComponent {}
/*
	[FAQListData]="[
		{
			id: 1,
			question: 'INDIVIDUAL_MOTOR.FAQ_QUESTION_1',
			answer: ['INDIVIDUAL_MOTOR.FAQ_ANSWER_1'],
		},
		{
			id: 2,
			question: 'INDIVIDUAL_MOTOR.FAQ_QUESTION_2',
			answer: ['INDIVIDUAL_MOTOR.FAQ_ANSWER_2'],
		},
		{
			id: 3,
			question: 'INDIVIDUAL_MOTOR.FAQ_QUESTION_3',
			answer: ['INDIVIDUAL_MOTOR.FAQ_ANSWER_3'],
		},
		{
			id: 4,
			question: 'INDIVIDUAL_MOTOR.FAQ_QUESTION_4',
			answer: ['INDIVIDUAL_MOTOR.FAQ_ANSWER_4'],
		},
	]"
*/