import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorServicesComponent } from './rm-individual-motor-services.component';

describe('RmIndividualMotorServicesComponent', () => {
	let component: RmIndividualMotorServicesComponent;
	let fixture: ComponentFixture<RmIndividualMotorServicesComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [RmIndividualMotorServicesComponent],
		});
		fixture = TestBed.createComponent(RmIndividualMotorServicesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
