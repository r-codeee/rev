import { Component } from '@angular/core';
import { FeatureBenefitType } from 'src/app/design-system/types/FeatureBenefitType';

@Component({
	selector: 'art-individual-motor-services',
	templateUrl: './rm-individual-motor-services.component.html',
	styleUrls: ['./rm-individual-motor-services.component.scss'],
})
export class RmIndividualMotorServicesComponent {
	title = 'INDIVIDUAL_MOTOR.MOTOR_INSURANCE_SERVICE';
	motorIndividualServices: Array<FeatureBenefitType> = [
		{
			icon: 'multi-use-profile',
			title: 'INDIVIDUAL_MOTOR.SERVICE_1_TITLE',
			description: 'INDIVIDUAL_MOTOR.SERVICE_1_DESC',
		},
		{
			icon: 'truck',
			title: 'INDIVIDUAL_MOTOR.SERVICE_2_TITLE',
			description: 'INDIVIDUAL_MOTOR.SERVICE_2_DESC',
		},
		{
			icon: 'fa-light fa-triangle-exclamation',
			title: 'INDIVIDUAL_MOTOR.SERVICE_3_TITLE',
			description: 'INDIVIDUAL_MOTOR.SERVICE_3_DESC',
		},
		{
			icon: 'fa-light fa-file-circle-xmark',
			title: 'INDIVIDUAL_MOTOR.SERVICE_4_TITLE',
			description: 'INDIVIDUAL_MOTOR.SERVICE_4_DESC',
		},
	];
}
