import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorHomeComponent } from './rm-individual-motor-home.component';

describe('RmIndividualMotorHomeComponent', () => {
	let component: RmIndividualMotorHomeComponent;
	let fixture: ComponentFixture<RmIndividualMotorHomeComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [RmIndividualMotorHomeComponent],
		});
		fixture = TestBed.createComponent(RmIndividualMotorHomeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
