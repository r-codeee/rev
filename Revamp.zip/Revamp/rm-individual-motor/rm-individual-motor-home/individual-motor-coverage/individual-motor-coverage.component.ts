import {
	Component,
	computed,
	EventEmitter,
	Input,
	OnInit,
	Output,
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CoverageType } from 'src/app/rm-individual-motor/enums/CoverageType';
import { IndividualMotorComparisionTableComponent } from 'src/app/rm-individual-motor/individual-motor-comparision-table/individual-motor-comparision-table.component';
import { MotorIndividualBenifitPopupComponent } from 'src/app/rm-individual-motor/motor-individual-benifit-popup/motor-individual-benifit-popup.component';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Component({
	selector: 'art-individual-motor-coverage',
	templateUrl: './individual-motor-coverage.component.html',
	styleUrls: ['./individual-motor-coverage.component.scss'],
})
export class IndividualMotorCoverageComponent implements OnInit{
	protected readonly CoverageType = CoverageType;

	@Input() coveragePlans: any;
	@Input() isLoading: any;
	@Input() selectedProduct: any;
	@Input() allPlans: any;
	@Input() addons_details: any;
	@Input() selectedVehicleData: any;
	@Output() onSelectedProduct = new EventEmitter<string>();
	@Output() onshowBenefits = new EventEmitter<boolean>();
	currentLang;

	currentProductValue = (id: any) => computed(() => this.allPlans()[id]?.PolicyPremium);
	discountValue = (id: any) => computed(() => this.allPlans()[id]?.basePremium);

	constructor(
		private dialog: MatDialog,
		private readonly languageService: RMLanguageService,
	) {
		this.currentLang = this.languageService.activeLang();
	}

	ngOnInit(): void {
		this.languageService.toggleLang.subscribe(res => {
			if (res) {
				this.currentLang = this.languageService.activeLang();
			}
		});
	}

	selectProduct(event) {
		this.onSelectedProduct.emit(event);
	}

	openComparisonModal() {
		const modalRef = this.dialog.open(
			IndividualMotorComparisionTableComponent,
			{
				data: {
					selectedPlan: this.selectedProduct,
					rates: this.coveragePlans,
					allMapedPlans: this.allPlans(),
				},
				panelClass: 'comparision-table',
				width: '100%',
			},
		);
		modalRef.afterClosed().subscribe(plan => {
			if (plan !== undefined) {
				this.selectedProduct = this.selectedVehicleData.premium_details.find(
					el => el.short_name === plan.short_name,
				);
				this.selectProduct(this.selectedProduct);
			}
		});
	}

	handleShowBenefits(rate) {
		rate.tierName = rate.short_name.replace(/\s+/g, '-');
		const plan: any = this.coveragePlans.find(
			el => el.product_id === rate.product_id,
		);
		plan.netPremium = this.allPlans()[rate.product_id]?.PolicyPremium;
		plan.totalPremium = this.allPlans()[rate.product_id]?.basePremium;
		plan.vatPremium = this.allPlans()[rate.product_id]?.VATAmount;
		plan.applicable_add_ons = plan?.applicable_add_ons?.map(el => ({
			value: this.allPlans()[rate.product_id]?.add_ons[el.cover_id]?.Premium,
			cover_name_ar: el?.cover_name_ar,
			cover_name: el?.cover_name,
			cover_id: el?.cover_id,
		}));
		this.onshowBenefits.emit(false);
		this.dialog.open(MotorIndividualBenifitPopupComponent, {
			data: {
				plan: rate,
				rateInfo: [plan],
				addons_details: this.addons_details,
			},
			autoFocus: false,
			maxHeight: '90vh',
		});
	}
}
