import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorOverviewComponent } from './rm-individual-motor-overview.component';

describe('RmIndividualMotorOverviewComponent', () => {
	let component: RmIndividualMotorOverviewComponent;
	let fixture: ComponentFixture<RmIndividualMotorOverviewComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [RmIndividualMotorOverviewComponent],
		});
		fixture = TestBed.createComponent(RmIndividualMotorOverviewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
