import { Component } from '@angular/core';

@Component({
	selector: 'art-individual-motor-overview',
	templateUrl: './rm-individual-motor-overview.component.html',
	styleUrls: ['./rm-individual-motor-overview.component.scss'],
})
export class RmIndividualMotorOverviewComponent {
	onClickCheckProductDetails() {
		document
			.getElementById('feature-benefits')
			?.scrollIntoView({ behavior: 'smooth' });
	}
}
