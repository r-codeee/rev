import { Component, inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { CyberInsuranceQueriesService } from 'src/app/rm-cyber-insurance/services/cyber-insurance-queries.service';
import { CyberInsuranceService } from 'src/app/rm-cyber-insurance/services/cyber-insurance.service';
import { GetQuoteFormValues } from 'src/app/rm-shared-components/types/GetQuoteFormValues';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';

@Component({
	selector: 'art-get-individual-motor-quote-form',
	templateUrl: './get-individual-motor-quote-form.component.html',
	styleUrls: ['./get-individual-motor-quote-form.component.scss'],
})
export class GetIndividualMotorQuoteFormComponent {
	heading = 'INDIVIDUAL_MOTOR.BANNER_HEADING';
	description = 'INDIVIDUAL_MOTOR.BANNER_DESCRIPTION';
	buttonText = 'INDIVIDUAL_MOTOR.BANNER_BUTTON_TEXT';
}
