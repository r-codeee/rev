import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetIndividualMotorQuoteFormComponent } from './get-individual-motor-quote-form.component';

describe('GetIndividualMotorQuoteFormComponent', () => {
	let component: GetIndividualMotorQuoteFormComponent;
	let fixture: ComponentFixture<GetIndividualMotorQuoteFormComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [GetIndividualMotorQuoteFormComponent],
		});
		fixture = TestBed.createComponent(GetIndividualMotorQuoteFormComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
