import { Component, inject } from '@angular/core';
import { HeaderService } from 'src/app/main-views/home/rm-home/services/header.service';
import { IndividualMotorService } from '../services/individual-motor.service';

@Component({
	selector: 'app-rm-individual-motor-home',
	templateUrl: './rm-individual-motor-home.component.html',
	styleUrls: ['./rm-individual-motor-home.component.scss'],
})
export class RmIndividualMotorHomeComponent {
	private headerService = inject(HeaderService);
	private individualMotorService = inject(IndividualMotorService);

	ngOnInit() {
		this.headerService.setShowProductsTypeTab(true);
		this.headerService.setShowProductsTypeTabType(
			this.headerService.HEADER_TABS.individual,
		);
		this.deleteUserInfo();
	}

	deleteUserInfo(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService.deleteUserInfo().subscribe({
				next: res => {
					this.individualMotorService.getCacheDataWithCredential(),
						resolve(res);
				},
				error: err => {
					console.log(err);
				},
			});
		});
	}
}
