import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorIndividualBenifitPopupComponent } from './motor-individual-benifit-popup.component';

describe('MotorIndividualBenifitPopupComponent', () => {
  let component: MotorIndividualBenifitPopupComponent;
  let fixture: ComponentFixture<MotorIndividualBenifitPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MotorIndividualBenifitPopupComponent]
    });
    fixture = TestBed.createComponent(MotorIndividualBenifitPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
