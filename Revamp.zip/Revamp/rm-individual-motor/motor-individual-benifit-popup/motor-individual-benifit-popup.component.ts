import { Component, EventEmitter, inject, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { RMBenifitCardComponent } from '../../design-system/rm-product-benifit-card/rm-product-benifit-card.component';
import { TranslateModule } from '@ngx-translate/core';
import { IndividualMotorService } from '../services/individual-motor.service';
import { IconButtonComponent } from '../../design-system/icon-button/icon-button.component';

@Component({
	selector: 'app-motor-individual-benifit-popup',
	standalone: true,
	imports: [
		CommonModule,
		RMBenifitCardComponent,
		TranslateModule,
		IconButtonComponent,
	],
	templateUrl: './motor-individual-benifit-popup.component.html',
	styleUrls: ['./motor-individual-benifit-popup.component.scss'],
})
export class MotorIndividualBenifitPopupComponent implements OnInit {
	currentLang: any;
	submit = new EventEmitter();
	objectKeys = Object.keys;
	isShowLess = false;
	panelOpenState = false;
	plan;
	selctedRate;
	rateInfo: any[];
	addons_details: any = [];
	benfits: { Name: string; Value: string }[];
	individualMotor = inject(IndividualMotorService);
	addedAddons :any= [];

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: any,
		private dialogRef: MatDialogRef<MotorIndividualBenifitPopupComponent>,
	) {
		this.currentLang = localStorage.getItem('selectedLang');
		this.plan = data.plan;
		this.rateInfo = data.rateInfo;
		this.individualMotor.addonsData.subscribe((res)=>{
			this.addedAddons = res;
		});
	}

	ngOnInit(): void {
		this.selctedRate = this.rateInfo.filter(
			rate =>
				rate.short_name.toLowerCase().replace(/\s+/g, '-') ===
				this.plan.tierName.toLowerCase(),
		)[0];
		this.benfits = this.selctedRate?.basic_coverage.map(el => ({
			Name: this.currentLang === 'ar' ? el.cover_name_ar : el.cover_name,
			Value: '',
			cover_id: el?.cover_id,
		}));

		this.handelAddons();
	}

	close() {
		this.dialogRef.close(false);
	}

	closeSidenav() {
		this.dialogRef.close(false);
	}

	getPlanImage(plan) {
		return `${plan.tierName.toLowerCase()}-product`;
	}

	addAddons(plan: any) {
		this.individualMotor.addAddons$.next({
			addon: plan,
			plan: this.selctedRate.short_name,
		});
	}

	private handelAddons() {
		this.individualMotor.isAddonsAdded.subscribe(res => {
			this.addedAddons.push(res.cover_id);
		});
	}
}
