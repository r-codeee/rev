import {
	Component,
	EventEmitter,
	Inject,
	inject,
	Input,
	OnInit,
	Output,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
	selector: 'app-rm-vehicle-list-details-popup',
	templateUrl: './rm-vehicle-list-details-popup.component.html',
	styleUrls: ['./rm-vehicle-list-details-popup.component.scss'],
})
export class RmVehicleListDetailsPopupComponent implements OnInit {
	currentLang;
	@Output() close = new EventEmitter<void>();

	@Input() vehicles = [];

	driverData = null;

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: any,
		private dialogRef: MatDialogRef<RmVehicleListDetailsPopupComponent>,
	) {
		this.currentLang = localStorage.getItem('selectedLang');
	}

	ngOnInit(): void {
		this.driverData = this.data.driver;
	}

	removeVehicle(vehicle) {
		console.info(vehicle);
		this.dialogRef.close(vehicle.id);
	}

	onClose() {
		this.dialogRef.close();
		this.close.emit();
	}
}
