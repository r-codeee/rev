import {
	Component,
	EventEmitter,
	HostListener,
	Input,
	OnChanges,
	OnInit,
	Output,
	SimpleChanges,
} from '@angular/core';
import { IVehicle } from 'src/app/rm-individual-motor/types/IVehicle';
import { IAddRiskItemPayload } from '../models/individualMotorDto';
import { IndividualMotorService } from '../services/individual-motor.service';
import { AddNewCarMethods } from '../enums/AddNewCarMethods';
import { switchMap } from 'rxjs';
import { RmMotorSmeService } from 'src/app/products/sme/rm-motor/services/rm-motor-sme.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Component({
	selector: 'art-cars-list-of-card',
	templateUrl: './cars-list-of-card.component.html',
	styleUrls: ['./cars-list-of-card.component.scss'],
})
export class CarsListOfCardComponent implements OnInit,OnChanges {
	@Input() vehicleList: Array<any> = [];
	@Input() isAddNewCar: boolean;
	@Input() nationalId: string;
	@Input() referenceNumber: string;
	@Input() selectedVehicleId: number;
	@Input() defaultSelectedVehicleId;
	@Input() quotaId: number;
	@Input() quotaIdNumber: string;
	@Output() onClickAddNewCar = new EventEmitter();
	@Output() onCloseAddNewCar = new EventEmitter();
	@Output() deleteCard = new EventEmitter();
	@Output() onSelectCar: EventEmitter<IVehicle> = new EventEmitter();
	@Output() onInputChange: EventEmitter<boolean> = new EventEmitter();
	coverageValue = 0;

	isLoading = false;
	isMobile = false;
	currentLang: string;

	constructor(
		private individualMotorService: IndividualMotorService,
		private rmMotorSmeService: RmMotorSmeService,
		private rmLanguageService: RMLanguageService
	) {
		this.checkScreenSize();
		this.currentLang = localStorage.getItem('selectedLang') || 'en';
	}
	ngOnChanges(changes: SimpleChanges): void {
		this.currentLang = localStorage.getItem('selectedLang');
		this.rmLanguageService.toggleLang.subscribe(isToggled => {
			if(isToggled){
				this.currentLang = localStorage.getItem('selectedLang');
			}
		});
		console.log('VehicleList cars:', this.vehicleList);
		if(changes?.vehicleList?.currentValue != changes?.vehicleList?.currentValue ){
			this.vehicleList = changes?.vehicleList?.currentValue
		}
	}

	ngOnInit(): void {
		this.selectedVehicleId = this.defaultSelectedVehicleId;
		if (this.vehicleList[0]?.premium_details?.length) {
			this.coverageValue = this.vehicleList[0]?.premium_details.find(
				item => item.product_code == this.vehicleList[0].product_code,
			)?.ITDPremium;
		}
	}
	handleClickAddNewCar(data: any) {
		this.isAddNewCar = true;
	}
	handlCloseAddNewCar() {
		this.isAddNewCar = false;
		this.onCloseAddNewCar.emit();
	}

	handleSelectCar(vehicleDetails: IVehicle) {
		this.onSelectCar.emit(vehicleDetails);
		this.selectedVehicleId = vehicleDetails.id;
	}

	handleAddNewCar(event?: any) {
		this.isAddNewCar = true;
		this.isLoading = true;
		const data = event?.values;
		let addedCar = null;
		if (data) {
			if (this.vehicleList.length > 0 && this.vehicleList.length <= 5) {
				const addRiskItemPayload: IAddRiskItemPayload = {
					filter: { quote_id: this.quotaId },
					offSet: 0,
					orderBy: {},
					pageSize: 0,
				};
				this.individualMotorService.refresh.next(true)
				this.individualMotorService
					.addRiskItemTolist(addRiskItemPayload)
					.subscribe({
						next: listResponse => {
							console.log('Risk Item List Response:', listResponse);

							const payload = {
								id_type:
									event.selectedMethod === AddNewCarMethods.CUSTOM_NUMBER
										? 11
										: 10,
								vehicle_id_no: data?.customNumber
									? data?.customNumber
									: data?.sequenceNumber,
								owner_id:
									event.selectedMethod === AddNewCarMethods.CUSTOM_NUMBER
										? ''
										: data?.customNumber
											? this.quotaIdNumber
											: data?.nationalIdNumber
												? data?.nationalIdNumber
												: this.quotaIdNumber,
								model_year: data?.vehicleProductionYear || '',
								policy_holder_id: this.quotaIdNumber,
							};

							const riskPayload = {
								id_no:
									event.selectedMethod === AddNewCarMethods.CUSTOM_NUMBER
										? Number(data?.customNumber)
										: Number(data?.sequenceNumber),
								quote_id: Number(this.quotaId),
							};

							this.individualMotorService
								.getVehicleDetails(payload)
								.pipe(
									switchMap(vehicleDetailsRes => {
										console.log('Vehicle Details:', vehicleDetailsRes);
										addedCar = vehicleDetailsRes;
										return this.individualMotorService.createRiskItem(
											riskPayload,
										);
									}),
								)
								.subscribe({
									next: createRiskItemRes => {
										console.info('Risk Item Created:', createRiskItemRes);
										this.onClickAddNewCar.emit({
											status: true,
											riskItemData: { ...createRiskItemRes },
											errMsg: '',
										});
										this.isAddNewCar = false;
										this.isLoading = false;
									},
									error: err => {
										this.onClickAddNewCar.emit({
											status: false,
											errMsg: err,
										});
										this.isLoading = false;
									},
								});
						},
						error: err => {
							this.onClickAddNewCar.emit({ status: false, errMsg: err });
							this.isLoading = false;
						},
					});
			}
		}
	}

	handleRemoveCar(id: string) {
		this.rmMotorSmeService.vehicleDelete(id).subscribe(res => {
			if (res) {
				this.deleteCard.emit(id);
			}
		});
	}

	changeInput(event) {
		this.onInputChange.emit(true);
	}

	deductibleDefaultValue(x) {
		x = Number(x);
		let val = 2000;
		if (x > 60000) {
			val = 25000;
		}
		if (x > 45000 && x <= 60000) {
			val = 20000;
		}
		if (x > 30000 && x <= 45000) {
			val = 15000;
		}
		if (x <= 30000) {
			val = 10000;
		}
		return val;
	}

	@HostListener('window:resize', ['$event'])
	checkScreenSize() {
		this.isMobile = window.innerWidth <= 991; // Adjust for MD breakpoint
	}
}
