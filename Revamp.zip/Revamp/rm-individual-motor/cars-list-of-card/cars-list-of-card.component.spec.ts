import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarsListOfCardComponent } from './cars-list-of-card.component';

describe('CarsListOfCardComponent', () => {
  let component: CarsListOfCardComponent;
  let fixture: ComponentFixture<CarsListOfCardComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CarsListOfCardComponent]
    });
    fixture = TestBed.createComponent(CarsListOfCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
