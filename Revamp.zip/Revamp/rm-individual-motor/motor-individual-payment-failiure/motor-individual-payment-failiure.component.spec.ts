import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorIndividualPaymentFailiureComponent } from './motor-individual-payment-failiure.component';

describe('MotorIndividualPaymentFailiureComponent', () => {
  let component: MotorIndividualPaymentFailiureComponent;
  let fixture: ComponentFixture<MotorIndividualPaymentFailiureComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MotorIndividualPaymentFailiureComponent]
    });
    fixture = TestBed.createComponent(MotorIndividualPaymentFailiureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
