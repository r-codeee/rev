import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RmPaymentFailurePageComponent } from '../../rm-payment-failure-page/rm-payment-failure-page.component';
import { ARTStorageService } from '../../utils/services/shared/storage.service';
import { Router } from '@angular/router';
import { IndividualMotorService } from '../services/individual-motor.service';

@Component({
	selector: 'art-motor-individual-payment-failiure',
	standalone: true,
	imports: [CommonModule, RmPaymentFailurePageComponent],
	templateUrl: './motor-individual-payment-failiure.component.html',
	styleUrls: ['./motor-individual-payment-failiure.component.scss'],
})
export class MotorIndividualPaymentFailiureComponent {
	private readonly storage = inject(ARTStorageService);
	private individualMotor = inject(IndividualMotorService);
	private readonly router = inject(Router);
	customerData: any;
	ngOnInit() {
		const { STORAGE_KEY } = this.individualMotor;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
		this.customerData = {
			...this.customerData,
			name: this.storage.GetValue('name'),
			refNumber: this.storage.GetValue('paymentRefNo'),
			policyId: this.storage.GetValue('paymentRefNo'),
			paymentFrom: this.storage.GetValue('policyStartDate'),
			paymentTo: this.storage.GetValue('policyEndDate'),
			policyName: 'INDIVIDUAL_MOTOR.MOTOR_INSURANCE_POLICY',
			productIcon: 'art-motor-product-icon',
			paymentAmount: this.storage.GetValue('totalPremiumVal'),
			paymentCurrency: 'COMMON.CURRENCY',
		};
		this.storage.Setvalue(STORAGE_KEY, this.customerData);
	}
	navigateToPayment() {
		this.router.navigate([
			'revamp-individual-motor/motor-individual-quotation-stepper/payment',
		]);
	}
}
