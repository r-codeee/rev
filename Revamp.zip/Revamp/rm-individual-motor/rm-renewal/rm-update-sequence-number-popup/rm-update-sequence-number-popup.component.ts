import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import * as yup from 'yup';

@Component({
	selector: 'art-rm-update-sequence-number-popup',
	templateUrl: './rm-update-sequence-number-popup.component.html',
	styleUrls: ['./rm-update-sequence-number-popup.component.scss'],
})
export class RmUpdateSequenceNumberPopupComponent extends BaseFormComponent<{
	sequenceNumber: string;
}> {
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private readonly dialogRef: MatDialogRef<RmUpdateSequenceNumberPopupComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
	) {
		super(formBuilderService);
	}
	values: { sequenceNumber: string } = {
		sequenceNumber: this.data?.customNumber || this.data?.sequenceNumber || '',
	};
	validationSchema = yup.object().shape({
		sequenceNumber: yup
			.string()
			.min(8)
			.max(10)
			.matches(/^[0-9]*$/)
			.required(),
	});

	close(data) {
		this.dialogRef.close(data);
	}

	onSubmit(values: { sequenceNumber }) {
		if (this.form.valid) {
			this.data.sequenceNumber = values.sequenceNumber;
			this.close(this.data);
		}
	}
}
