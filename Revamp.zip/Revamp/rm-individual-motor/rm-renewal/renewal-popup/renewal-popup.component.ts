import { Component, inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

import { GetRenewalValue } from 'src/app/rm-shared-components/types/GetrenewalValues';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { IndividualMotorQuotationFormValidationSchemaService } from '../../services/individual-motor-quotation-form-validation-schema.service';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { SvgIconComponent } from 'src/app/design-system/svg-icon/svg-icon.component';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { delay, switchMap, tap } from 'rxjs';
import { IndividualMotorService } from '../../services/individual-motor.service';
import moment from 'moment';
import { CommonMyspaceService } from 'src/app/rm-my-space/common/services/common-myspace.service';
import { AppComponent } from 'src/app/app.component';
@Component({
	selector: 'app-rm-motor-individual-renewal-popup-popup',
	templateUrl: './renewal-popup.component.html',
	styleUrls: ['./renewal-popup.component.scss'],
})
export class RenewalPopupComponent extends BaseFormComponent<GetRenewalValue> {
	currentLang;
	nationalIdSuffixComponent = SvgIconComponent;
	nationalIdSuffixComponentInputs = {
		icon: 'nationalId',
		size: 'xs',
	};
	errorMessage;
	isPopupVisible = true;
	values: GetRenewalValue = {
		nationalId: '',
		dateOfBirth: '',
	};
	today = new Date();
	submitted: boolean = false;
	isLoading: boolean = false;
	hasError: boolean = false;
	otpVerified = false;
	userInfo;
	private readonly router = inject(Router);
	private readonly authService = inject(AuthService);
	constructor(
		private readonly dialogRef: MatDialogRef<RenewalPopupComponent>,
		protected formBuilderService: ArtFormBuilderService,
		private readonly individualMotorService: IndividualMotorService,
		private readonly commonMyspaceService: CommonMyspaceService,
		private readonly renewalValidationSchemaService: IndividualMotorQuotationFormValidationSchemaService,
		private appComponent: AppComponent,
	) {
		super(formBuilderService);
		this.currentLang = localStorage.getItem('selectedLang');
	}
	validationSchema =
		this.renewalValidationSchemaService.createRenewalValidationSchema();
	close() {
		this.dialogRef.close('close');
	}
	goTo() {
		this.close();
		this.router.navigateByUrl('/revamp-individual-motor/quotation');
	}

	onSubmit(values: GetRenewalValue): Promise<void> {
		this.isLoading = true;
		this.errorMessage = '';
		return new Promise((resolve, reject) => {
			this.hasError = false;
			const statusCheckBody = {
				customer_id: values.nationalId,
				dob: moment(values.dateOfBirth, 'DD-MM-YYYY').format('MM/YYYY'),
			};

			this.individualMotorService.generateAuthCode().subscribe(res => {
				let authorizationCode = res.Authorization_code;
				if (authorizationCode) {
					this.individualMotorService
						.generateAccessToken(authorizationCode)
						.subscribe(res => {
							let token = 'Bearer' + ' ' + res.Access_token;
							localStorage.setItem('Pay_Token', token);
							sessionStorage.setItem('Pay_session_token', token);
							this.guestLogin().then(() => {
								// this.individualMotorService.getCacheData().subscribe(res => {
								this.getUserInfo().then(res => {
									this.otpVerified = res.data?.['otp-verified'];
									this.individualMotorService
										.checkRenewalStatus(statusCheckBody)
										.subscribe(res => {
											if (res.status) {
												if (this.otpVerified) {
													this.close();
													this.router.navigate([
														'/revamp-individual-motor/renewal/policies',
													]);
												} else {
													this.close();
													this.router.navigateByUrl(
														'/revamp-individual-motor/revamp-renewal-otp',
													);
												}
												this.isLoading = false;
											} else {
												this.hasError = true;
												this.isLoading = false;
												resolve();
											}
										});
								});
								// });
							});
						});
				}
			});
		});
	}

	guestLogin(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService
				.guestLogin()
				.pipe(
					tap((res: any) => {
						localStorage.removeItem('dcp-token');
						localStorage.setItem('dcp-token', res.token);
					}),
					delay(1200),
					switchMap(() =>
						this.individualMotorService.getCacheDataWithCredential(),
					),
				)
				.subscribe({
					next: res => {
						console.log(res);
						resolve(res);
					},
					error: ({ error }) => {
						this.errorMessage = error?.message || error;
						reject(error);
					},
				});
		});
	}

	getUserInfo(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService.getUserInfo().subscribe({
				next: res => {
					this.otpVerified = res.data?.['otp-verified'];
					this.userInfo = res;
					resolve(res);
				},
				error: err => {
					resolve({});
					console.log(err);
				},
			});
		});
	}

	onChangeNationalId(value) {
		this.hasError = false;
	}

	onChangeBirthdate(value) {
		this.hasError = false;
	}
}
