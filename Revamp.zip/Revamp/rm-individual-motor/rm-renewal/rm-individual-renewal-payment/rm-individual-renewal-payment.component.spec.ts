import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualRenewalPaymentComponent } from './rm-individual-renewal-payment.component';

describe('RmIndividualRenewalPaymentComponent', () => {
  let component: RmIndividualRenewalPaymentComponent;
  let fixture: ComponentFixture<RmIndividualRenewalPaymentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualRenewalPaymentComponent]
    });
    fixture = TestBed.createComponent(RmIndividualRenewalPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
