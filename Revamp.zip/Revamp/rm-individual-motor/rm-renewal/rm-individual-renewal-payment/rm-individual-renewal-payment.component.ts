import { Component } from '@angular/core';

@Component({
  selector: 'app-rm-individual-renewal-payment',
  templateUrl: './rm-individual-renewal-payment.component.html',
  styleUrls: ['./rm-individual-renewal-payment.component.scss']
})
export class RmIndividualRenewalPaymentComponent {

}
