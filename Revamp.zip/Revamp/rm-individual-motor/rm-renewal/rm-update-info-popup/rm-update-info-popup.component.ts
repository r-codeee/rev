import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
	selector: 'art-rm-update-info-popup',
	templateUrl: './rm-update-info-popup.component.html',
	styleUrls: ['./rm-update-info-popup.component.scss'],
})
export class RmUpdateInfoPopupComponent {
	constructor(
		private readonly dialogRef: MatDialogRef<RmUpdateInfoPopupComponent>,
		private readonly router: Router,
	) {}

	close() {
		this.dialogRef.close('close');
	}

	goToUpdateInfoPage() {
		this.close();
		this.router.navigateByUrl(
			'/revamp-individual-motor/renewal/update-information',
		);
	}
}
