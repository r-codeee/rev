import { AfterViewInit, Component, inject, OnInit } from '@angular/core';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { UpdateInformationValue } from 'src/app/rm-shared-components/types/UpdateInformationValues';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { IndividualMotorQuotationFormValidationSchemaService } from '../../services/individual-motor-quotation-form-validation-schema.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import {
	INationalAddressResponse,
	IQuoteRiskItemAdditionalDetails,
	IValidateQuoteResponse,
} from '../../models/individualMotorDto';
import * as moment from 'moment';
import { MatDialog } from '@angular/material/dialog';
import { RmSuccessPopupComponent } from '../rm-success-popup/rm-success-popup.component';
import { Subscription } from 'rxjs';
import { NavigationStart, Router } from '@angular/router';
import { RmUpdateSequenceNumberPopupComponent } from '../rm-update-sequence-number-popup/rm-update-sequence-number-popup.component';
import { TranslateService } from '@ngx-translate/core';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';


@Component({
	selector: 'art-rm-update-information',
	templateUrl: './rm-update-information.component.html',
	styleUrls: ['./rm-update-information.component.scss'],
})
export class RmUpdateInformationComponent
	extends BaseFormComponent<UpdateInformationValue>
	implements AfterViewInit
{
	values: UpdateInformationValue = {
		nationalAddress: '',
		dateOfBirth: '',
	};

	validationSchema =
		this.renewalValidationSchemaService.createUpdateInformationValidationSchema();
	isFormSubmitted = false;
	addressList: Array<INationalAddressResponse> = [];
	quoteId: string = '';
	private readonly individualMotor = inject(IndividualMotorService);
	errorMessage: string;
	isLoading: boolean;
	hasError: boolean;
	private readonly storage = inject(ARTStorageService);
	storageData;
	vehicleList = [];
	currentLang: string;
	private routerSubscription: Subscription;
	selectedAddress: any = {};
	validateRes: IValidateQuoteResponse;
	sequencesAreValid = false;
	dateOfBirth;
	address;

	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private renewalValidationSchemaService: IndividualMotorQuotationFormValidationSchemaService,
		private dialog: MatDialog,
		private router: Router,
		private translateService: TranslateService,
		private lanugageService: RMLanguageService,
	) {
		super(formBuilderService);
		const lang = this.lanugageService.activeLang();
		this.currentLang = lang || 'ar';
		this.storageData = this.storage.GetValue(this.individualMotor.STORAGE_KEY);
		this.dateOfBirth = this.storageData.quoteDetails?.quote_details?.addl_details?.dob || '';
		this.quoteId = this.storageData.quoteDetails.quote_details.id;
		this.vehicleList = this.storageData.quoteDetails.risk_item_details;
		this.getAddressList();
		this.validateRes = this.storageData.validateRes;
		this.updateSequencesAreValid();
	}

	ngAfterViewInit(): void {
		this.form.get('dateOfBirth').setValue(moment(this.dateOfBirth,'DD-MM-YYYY'))
		// this.form.patchValue({
		// 	nationalAddress:
		// 		this.storageData.quoteDetails?.quote_details?.addl_details
		// 			?.address_line_1 || '',
		// });		
		// this.selectedAddress =
		// this.storageData.quoteDetails?.quote_details?.addl_details;
		// this.selectedAddress.Name_ar = this.selectedAddress.address_line_1 || '';
		// this.selectedAddress.Name_en = this.selectedAddress.address_line_1 || '';
		
		this.form.get('nationalAddress').markAsTouched();
		this.form.get('dateOfBirth').markAsTouched();
	}

	updateSequencesAreValid() {
		this.sequencesAreValid = this.validateRes.valid_sequence_no.every(
			item => item.updated || item.valid,
		);
	}

	getAddressList() {
		this.individualMotor
			.getAddressList({
				id_no: this.storageData.quoteDetails.quote_details.id_no,
			})
			.subscribe({
				next: res => {
					console.log(res);
					this.addressList = res;
					this.addressList = this.addressList.map(address => {
						address.Name_ar =
							address.street_ar +
							' - ' +
							address.district_ar +
							' - ' +
							address.region_name_ar;
						address.Name_en =
							address.street +
							' - ' +
							address.district +
							' - ' +
							address.region_name_en;
						return address;
					});
					this.selectedAddress = this.addressList[0];
					this.form.patchValue({
						nationalAddress: this.currentLang =='en'? this.selectedAddress.Name_en:this.selectedAddress.Name_ar
					});
				},
				error: err => {
					this.errorMessage = err;
					console.log(err);
				},
			});
	}

	nationalAddressChange(event) {
		this.selectedAddress = event;
		this.form.patchValue({
			nationalAddress: this.currentLang == 'en' ? event.Name_en : event.Name_ar,
		});
	}

	updateSequenceNumber(id_no: number, index: number) {
		// Data you want to pass to the popup component
		const dialogData = {
			sequenceNumber: id_no,
		};

		const dialogRef = this.dialog.open(RmUpdateSequenceNumberPopupComponent, {
			panelClass: 'custom-renewal-width', // 80% of the available width
			data: dialogData,
		});

		// Subscribe to when the dialog is closed and get the returned data
		dialogRef.afterClosed().subscribe(result => {
			if (result) {
				// `result` contains the data sent back from the dialog
				this.vehicleList[index].id_no = result.sequenceNumber;
				this.validateRes.valid_sequence_no[index].updated = true;
				this.updateSequencesAreValid();
				dialogRef.close();
			}
		});

		// Subscribe to router events to close the dialog on navigation
		this.routerSubscription = this.router.events.subscribe(event => {
			if (event instanceof NavigationStart) {
				// Close the dialog when navigation starts
				dialogRef.close();
			}
		});
	}

	onSubmit(values: UpdateInformationValue) {
		this.isLoading = true;
		this.errorMessage = '';
		this.isFormSubmitted = true;
		this.updateQuoteInformation()
			.then(res => {
				if (res) {
					this.openSuccessPopup();
				}
			})
			.catch(err => {
				this.errorMessage = err;
				this.isLoading = false;
			});
	}

	openSuccessPopup() {
		this.hasError = false;
		const dialogRef = this.dialog.open(RmSuccessPopupComponent, {
			panelClass: 'custom-renewal-width', // 80% of the available width
			disableClose: true,
		});
		// Subscribe to router events to close the dialog on navigation
		this.routerSubscription = this.router.events.subscribe(event => {
			if (event instanceof NavigationStart) {
				// Close the dialog when navigation starts
				dialogRef.close();
			}
		});
	}

	updateQuoteInformation(): Promise<any> {
		const dobControl = this.form.get('dateOfBirth');
		const dobValue = dobControl.value;
		const formattedDob = moment(dobValue).format('DD-MM-YYYY');
		const sequenceList = this.createVehicleSequenceList();
		const payload: UpdateQuotePayload = this.buildPayload(
			formattedDob,
			sequenceList,
		);

		return new Promise<any>((resolve, reject) => {
			this.individualMotor.UpdateQuoteInfo(payload).subscribe({
				next: res => {
					this.isLoading = false;
					resolve(res);
				},
				error: err => {
					this.isLoading = false;
					let error = err?.message || err?.error || err.error_msg || err;
					this.isLoading = false;
					if(error.includes('Unknown Error') || error == undefined  ||  typeof error == 'object'){
						error = this.translateService.instant('COMMON.PLEASE_CHECK_ENTERED_DATA_THEN_TRY_AGAIN_LATER')
					}
					reject(error);
				},
			});
		});
	}

	private createVehicleSequenceList(): VehicleSequence[] {
		// Create a list of vehicle sequences
		return this.vehicleList.map(vehicle => ({
			id: +vehicle.id,
			sequence_number: +vehicle.id_no,
		}));
	}

	private buildPayload(
		formattedDob: string,
		sequenceList: VehicleSequence[],
	): UpdateQuotePayload {
		// Build the payload object with all necessary details
		const payload: UpdateQuotePayload = {
			id: this.quoteId,
			status_id: 1,
			source: 'b2c',
		};

		// Include the date of birth if valid
		if (!this.validateRes.valid_dob) {
			payload.dob = formattedDob;
		}

		// Include the address details if valid
		if (!this.validateRes.valid_address) {
			payload.address_details = this.selectedAddress;
		}

		// Include sequence numbers if valid
		if (!this.validateRes.valid_sequence_no.every(seq => seq.valid)) {
			payload.sequence_number = this.getInvalidSequenceNumbers(sequenceList);
		}

		return payload;
	}

	private getInvalidSequenceNumbers(
		sequenceList: VehicleSequence[],
	): VehicleSequence[] {
		// Filter out invalid sequence numbers
		return this.validateRes.valid_sequence_no
			.map((seq, index) => (seq.valid ? null : sequenceList[index]))
			.filter(seq => seq !== null) as VehicleSequence[];
	}

	ngOnDestroy() {
		// Unsubscribe from the router events when the component is destroyed
		if (this.routerSubscription) {
			this.routerSubscription.unsubscribe();
		}
	}
}

export interface VehicleSequence {
	id: number;
	sequence_number: number;
}

export interface UpdateQuotePayload {
	id: string;
	status_id: number;
	source: string;
	dob?: string;
	address_details?: any; // Specify a more specific type for address details
	sequence_number?: VehicleSequence[];
}
