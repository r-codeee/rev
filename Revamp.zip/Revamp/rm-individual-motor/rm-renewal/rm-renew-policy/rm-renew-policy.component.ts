import {
	Component,
	computed,
	inject,
	Input,
	OnInit,
	signal,
} from '@angular/core';
import { IndividualMotorPremiumCalculationService } from 'src/app/rm-individual-motor/services/individual-motor-premium-calculation.service';
import {
	IAddonsResponseItemWithGroup,
	IAddonView,
	IAddRiskItemListResponse,
	IAddRiskItemPayload,
	ICreateAddonsPayload,
	ICreateDriverPayload,
	ICustomerDetailsPayload,
	IGetRateResponse,
	IQuoteProductItem,
	IQuoteResponse,
	IQuoteSummaryResponse,
	IUserInfo,
	IValidateQuoteResponse,
	VehicleType,
} from '../../models/individualMotorDto';
import { IRatesInfoResponseData } from '../../types/IRatesInfoResponse';
import {
	IAddDriverFormValues,
	IVehicle,
	IVehicleCoverage,
} from '../../types/IVehicle';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { MultiMotorService } from '../../services/multi-motor.service';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { NavigationStart, Router } from '@angular/router';
import { CoverageType } from '../../enums/CoverageType';
import { TranslateService } from '@ngx-translate/core';
import { MatDialog } from '@angular/material/dialog';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SendVehicleImagesComponent } from 'src/app/design-system/send-vehicle-images/send-vehicle-images.component';
import moment from 'moment';
import { MotorIndividualBenifitPopupComponent } from '../../motor-individual-benifit-popup/motor-individual-benifit-popup.component';
import { IndividualMotorComparisionTableComponent } from '../../individual-motor-comparision-table/individual-motor-comparision-table.component';
import { delay, Subscription, switchMap, tap } from 'rxjs';
import { UpgradePopupMotorComponent } from '../../upgrade-popup-motor/upgrade-popup-motor.component';
import { AddNewCarMethods } from '../../enums/AddNewCarMethods';
import { RmMotorSmeService } from 'src/app/products/sme/rm-motor/services/rm-motor-sme.service';
import { RMIndividualMotorModalComponent } from '../../rm-individual-motor-modal/rm-individual-motor-modal.component';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { RmUpdateInfoPopupComponent } from '../rm-update-info-popup/rm-update-info-popup.component';

interface StorageDataType {
	userName: string;
	dateOfBirth: string;
	agentCode: string;
	insuranceType: string;
	mobileNumber: string;
	nationalId: string;
	emailAddress: string;
	policyStartDate: string;
	privacyPolicyConsent: boolean;
	referenceId: string;
	vehicleList: Array<IVehicle>;
	ratesInfoData: IRatesInfoResponseData;
	quoteResponse: IQuoteResponse;
}
@Component({
	selector: 'app-rm-renew-policy',
	templateUrl: './rm-renew-policy.component.html',
	styleUrls: ['./rm-renew-policy.component.scss'],
})
export class RmRenewPolicyComponent  {
	// implements OnInit
	constructor(
		private dialog: MatDialog,
		private readonly ngbModal: NgbModal,
		private rmMotorSmeService: RmMotorSmeService,
	) {
		this.storageData = this.storage.GetValue(this.individualMotor.STORAGE_KEY);
		this.referenceId = this.storageData.quoteResponse.reference_number;
		console.log('storageData', this.storageData);
	}
	// @Input() isRenewalPolicy: boolean = false;
	// isAddNewCar: boolean;
	// isOnlyOneCar = true;
	// ratesInfoData: IRatesInfoResponseData = {
	// 	coverage: null,
	// 	finalRateSummary: null,
	// 	rateSummmary: [],
	// 	ownerInformation: null,
	// 	vehicleAndDriverInfo: null,
	// 	productAddons: null,
	// };
	private readonly storage = inject(ARTStorageService);
	// private readonly multiMotor = inject(MultiMotorService);
	private readonly individualMotor = inject(IndividualMotorService);
	// riskItemIds: number[];
	storageData: StorageDataType;
	referenceId: string;
	// vehicleList: Array<IVehicle>;
	// selectedVehicle: number;
	// selected_vehicle_risk_Id: number;
	// CoverageType = CoverageType;
	// selectedCoverage: string;
	// netValue;
	// dataToProceed = {};
	// serverErrorMsg = '';
	// currentLang: any = localStorage.getItem('selectedLang');
	// translateService = inject(TranslateService);

	// isVehicleNotExist: boolean;
	// selectedVehicleData: any;
	// filteredValidRates: any;
	// isDeleteLoaded: boolean;
	// filteredValidRatesForCarSelected: any = [];
	// // Neutrinous
	router = inject(Router);
	// quoteDetails: IQuoteSummaryResponse;
	// userInfo: IUserInfo;
	// products: Array<IQuoteProductItem> = [];
	// rateReponse: Array<IGetRateResponse> = [];
	// addonsWithGroup: Array<IAddonsResponseItemWithGroup> = [];
	// selectedProduct: IQuoteProductItem;
	// selectedAddons;
	// selectedProductId: number;
	// userName: string = '';
	// VehicleType = VehicleType;
	isLoadingQuoteSummary = false;
	// apiLoading = false;
	// isPremiumDetailsFooterExpanded = true;
	// currentAddons: Array<IAddonView> = [];
	// isLoadingCarInfo: boolean = false;
	// isLoadingRecalculate: boolean = false;
	// transparentLoading: boolean = false;
	// driverList: any = [];
	// sendVechilImagModalRef;
	// firstName: string;
	// upload_documents;
	// sub = new Subscription();
	// allPlans = signal<any>({});
	// selectedVehicleId: number;
	// private readonly authService = inject(AuthService);
	// private readonly individualMotorPremiumCalculationService = inject(
	// 	IndividualMotorPremiumCalculationService,
	// );
	// protected readonly AddNewCarMethods = AddNewCarMethods;
	// handleError(error: any, context: string) {
	// 	console.error(`${context}:`, error);
	// 	this.serverErrorMsg =
	// 		error?.message || error.error || 'An unexpected error occurred.';
	// 	this.isVehicleNotExist = true;
	// 	this.isLoadingQuoteSummary = false;
	// }
	// currentProductValue = (id: any) =>
	// 	computed(() => this.allPlans()[id]?.PolicyPremium);
	// discountValue = (id: any) => computed(() => this.allPlans()[id]?.basePremium);
	private routerSubscription: Subscription;
	validateResponse: IValidateQuoteResponse;
	validateFalg: boolean = false;

	ngOnInit() {
		this.isLoadingQuoteSummary = true;
		this.validateQuoteInfo()
			.then(res => {
				this.validateFalg = res;
				if (res) {
				// 	this.intializeData();
				// 	this.listenToAddAddon();
				this.isLoadingQuoteSummary = false;
				} else {
					this.showUpdateInformation();
				}
			})
			.catch(error => {
				this.isLoadingQuoteSummary = false;
				console.log(error);
			});
	}

	// intializeData() {
	// 	this.isLoadingQuoteSummary = true;

	// 	return this.getQuoteSummary()
	// 		.then(() => this.getProducts())
	// 		.then(() => this.getUserInfo())
	// 		.then(() => this.updateQuote())
	// 		.then(() => this.getRate())
	// 		.then(() => this.initializeProduct())
	// 		.then(() => {
	// 			this.getVehicleImage();
	// 			this.selectedVehicleData = this.quoteDetails.risk_item_details[0];
	// 			this.handleSelectCar(this.selectedVehicleData);
	// 		})
	// 		.then(() => this.quoteCalculatePremium())
	// 		.then(() => this.getQuoteSummary())
	// 		.then(() => this.initializeProduct())
	// 		.then(() => {
	// 			this.getVehicleImage();
	// 			this.selectedVehicleData = this.quoteDetails.risk_item_details[0];
	// 			this.handleSelectCar(this.selectedVehicleData);
	// 		})
	// 		.then(() => this.addRiskItemTolist())
	// 		.then(() => this.getAddons())
	// 		.catch(error => {
	// 			console.error('Error during initialization:', error);
	// 		})
	// 		.finally(() => {
	// 			this.isLoadingQuoteSummary = false;
	// 		});
	// }

	// getProductByName(name) {
	// 	return this.products.find(product => product.short_name == name);
	// }

	// initializeProduct() {
	// 	this.quoteDetails.risk_item_details =
	// 		this.individualMotorPremiumCalculationService.initializeProduct(
	// 			this.quoteDetails.risk_item_details,
	// 			this.rateReponse,
	// 			this.products,
	// 		);

	// 	console.log(this.filteredValidRatesForCarSelected);
	// 	console.log(this.selectedProduct);
	// }

	// getFilteredValidRates() {
	// 	const filteredRates = this.rateReponse
	// 		.map(vehicle => {
	// 			// Filter plans with validation_code === 0
	// 			const validPlans = Object.values(vehicle.plans)
	// 				.filter(plan => plan.validation_code === 0)
	// 				.map(plan => {
	// 					// Find the matching product by product_code
	// 					const matchingProduct = this.products.find(
	// 						product => product.product_id === plan.product_code,
	// 					);

	// 					// Merge the product data with the plan
	// 					return {
	// 						...plan,
	// 						...(matchingProduct || null), // Include product data or null if no match
	// 					};
	// 				});

	// 			return {
	// 				vehicle_id_no: vehicle.vehicle_id_no,
	// 				plans: validPlans,
	// 			};
	// 		})
	// 		.filter(vehicle => vehicle.plans.length > 0);

	// 	return filteredRates;
	// }

	// getHigherPlan(plans) {
	// 	if (!Array.isArray(plans) || plans.length === 0) {
	// 		throw new Error('plans must be a non-empty array.');
	// 	}
	// 	return plans.reduce((highest, current) => {
	// 		if (current.PolicyPremium > highest.PolicyPremium) {
	// 			return current;
	// 		} else {
	// 			return highest;
	// 		}
	// 	});
	// }

	// drowProductForSelectedVehicle(selecvtedVehicleDataID: any) {
	// 	return this.filteredValidRates?.find(
	// 		premiumDetail => premiumDetail.vehicle_id_no === selecvtedVehicleDataID,
	// 	)?.plans;
	// }

	// handleAddNewCar(event?: any) {
	// 	this.isAddNewCar = true;
	// 	this.serverErrorMsg = '';
	// 	console.info(event);
	// 	this.isLoadingQuoteSummary = true;
	// 	if (event.status) {
	// 		this.selectedVehicleId = event.riskItemData.id;
	// 		this.intializeDataAddNewCar();
	// 	} else {
	// 		this.handleError(event.errMsg, 'Error creating risk item');
	// 	}
	// }

	// intializeDataAddNewCar() {
	// 	return this.getQuoteSummary()
	// 		.then(() => this.getProducts())
	// 		.then(() => this.getUserInfo())
	// 		.then(() => this.updateQuote())
	// 		.then(() => this.getRate())
	// 		.then(() => this.initializeProduct())
	// 		.then(() => {
	// 			this.getVehicleImage();
	// 			this.selectedVehicle = this.quoteDetails.risk_item_details.find(
	// 				el => el.id == this.selectedVehicleId,
	// 			).id_no;
	// 			this.selectedVehicleData = this.quoteDetails.risk_item_details.find(
	// 				el => el.id == this.selectedVehicleId,
	// 			);
	// 			this.handleSelectCar(this.selectedVehicleData);
	// 		})
	// 		.then(() => this.linkProduct())
	// 		.then(() => this.quoteCalculatePremium())
	// 		.then(() => this.getQuoteSummary())
	// 		.then(() => this.initializeProduct())
	// 		.then(() => {
	// 			this.getVehicleImage();
	// 			this.selectedVehicle = this.quoteDetails.risk_item_details.find(
	// 				el => el.id == this.selectedVehicleId,
	// 			).id_no;
	// 			this.selectedVehicleData = this.quoteDetails.risk_item_details.find(
	// 				el => el.id == this.selectedVehicleId,
	// 			);

	// 			this.handleSelectCar(this.selectedVehicleData);
	// 		})
	// 		.then(() => this.addRiskItemTolist())
	// 		.then(() => this.getAddons())
	// 		.catch(error => {})
	// 		.finally(() => {
	// 			this.isLoadingQuoteSummary = false;
	// 			this.resetFlags();
	// 		});
	// }

	// resetFlags() {
	// 	this.isAddNewCar = false;
	// 	this.isLoadingQuoteSummary = false;
	// 	this.isVehicleNotExist = false;
	// }

	// handleRemoveCar(id: string) {
	// 	this.selectedVehicle = null;
	// 	this.intializeData();
	// }

	// handleSelectCar(vehicleDetails: IVehicle) {
	// 	const {
	// 		selectedVehicle,
	// 		selectedVehicleRiskId,
	// 		filteredValidRatesForCarSelected,
	// 		selectedProduct,
	// 		selectedCarAdditionalInfo,
	// 	} = this.individualMotor.handleSelectCar(this.quoteDetails, vehicleDetails);

	// 	this.selectedVehicleData = vehicleDetails;
	// 	this.selectedVehicle = selectedVehicle;
	// 	this.selected_vehicle_risk_Id = selectedVehicleRiskId;
	// 	this.filteredValidRatesForCarSelected = filteredValidRatesForCarSelected;
	// 	this.selectedProduct = selectedProduct;
	// 	this.allPlans.set(this.calculatePlans());
	// 	this.filterAddonsBySelectedProduct();
	// }

	// selectProduct(event) {
	// 	this.selectedProduct = event;
	// 	this.transparentLoading = true;
	// 	this.linkProduct()
	// 		.then(() => this.getRate())
	// 		.then(() => this.quoteCalculatePremium())
	// 		.then(() => {
	// 			this.quoteDetails.risk_item_details =
	// 				this.quoteDetails.risk_item_details.map(riskItem => {
	// 					if (riskItem.id === this.selectedVehicleData.id) {
	// 						this.selectedVehicleData = {
	// 							...riskItem,
	// 							selectedPlan: this.selectedProduct,
	// 						};
	// 						return this.selectedVehicleData;
	// 					}
	// 					return riskItem;
	// 				});
	// 			this.getVehicleImage();
	// 			this.filterAddonsBySelectedProduct();
	// 		})
	// 		.catch(error => {})
	// 		.finally(() => {
	// 			this.transparentLoading = false;
	// 		});
	// }

	// vehicleDetailsSubmitted(formData: IVehicleCoverage) {
	// 	this.isLoadingRecalculate = true;
	// 	this.updateRiskItem(formData).then(() => {
	// 		this.addRiskItemTolist().then(listResposne => {
	// 			this.getRate().then(() => {
	// 				this.getAddonsList().then(() => {
	// 					this.quoteCalculatePremium();
	// 					this.isLoadingRecalculate = false;
	// 				});
	// 			});
	// 		});
	// 	});
	// }

	// addonsSelected(event) {
	// 	this.transparentLoading = true;
	// 	const payload: ICreateAddonsPayload = {
	// 		risk_items: [this.selectedVehicleData.id],
	// 		add_on_code: event.cover_id,
	// 		addl_details: {
	// 			cover_name: event.cover_name,
	// 			cover_name_ar: event.cover_name_ar,
	// 			cover_id: event.cover_id,
	// 			applicable_products: event.applicable_products,
	// 		},
	// 	};
	// 	this.individualMotor.createAddons(payload).subscribe({
	// 		next: res => {
	// 			this.getAddonsList().then(() => {
	// 				this.getRate().then(() => {
	// 					this.quoteCalculatePremium().then(() => {
	// 						//this.getQuoteSummary();
	// 						this.individualMotor.isAddonsAdded.next({
	// 							isAdded: true,
	// 							cover_id: event.cover_id,
	// 						});
	// 						this.transparentLoading = false;
	// 					});
	// 				});
	// 			});
	// 		},
	// 		error: err => {
	// 			this.transparentLoading = false;
	// 		},
	// 	});
	// }

	// addonsDeleted(event) {
	// 	this.transparentLoading = true;
	// 	const matchingAddon = this.selectedAddons.find(
	// 		addon => addon.addl_details.cover_id === event.cover_id,
	// 	);

	// 	const addongId = matchingAddon.add_on_id;
	// 	console.log(matchingAddon.add_on_id);
	// 	const payLoad = {
	// 		id: [addongId],
	// 	};
	// 	this.individualMotor.deleteAddons(payLoad).subscribe({
	// 		next: res => {
	// 			this.getAddonsList().then(() => {
	// 				this.getRate().then(() => {
	// 					this.quoteCalculatePremium().then(() => {
	// 						this.transparentLoading = false;
	// 					});
	// 				});
	// 			});
	// 		},
	// 		error: err => {
	// 			this.transparentLoading = false;
	// 		},
	// 	});
	// }

	// saveAdditionalInfo(formValue) {
	// 	this.isLoadingCarInfo = true;
	// 	this.updateRiskItem(formValue).then(() => {
	// 		this.addRiskItemTolist().then((riskList: any) => {
	// 			this.selectedVehicleData = riskList.data.find(
	// 				el => el.id == this.selectedVehicleData.id,
	// 			);
	// 			this.getRate().then(() => {
	// 				this.quoteCalculatePremium();
	// 				this.isLoadingCarInfo = false;
	// 			});
	// 		});
	// 	});
	// }

	// updateRiskItem(carInfo): Promise<any> {
	// 	return new Promise<any>((resolve, reject) => {
	// 		const payload = {
	// 			id: this.selectedVehicleData.id,
	// 			addl_details: carInfo,
	// 		};
	// 		this.individualMotor.updateRiskItem(payload).subscribe({
	// 			next: res => {
	// 				resolve(res);
	// 			},
	// 			error: err => {
	// 				this.serverErrorMsg = err.message;
	// 				console.log(err);
	// 				reject();
	// 			},
	// 		});
	// 	});
	// }

	// getCacheData(): Promise<void> {
	// 	return new Promise((resolve, reject) => {
	// 		this.individualMotor.getCacheData().subscribe({
	// 			next: res => {
	// 				console.log('cache Data response: ', res);
	// 				resolve();
	// 			},
	// 			error: err => {
	// 				this.isLoadingQuoteSummary = false;
	// 				this.serverErrorMsg = err.message;
	// 				if (err?.statusCode == 401 || err?.statusCode == 403) {
	// 					if (!this.isRenewalPolicy) {
	// 						this.router.navigate(['/revamp-individual-motor']);
	// 					} else {
	// 						this.router.navigate([
	// 							'/revamp-individual-motor/renewal/policies',
	// 						]);
	// 					}
	// 				}
	// 				console.log(err);
	// 			},
	// 		});
	// 	});
	// }

	// getQuoteSummary(): Promise<void> {
	// 	return new Promise((resolve, reject) => {
	// 		this.individualMotor.quoteSummary(this.referenceId).subscribe({
	// 			next: res => {
	// 				this.apiLoading = false;
	// 				this.quoteDetails = res;

	// 				this.selectedVehicle =
	// 					this.selectedVehicle || res.risk_item_details[0].id_no;

	// 				const selected_risk_item_details = res.risk_item_details.find(
	// 					item => item.id_no == this.selectedVehicle,
	// 				);

	// 				this.selectedVehicleData = selected_risk_item_details;

	// 				this.riskItemIds = [selected_risk_item_details.id];

	// 				this.upload_documents = res.risk_item_details.filter(item => {
	// 					return (
	// 						item.is_upload_documents === true &&
	// 						item.is_documents_uploaded === false
	// 					);
	// 				});

	// 				this.selectedProductId = selected_risk_item_details.product_code;

	// 				this.userName =
	// 					this.quoteDetails.quote_details.first_name +
	// 					' ' +
	// 					this.quoteDetails.quote_details.last_name;

	// 				this.driverList = this.quoteDetails.driver_details;

	// 				this.firstName =
	// 					this.currentLang === 'en'
	// 						? this.quoteDetails.quote_details.first_name
	// 						: this.quoteDetails.quote_details.addl_details.first_name_ar;

	// 				resolve();
	// 			},
	// 			error: err => {
	// 				this.apiLoading = false;
	// 				this.serverErrorMsg = err.message;

	// 				if (err?.statusCode == 401 || err?.statusCode == 403) {
	// 					this.router.navigate(['/revamp-individual-motor']);
	// 				}
	// 				this.isLoadingQuoteSummary = false;
	// 				console.log(err);
	// 			},
	// 		});
	// 	});
	// }

	// getProducts(): Promise<IQuoteProductItem[]> {
	// 	return new Promise<IQuoteProductItem[]>((resolve, reject) => {
	// 		this.individualMotor
	// 			.getProducts(this.quoteDetails.quote_details.customer_type_id)
	// 			.subscribe({
	// 				next: res => {
	// 					this.products = res;
	// 					this.selectedProduct = this.products.find(
	// 						product => product.product_id == this.selectedProductId,
	// 					);
	// 					console.info(this.selectedProduct);
	// 					this.getAddons();
	// 					resolve(res);
	// 				},
	// 				error: err => {
	// 					this.serverErrorMsg = err.message;
	// 					console.log(err);
	// 				},
	// 			});
	// 	});
	// }

	// addNewDriver(value: boolean) {
	// 	this.isLoadingQuoteSummary = true;
	// 	if (value) {
	// 		this.intializeData();
	// 	}
	// }

	// removeDriver(value) {
	// 	if (value) {
	// 		this.intializeData();
	// 	}
	// }

	// unlinkDriver(value) {
	// 	if (value) {
	// 		this.intializeData();
	// 	}
	// }

	// addRiskItemTolist(): Promise<IAddRiskItemListResponse> {
	// 	return new Promise<IAddRiskItemListResponse>((resolve, reject) => {
	// 		const payload: IAddRiskItemPayload = {
	// 			filter: { quote_id: this.quoteDetails.quote_details.id },
	// 			offSet: 0,
	// 			orderBy: {},
	// 			pageSize: 0,
	// 		};
	// 		this.individualMotor.addRiskItemTolist(payload).subscribe({
	// 			next: res => {
	// 				resolve(res);
	// 			},
	// 			error: err => {
	// 				reject(err);
	// 			},
	// 		});
	// 	});
	// }

	// getAddonsList(): Promise<any> {
	// 	return new Promise<any>((resolve, reject) => {
	// 		const payload: { quote_id: number } = {
	// 			quote_id: this.quoteDetails.quote_details.id,
	// 		};
	// 		this.individualMotor.getAddonsList(payload).subscribe({
	// 			next: res => {
	// 				this.selectedAddons = res;
	// 				resolve(res);
	// 			},
	// 			error: err => {
	// 				this.serverErrorMsg = err.message;
	// 				resolve(err);
	// 			},
	// 		});
	// 	});
	// }

	// listenToAddAddon() {
	// 	this.sub.add(
	// 		this.individualMotor.addAddons$.subscribe((res: any) => {
	// 			const addon = this.addonsWithGroup[0].add_ons.find(
	// 				el => el.cover_id === res?.addon.cover_id,
	// 			);
	// 			this.selectProduct(res.plan);
	// 			this.addonsSelected(addon);
	// 		}),
	// 	);
	// }

	// getUserInfo(): Promise<IUserInfo> {
	// 	return new Promise<IUserInfo>((resolve, reject) => {
	// 		this.individualMotor.getUserInfo().subscribe({
	// 			next: res => {
	// 				this.userInfo = res;
	// 				this.apiLoading = false;
	// 				resolve(res);
	// 			},
	// 			error: err => {
	// 				this.apiLoading = false;
	// 				this.serverErrorMsg = err.message;
	// 				console.log(err);
	// 			},
	// 		});
	// 	});
	// }

	// getVehicleImage(): Promise<any[]> {
	// 	return new Promise((resolve, reject) => {
	// 		const promises: Promise<any>[] = [];

	// 		// Use for...of instead of forEach for asynchronous operations
	// 		for (let i = 0; i < this.quoteDetails.risk_item_details.length; i++) {
	// 			const riskItem = this.quoteDetails.risk_item_details[i];
	// 			const imgId = riskItem.addl_details?.eska_make;

	// 			if (!imgId) {
	// 				console.error('Image ID is missing for riskItem:', riskItem);
	// 				continue; // Skip to the next iteration
	// 			}

	// 			const imagePromise = new Promise<void>((res, rej) => {
	// 				this.individualMotor.getVehicleImage(imgId).subscribe({
	// 					next: (resBlob: Blob) => {
	// 						const objectUrl = URL.createObjectURL(resBlob);
	// 						console.log('Vehicle Logo URL:', objectUrl);

	// 						// Update the vehicleLogoUrl directly in the risk_item_details array
	// 						this.quoteDetails.risk_item_details[
	// 							i
	// 						].addl_details.vehicleLogoUrl = objectUrl;

	// 						res(); // Resolve the promise when done
	// 					},
	// 					error: err => {
	// 						console.error('Error fetching vehicle image:', err);
	// 						rej(err); // Reject the promise in case of an error
	// 					},
	// 				});
	// 			});

	// 			promises.push(imagePromise); // Add each promise to the promises array
	// 		}

	// 		// Wait for all Promises to complete
	// 		Promise.all(promises)
	// 			.then(() => {
	// 				console.log('All vehicle images have been processed');
	// 				resolve(this.quoteDetails.risk_item_details); // Resolve with updated risk items
	// 			})
	// 			.catch(err => {
	// 				console.error(
	// 					'One or more errors occurred while fetching vehicle images:',
	// 					err,
	// 				);
	// 				reject(err); // Reject if any of the promises fail
	// 			});
	// 	});
	// }

	// getRate(): Promise<IGetRateResponse[]> {
	// 	return new Promise<IGetRateResponse[]>((resolve, reject) => {
	// 		this.individualMotor
	// 			.getRate({ reference_number: this.referenceId })
	// 			.subscribe({
	// 				next: res => {
	// 					this.rateReponse = res;
	// 					if (this.rateReponse.length <= 0 || !this.rateReponse) {
	// 						this.showModalOfNoRate();
	// 					}
	// 					this.allPlans.set(this.calculatePlans());
	// 					resolve(res);
	// 				},
	// 				error: err => {
	// 					this.isLoadingQuoteSummary = false;
	// 					this.serverErrorMsg = err.message;
	// 					console.log(err);
	// 				},
	// 			});
	// 	});
	// }

	// showModalOfNoRate() {
	// 	let deleteModalRef = this.ngbModal.open(RMIndividualMotorModalComponent, {
	// 		centered: true,
	// 		windowClass: 'custom-common-model-width',
	// 	});
	// 	deleteModalRef.componentInstance.btncustomClasses = 'background-bg-error';
	// 	deleteModalRef.componentInstance.variant = 'error';
	// 	deleteModalRef.componentInstance.btnConfirmLabel = 'COMMON.CANCEL';
	// 	deleteModalRef.componentInstance.desc =
	// 		'INDIVIDUAL_MOTOR.NO_RATES_AVAILABLE';
	// 	// Handle modal result
	// 	deleteModalRef.result
	// 		.then(result => {
	// 			if (result) {
	// 				this.router.navigateByUrl(`/revamp-individual-motor/quotation`);
	// 			}
	// 		})
	// 		.catch(() => {
	// 			console.log('Modal dismissed');
	// 		});
	// }

	// private calculatePlans() {
	// 	const car: Array<IGetRateResponse> = this.rateReponse.filter(
	// 		el => el.vehicle_id_no === this.selectedVehicleData.id_no,
	// 	);
	// 	return car.reduce((acc: any, currentValue: any) => {
	// 		Object.keys(currentValue.plans).forEach(planKey => {
	// 			if (!acc[planKey]) {
	// 				acc[planKey] = { ...currentValue.plans[planKey] };
	// 				acc[planKey].PolicyPremium = 0;
	// 				acc[planKey].NCDAmount = 0;
	// 				acc[planKey].LoyaltyDiscountAmount = 0;
	// 				acc[planKey].MultiVehicleDiscountAmount = 0;
	// 				acc[planKey].TotalPremium = 0;
	// 				acc[planKey].VATAmount = 0;
	// 				acc[planKey].SchemeDiscountAmount = 0;
	// 				acc[planKey].basePremium = 0;
	// 			}
	// 			acc[planKey].NCDAmount += currentValue.plans[planKey].NCDAmount || 0;
	// 			acc[planKey].LoyaltyDiscountAmount +=
	// 				currentValue.plans[planKey].LoyaltyDiscountAmount || 0;
	// 			acc[planKey].MultiVehicleDiscountAmount +=
	// 				currentValue.plans[planKey].MultiVehicleDiscountAmount || 0;
	// 			acc[planKey].TotalPremium +=
	// 				currentValue.plans[planKey].TotalPremium || 0;
	// 			acc[planKey].PolicyPremium +=
	// 				currentValue.plans[planKey].PolicyPremium || 0;
	// 			acc[planKey].VATAmount +=
	// 				(currentValue.plans[planKey].PolicyPremium || 0) * 0.15;
	// 			acc[planKey].SchemeDiscountAmount +=
	// 				currentValue.plans[planKey].SchemeDiscountAmount || 0;
	// 			const base =
	// 				(currentValue.plans[planKey].PolicyPremium || 0) +
	// 				Math.abs(currentValue.plans[planKey].LoyaltyDiscountAmount || 0) +
	// 				Math.abs(
	// 					currentValue.plans[planKey].MultiVehicleDiscountAmount || 0,
	// 				) +
	// 				Math.abs(currentValue.plans[planKey].NCDAmount || 0) +
	// 				Math.abs(currentValue.plans[planKey].SchemeDiscountAmount || 0);
	// 			acc[planKey].basePremium += base;
	// 		});
	// 		return acc;
	// 	}, {});
	// }

	// updateQuote(): Promise<{ reference_number: string; id: number }> {
	// 	return new Promise<{ reference_number: string; id: number }>(
	// 		(resolve, reject) => {
	// 			const payload = {
	// 				id: this.quoteDetails.quote_details.id,
	// 				source: 'b2c',
	// 				status_id: this.quoteDetails.quote_details.status_id,
	// 				addl_details: {
	// 					current_stage:
	// 						this.quoteDetails.quote_details.addl_details.current_stage,
	// 					is_history: true,
	// 				},
	// 			};
	// 			this.individualMotor.updateQuote(payload).subscribe({
	// 				next: res => {
	// 					this.referenceId = res.reference_number;
	// 					this.storage.mergeIntoExistValue(this.individualMotor.STORAGE_KEY, {
	// 						quoteDetails: this.quoteDetails,
	// 						reference_number: this.referenceId,
	// 					});
	// 					this.apiLoading = false;
	// 					resolve(res);
	// 				},
	// 				error: err => {
	// 					this.serverErrorMsg = err.message;
	// 					this.apiLoading = false;
	// 					console.log(err);
	// 					reject();
	// 				},
	// 			});
	// 		},
	// 	);
	// }

	// getAddons() {
	// 	this.individualMotor
	// 		.getAddons(this.quoteDetails.quote_details.customer_type_id)
	// 		.subscribe({
	// 			next: res => {
	// 				this.addonsWithGroup = res;
	// 				if (
	// 					this.addonsWithGroup?.length &&
	// 					this.selectedProduct?.product_id
	// 				) {
	// 					// filter Addons based on selected Product
	// 					this.filterAddonsBySelectedProduct();
	// 				}
	// 			},
	// 			error: err => {
	// 				this.serverErrorMsg = err.message;
	// 				console.log(err);
	// 			},
	// 		});
	// }

	// filterAddonsBySelectedProduct() {
	// 	this.currentAddons = this.addonsWithGroup[0]?.add_ons.filter(addon => {
	// 		const hasProduct = addon.applicable_products.find(
	// 			product => product.product_id == this.selectedProduct?.product_id,
	// 		);
	// 		return hasProduct;
	// 	});

	// 	const premiumDetails = this.selectedVehicle
	// 		? this.quoteDetails.quote_details?.premium_details?.find(
	// 				item => item.vehicle_id_no == this.selectedVehicle,
	// 			)
	// 		: this.quoteDetails?.quote_details?.premium_details[0];
	// 	const quoteAddons =
	// 		premiumDetails?.plans[this.selectedProduct.product_id]?.add_ons;

	// 	quoteAddons &&
	// 		Object.entries(quoteAddons).forEach(([key, value]) => {
	// 			this.currentAddons?.forEach(addon => {
	// 				if (addon.cover_id == value.cover_id) {
	// 					addon.Premium = value.Premium;
	// 					addon.PremiumVatAmount = value.PremiumVatAmount;
	// 					addon.TotalPremium = value.TotalPremium;
	// 				}
	// 			});
	// 		});
	// 	this.getAddonsList().then(res => {
	// 		console.log(res);
	// 		this.selectedAddons = res;
	// 		this.currentAddons = this.currentAddons.map(item => {
	// 			return { ...item, isSelected: 0 };
	// 		});
	// 		let current_vehicle_risk_id =
	// 			this.selected_vehicle_risk_Id ||
	// 			this.quoteDetails.risk_item_details[0].id;
	// 		let result = this.currentAddons.map(item => {
	// 			let elm = this.selectedAddons.find(
	// 				addon =>
	// 					addon.addl_details.cover_id == item.cover_id &&
	// 					addon.risk_id[0] == current_vehicle_risk_id,
	// 			);
	// 			if (elm) {
	// 				return { ...item, isSelected: 1 };
	// 			} else {
	// 				return { ...item };
	// 			}
	// 		});
	// 		this.currentAddons = result;

	// 		console.log(result);
	// 	});
	// }

	// linkProduct(): Promise<{ id: number }> {
	// 	return new Promise<{ id: number }>((resolve, reject) => {
	// 		this.selected_vehicle_risk_Id =
	// 			this.selected_vehicle_risk_Id ||
	// 			this.quoteDetails.risk_item_details[0].id;
	// 		const selected_risk_item_details =
	// 			this.quoteDetails.risk_item_details.find(
	// 				item => item.id == this.selected_vehicle_risk_Id,
	// 			);
	// 		if (selected_risk_item_details) {
	// 			this.selected_vehicle_risk_Id = selected_risk_item_details.id;
	// 		}
	// 		const payload = {
	// 			id: this.selected_vehicle_risk_Id,
	// 			product_code: this.selectedProduct?.product_id,
	// 		};
	// 		this.individualMotor.linkProduct(payload).subscribe({
	// 			next: res => {
	// 				console.log('Link Product Response: ', res);
	// 				resolve(res);
	// 			},
	// 			error: err => {
	// 				this.serverErrorMsg = err.message;
	// 				console.log(err);
	// 			},
	// 		});
	// 	});
	// }

	// quoteCalculatePremium(): Promise<void> {
	// 	return new Promise((resolve, reject) => {
	// 		this.apiLoading = true;
	// 		this.individualMotor
	// 			.quoteCalculatePremium({
	// 				id: this.quoteDetails.quote_details.id,
	// 			})
	// 			.subscribe({
	// 				next: res => {
	// 					this.netValue = res.premium;
	// 					this.apiLoading = false;
	// 					resolve();
	// 				},
	// 				error: err => {
	// 					this.apiLoading = false;
	// 					this.serverErrorMsg = err.message;
	// 					console.log(err);
	// 				},
	// 			});
	// 	});
	// }

	// navigateToOtp() {
	// 	this.router.navigate(['/revamp-individual-motor/opt']);
	// }

	// togglePremiumDetailsFooterExpansion() {
	// 	this.isPremiumDetailsFooterExpanded = !this.isPremiumDetailsFooterExpanded;
	// }

	// viewQuote() {
	// 	this.apiLoading = true;
	// 	// this.individualMotor.viewQuote(this.referenceId).subscribe({
	// 	// 	next: res => {
	// 	// 			next: res => {
	// 	// this.storage.mergeIntoExistValue(this.individualMotor.STORAGE_KEY, {
	// 	// 	txId: res.txId,
	// 	// 	phone_no: res.phone_no,
	// 	// });
	// 	// Goto OTP

	// 	this.apiLoading = false;
	// 	this.router.navigate(['/revamp-individual-motor/renewal/payment']);
	// 	// },error: err => {
	// 	// 	console.log(err);
	// 	// },
	// 	// },
	// 	// 	error: err => {
	// 	// 		this.apiLoading = false;
	// 	// 		this.serverErrorMsg = err.message;
	// 	// 		console.log(err);
	// 	// 	},
	// 	// });
	// }

	// GR_code() {
	// 	this.apiLoading = true;
	// 	let payload = {
	// 		reference_number: this.referenceId,
	// 	};

	// 	this.individualMotor.QR_code(payload).subscribe({
	// 		next: res => {
	// 			console.log(res);

	// 			this.openUpgradPopup(res);
	// 			this.apiLoading = false;
	// 		},
	// 		error: err => {
	// 			this.apiLoading = false;
	// 			if (err.statusCode == 403) {
	// 				this.router.navigate(['/revamp-individual-motor']);
	// 			}
	// 			console.log(err);
	// 		},
	// 	});
	// }

	// openUpgradPopup(QRData) {
	// 	this.sendVechilImagModalRef = this.ngbModal.open(
	// 		SendVehicleImagesComponent,
	// 		{
	// 			centered: true,
	// 			windowClass: 'upload-popup',
	// 		},
	// 	);

	// 	this.sendVechilImagModalRef.componentInstance.customerName = this.firstName;

	// 	this.sendVechilImagModalRef.componentInstance.QR_data = QRData.data;
	// 	this.sendVechilImagModalRef.componentInstance.SendVehicleImages.subscribe(
	// 		event => {
	// 			this.apiLoading = true;
	// 			let payload = {
	// 				reference_number: this.referenceId,
	// 			};

	// 			this.sendVechilImagModalRef.componentInstance.error = false;
	// 			this.sendVechilImagModalRef.componentInstance.status = false;
	// 			this.individualMotor.uploadImageSms(payload).subscribe({
	// 				next: res => {
	// 					console.log(res);
	// 					if (res.status) {
	// 						this.sendVechilImagModalRef.componentInstance.status = res.status;
	// 					}

	// 					this.apiLoading = false;
	// 				},
	// 				error: err => {
	// 					this.sendVechilImagModalRef.componentInstance.error = true;
	// 					this.apiLoading = false;
	// 					this.serverErrorMsg = err.message;
	// 					console.log(err);
	// 				},
	// 			});
	// 		},
	// 	);
	// }

	// openUpgradModal() {
	// 	const upgradeModalCard = this.ngbModal.open(UpgradePopupMotorComponent, {
	// 		centered: true,
	// 		windowClass: 'upgrade-popup',
	// 	});
	// 	upgradeModalCard.componentInstance.btncustomClasses =
	// 		'background-bg-primary';
	// 	upgradeModalCard.componentInstance.PlanSelectName =
	// 		this.selectedProduct.short_name;
	// 	let upgradePlanName =
	// 		this.selectedProduct.long_name === 'Smart'
	// 			? 'Comprehensive'
	// 			: this.selectedProduct.short_name === 'WAFI Basic'
	// 				? 'WAFI Smart'
	// 				: '';
	// 	upgradeModalCard.componentInstance.upgradToPlanName = upgradePlanName;
	// 	upgradeModalCard.componentInstance.skip.subscribe(() => {
	// 		this.viewQuote();
	// 		upgradeModalCard.close();
	// 	});
	// 	upgradeModalCard.componentInstance.upgrade.subscribe(event => {
	// 		this.selectProduct(event);
	// 		upgradeModalCard.close();
	// 	});
	// }

	// proceed() {
	// 	this.apiLoading = true;
	// 	this.getQuoteSummary().then(() => {
	// 		this.getUserInfo().then(res => {
	// 			this.updateQuote().then(() => {
	// 				if (this.upload_documents.length > 0) {
	// 					this.storage.Setvalue('showQrCode', true);
	// 					if (this.userInfo.data['otp-verified']) {
	// 						this.GR_code();
	// 					} else {
	// 						this.viewQuote();
	// 					}
	// 				} else {
	// 					this.storage.RemoveValue('showQrCode');
	// 					const hascomperhensivId = this.products.some(
	// 						item => item.product_id == 600461,
	// 					);
	// 					if (!hascomperhensivId) {
	// 						this.openUpgradModal();
	// 					} else {
	// 						this.viewQuote();
	// 					}
	// 				}
	// 				this.apiLoading = false;
	// 			});
	// 		});
	// 	});
	// }

	// changeInput(event) {
	// 	this.isVehicleNotExist = false;
	// 	this.serverErrorMsg = '';
	// }

	showUpdateInformation() {
		const dialogRef = this.dialog.open(RmUpdateInfoPopupComponent, {
			panelClass: 'custom-renewal-width', // 80% of the available width
			disableClose: true,
		});
		// Subscribe to router events to close the dialog on navigation
		this.routerSubscription = this.router.events.subscribe(event => {
			if (event instanceof NavigationStart) {
				// Close the dialog when navigation starts
				dialogRef.close();
			}
		});
	}

	validateQuoteInfo(): Promise<boolean> {
		return new Promise<boolean>((resolve, reject) => {
			this.individualMotor
				.validateQuoteInfo({
					reference_number: this.referenceId,
				})
				.subscribe({
					next: (res: IValidateQuoteResponse) => {
						this.validateResponse = res;
						const isValidSequences =
							this.validateResponse.valid_sequence_no.length &&
							this.validateResponse.valid_sequence_no.every(
								sequence => sequence.valid,
							);
						const isValid =
							this.validateResponse.statusCode == 200 &&
							this.validateResponse.valid_address &&
							this.validateResponse.valid_dob &&
							isValidSequences;
						this.storage.mergeIntoExistValue(this.individualMotor.STORAGE_KEY, {
							validateRes: res,
						});
						resolve(isValid);
					},
					error: err => {
						console.log(err);
						this.isLoadingQuoteSummary = false;
						reject(false);
					},
				});
		});
	}

	ngOnDestroy() {
		// Unsubscribe from the router events when the component is destroyed
		if (this.routerSubscription) {
			this.routerSubscription.unsubscribe();
		}
	}
}
