import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { ArtButtonComponent } from '../../../design-system/art-button/art-button.component';
import { IconComponent } from '../../../design-system/icon/icon.component';
@Component({
	selector: 'art-policy-pending-popup',
	standalone: true,
	imports: [CommonModule, IconComponent, ArtButtonComponent, TranslateModule],
	templateUrl: './policy-pending-popup.component.html',
	styleUrls: ['./policy-pending-popup.component.scss'],
})
export class PolicyPendingPopupComponent {
	currentLang: string;

	constructor(private readonly ngbactivemodl: NgbActiveModal) {
		const lang = localStorage.getItem('selectedLang');
		this.currentLang = lang || 'en';
	}

	onDismissModal() {
		this.ngbactivemodl.dismiss();
	}
}
