import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmRenewalStepperComponent } from './rm-renewal-stepper.component';

describe('RmRenewalStepperComponent', () => {
  let component: RmRenewalStepperComponent;
  let fixture: ComponentFixture<RmRenewalStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmRenewalStepperComponent]
    });
    fixture = TestBed.createComponent(RmRenewalStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
