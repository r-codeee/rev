import { Component, inject } from '@angular/core';
import { StepperService } from 'src/app/design-system/services/stepper.service';

@Component({
  selector: 'app-rm-renewal-stepper',
  templateUrl: './rm-renewal-stepper.component.html',
  styleUrls: ['./rm-renewal-stepper.component.scss']
})
export class RmRenewalStepperComponent {
protected stepperService = inject(StepperService);

  ngOnInit() {
    this.stepperService.setStepsData([ 
      {
        titleKey: 'INDIVIDUAL_MOTOR.ADD_VEHICLES',
        url: '/revamp-individual-motor/renewal-stepper/add-vehicles',
        isActive: true,
        isValid: false,
      },
      {
        titleKey: 'COMMON.PREMIUM_CALCULATION',
        url: '/revamp-individual-motor/renewal-stepper/premium-calculation',
        isActive: false,
        isValid: false,
      },
      {
        titleKey: 'COMMON.REVIEW_AND_PAYMENT',
        url: '/revamp-individual-motor/renewal-stepper/payment',
        isActive: false,
        isValid: false,
      },
    ]);
  }
}
