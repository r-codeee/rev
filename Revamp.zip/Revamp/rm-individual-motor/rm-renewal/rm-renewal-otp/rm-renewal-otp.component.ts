import {
	AfterViewInit,
	Component,
	EventEmitter,
	inject,
	OnInit,
	Output,
	ViewChild,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
	delay,
	finalize,
	Subject,
	Subscription,
	switchMap,
	takeUntil,
	tap,
} from 'rxjs';
import { RmOTPComponentConfigI } from 'src/app/rm-otp/rm-motor-otp/rm-motor-otp.component';
import { RMOtpService } from 'src/app/rm-otp/services/rm-otp-service.service';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { timerDown } from 'src/app/rm-otp/utilities/timer.utilities';
import { OtpComponent } from 'src/app/design-system/otp/otp.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { SadadPaymentPopupComponent } from '../sadad-payment-popup/sadad-payment-popup.component';
import { PolicyPendingPopupComponent } from '../policy-pending-popup/policy-pending-popup.component';

@Component({
	selector: 'app-rm-renewal-otp',
	templateUrl: './rm-renewal-otp.component.html',
	styleUrls: ['./rm-renewal-otp.component.scss'],
})
export class RmRenewalOtpComponent implements OnInit, AfterViewInit {
	$destroy: Subject<unknown> = new Subject();
	timerDisplay = '';
	enableResend = false;
	isEnableResend = false;
	invalidOTP = false;
	CustomSendPayload;
	CustomReSendPayload;
	VerifyOtpRequestByMobile = false;
	isFirstOtp = false;
	timeToReset = 300; // in seconds;
	errorMessage = '';
	timerSubscription: Subscription = new Subscription();
	@ViewChild(OtpComponent) otpComRef: OtpComponent;
	componentConfig: RmOTPComponentConfigI = {
		isFooter: true,
		isChangePhoneEnabled: false,
		isRedirectEnabled: true,
		isResendEnabled: true,
		isCounterEnabled: true,
		headerTitleCustomClasses: '',
	};
	@Output() otpValue: EventEmitter<string> = new EventEmitter();

	private readonly otpService = inject(RMOtpService);
	private readonly individualMotorService = inject(IndividualMotorService);
	private readonly languageService = inject(LanguageService);
	readonly router = inject(Router);
	readonly activatedRoute = inject(ActivatedRoute);
	config = this.otpService.config;
	currentLang = this.languageService.currentLang;
	txId: string;
	reference_number: string;
	hiddenPhoneNo: string;
	phoneNo: string;
	isLoading: boolean = false;

	otpVerified = false;
	userInfo;
	queryParams;
	private storage = inject(ARTStorageService);

	constructor(private readonly ngbModal: NgbModal) {}

	ngOnInit(): void {
		this.queryParams = this.activatedRoute.snapshot.queryParams;
		this.otpService.config.length = 6;
		if (this.queryParams?.lang && this.queryParams?.rnd) {
			this.isLoading = true;
			this.individualMotorService.generateAuthCode().subscribe(res => {
				let authorizationCode = res.Authorization_code;
				if (authorizationCode) {
					this.individualMotorService
						.generateAccessToken(authorizationCode)
						.subscribe(res => {
							let token = 'Bearer' + ' ' + res.Access_token;
							localStorage.setItem('Pay_Token', token);
							sessionStorage.setItem('Pay_session_token', token);
							this.guestLogin()
								.then(() => {
									this.getUserInfo().then(res => {
										this.otpVerified = res.data?.['otp-verified'];
										this.sendOTP();
									});
								})
								.catch(err => {
									this.isLoading = false;
								});
						});
				}
			});
		} else {
			this.sendOTP();
		}
	}

	ngAfterViewInit(): void {
		this.otpComRef.ngOtpInputRef.otpForm.disable();
	}

	sendOTP() {
		this.isLoading = true;
		this.individualMotorService.sendRenewalOTP().subscribe({
			next: res => {
				this.initializeOTP();
				this.txId = res.txId;
				this.hiddenPhoneNo = res.phone_no;
				this.isLoading = false;
			},
			error: err => {
				this.isLoading = false;
				console.log(err);
			},
		});
	}

	initializeOTP() {
		this.timerSubscription.unsubscribe();
		this.timerSubscription = this.timerExpire(this.timeToReset);
		this.otpComRef.ngOtpInputRef.otpForm.enable();
		this.isEnableResend = false;
	}

	timerExpire(timeToLive: number) {
		return timerDown(Math.round(timeToLive))
			.pipe(
				takeUntil(this.$destroy),
				finalize(() => {
					this.timerDisplay = '00:00';
					if (this.timerDisplay == '00:00') {
						this.otpComRef.ngOtpInputRef.otpForm.enable();
						this.isEnableResend = true;
					}
				}),
			)
			.subscribe(timeInfo => {
				this.timerDisplay = timeInfo.time;
			});
	}

	changeOTP(val: any) {
		this.errorMessage = '';
		if (val.length === this.config.length) {
			this.isLoading = true;
			this.individualMotorService
				.verifyRenewalOTP({ TxId: this.txId, value: val })
				.subscribe({
					next: res => {
						if (res && res.status) {
							if (this.hasValidPolicyParams() && this.queryParams?.rnd) {
								this.getPolicyRenewalList()
									.then(response => {
										const policies: any[] = response.policy;
										let policy = policies.find(
											item => item.POLICY_NUMBER == this.userInfo.policy_number,
										);
										if (policy) {
											this.getPolicyRenewal(
												policy.POLICY_ID,
												policy.SEGMENT_CODE,
											);
										} else {
											this.router.navigate([
												'/revamp-individual-motor/renewal/policies',
											]);
										}
									})
									.catch(err => {
										this.isLoading = false;
										console.log(err);
									});
							} else {
								this.router.navigate([
									'/revamp-individual-motor/renewal/policies',
								]);
							}
						} else {
							this.errorMessage = res.error;
							this.isLoading = false;
						}
					},
					error: err => {
						// this.ngOtpInputRef?.otpForm.reset();
						this.errorMessage = err.error;
						this.invalidOTP = true;
						this.isLoading = true;
					},
				});
		}
	}

	getPolicyRenewal(POLICY_ID: number, SEGMENT_CODE: string) {
		this.isLoading = true;
		this.individualMotorService
			.getPolicyRenew(POLICY_ID, SEGMENT_CODE)
			.subscribe({
				next: res => {
					this.getQuoteSummary(res.reference_number).then(response => {
						if (![11, 12].includes(response.quote_details.status_id)) {
							console.log(res);
							this.storage.mergeIntoExistValue(
								this.individualMotorService.STORAGE_KEY,
								{
									quoteResponse: res,
								},
							);
							this.isLoading = false;
							this.storage.Setvalue('is-Renewal-Policy', true);
							this.router.navigateByUrl(
								'revamp-individual-motor/renewal/premium-calculation',
							);
						} else {
							if (response.quote_details.status_id == 12) {
								this.openSadadPaymentModal();
							} else {
								this.openPolicyPendingModal();
							}
							this.isLoading = false;
						}
					});
				},
				error: err => {
					this.isLoading = false;
					this.router.navigate(['/revamp-individual-motor/']);
					console.log(err);
				},
			});
	}

	openSadadPaymentModal() {
		const sadadPaymentModalCard = this.ngbModal.open(
			SadadPaymentPopupComponent,
			{
				centered: true,
				windowClass: 'upgrade-popup',
			},
		);
	}
	openPolicyPendingModal() {
		const openPolicyPendingModalCard = this.ngbModal.open(
			PolicyPendingPopupComponent,
			{
				centered: true,
				windowClass: 'upgrade-popup',
			},
		);
	}

	getQuoteSummary(referenceId): Promise<any> {
		return new Promise((resolve, reject) => {
			this.individualMotorService.quoteSummary(referenceId).subscribe({
				next: res => {
					this.isLoading = false;
					resolve(res);
				},
				error: err => {
					if (err?.statusCode == 401) {
						this.router.navigate(['/revamp-individual-motor']);
					}
					this.isLoading = false;
				},
			});
		});
	}

	hasValidPolicyParams() {
		return this.userInfo?.id_no && this.userInfo?.policy_number;
	}

	getUserInfo(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService.getUserInfo().subscribe({
				next: res => {
					this.otpVerified = res.data?.['otp-verified'];
					this.userInfo = res.data;
					resolve(res.data);
				},
				error: err => {
					resolve({});
					console.log(err);
				},
			});
		});
	}

	guestLogin(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService
				.guestLogin()
				.pipe(
					tap((res: any) => {
						localStorage.removeItem('dcp-token');
						localStorage.setItem('dcp-token', res.token);
					}),
					delay(1200),
					switchMap(() =>
						this.individualMotorService.getCacheDataWithCredential(),
					),
				)
				.subscribe({
					next: res => {
						console.log(res);
						resolve(res);
					},
					error: ({ error }) => {
						this.errorMessage = error?.message || error;
						reject(error);
					},
				});
		});
	}

	getPolicyRenewalList(): Promise<any> {
		return new Promise<any>((resolve, reject) => {
			this.individualMotorService.getPolicyRenewalList().subscribe({
				next: res => {
					resolve(res);
				},
				error: ({ error }) => {
					this.errorMessage = error?.message || error;
					reject(error);
				},
			});
		});
	}

	ngOnDestroy(): void {
		this.$destroy.next(null);
		this.$destroy.complete();
		this.$destroy.unsubscribe();
	}
}
