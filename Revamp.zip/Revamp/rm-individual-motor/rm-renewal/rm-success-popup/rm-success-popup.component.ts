import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
	selector: 'art-rm-success-popup',
	templateUrl: './rm-success-popup.component.html',
	styleUrls: ['./rm-success-popup.component.scss'],
})
export class RmSuccessPopupComponent {
	constructor(
		private readonly dialogRef: MatDialogRef<RmSuccessPopupComponent>,
		private readonly router: Router,
	) {}

	close() {
		this.dialogRef.close('close');
	}

	goToUpdateInfoPage() {
		this.close();
		this.router.navigateByUrl(
			'/revamp-individual-motor/renewal/premium-calculation',
		);
	}
}
