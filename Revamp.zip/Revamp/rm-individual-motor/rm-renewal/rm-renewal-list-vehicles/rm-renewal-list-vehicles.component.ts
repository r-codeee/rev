import { Component, HostListener, inject, OnInit } from '@angular/core';
import { IRatesInfoResponseData } from '../../types/IRatesInfoResponse';
import { ARTStorageService } from '../../../utils/services/shared/storage.service';
import { MultiMotorService } from '../../services/multi-motor.service';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { IRenewalVehilce, IVehicle } from '../../types/IVehicle';
import { IQuoteResponse } from '../../models/individualMotorDto';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { delay, switchMap, tap } from 'rxjs';
import moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UpgradePopupMotorComponent } from '../../upgrade-popup-motor/upgrade-popup-motor.component';
import { SadadPaymentPopupComponent } from '../sadad-payment-popup/sadad-payment-popup.component';
import { PolicyPendingPopupComponent } from '../policy-pending-popup/policy-pending-popup.component';
interface StorageDataType {
	userName: string;
	dateOfBirth: string;
	agentCode: string;
	insuranceType: string;
	mobileNumber: string;
	nationalId: string;
	emailAddress: string;
	policyStartDate: string;
	privacyPolicyConsent: boolean;
	referenceId: string;
	vehicleList: Array<IVehicle>;
	ratesInfoData: IRatesInfoResponseData;
	quoteResponse: IQuoteResponse;
}
const FileSaver = require('file-saver');
@Component({
	selector: 'app-rm-renewal-list-vehicles',
	templateUrl: './rm-renewal-list-vehicles.component.html',
	styleUrls: ['./rm-renewal-list-vehicles.component.scss'],
})
export class RmRenewalListVehiclesComponent implements OnInit {
	userName: string;
	carsNumber: number;
	cars = [];
	isLoading: boolean = false;
	isOnlyOneCar = true;
	expireStatus: string;
	ratesInfoData: IRatesInfoResponseData = {
		coverage: null,
		finalRateSummary: null,
		rateSummmary: [],
		ownerInformation: null,
		vehicleAndDriverInfo: null,
		productAddons: null,
	};
	private storage = inject(ARTStorageService);
	private readonly multiMotor = inject(MultiMotorService);
	private readonly individualMotorService = inject(IndividualMotorService);
	private readonly router = inject(Router);
	private readonly authService = inject(AuthService);
	storageData: StorageDataType;
	referenceId: string;
	vehicleList: Array<any>;
	currentLang;
	loadingPolicyId;
	downloadPolicyId;
	isLoadingQuoteSummary = false;
	isMobile: boolean = false;
	constructor(private readonly ngbModal: NgbModal) {
		this.currentLang = localStorage.getItem('selectedLang');
	}
	ngOnInit(): void {
		this.isLoadingQuoteSummary = true;
		this.checkIfMobile();
		this.policyList();
	}
	policyList() {
		return new Promise((resolve, reject) => {
			// this.authService
			// 	.guestLogin()
			// 	.pipe(
			// 		tap((res: any) => {
			// 			localStorage.removeItem('dcp-token');
			// 			localStorage.setItem('dcp-token', res.token);
			// 		}),
			// 		delay(1200),
			// 		switchMap(() => this.getCacheData()),
			// 	)
			// 	.subscribe(res => {
			this.individualMotorService.getPolicyListrenewal().subscribe({
				next: res => {
					this.vehicleList = res?.list;
					this.vehicleList = this.vehicleList
						.map(obj => {
							let expireStatus = '';
							let daysToExpire = Number(obj.DAYS_DIFFERENCE);
							if (daysToExpire < 0) {
								expireStatus = 'GRACE_PERIOD';
							} else if (daysToExpire == 0) {
								expireStatus = 'EXPIRES_TODAY';
							} else if (daysToExpire == 1) {
								expireStatus = 'EXPIRES_TOMORROW';
							} else if (daysToExpire > 1) {
								if (daysToExpire == 2) {
									expireStatus = 'EXPIRING_WITHIN_TWO_DAYS';
								} else if (daysToExpire > 2 && daysToExpire <= 35) {
									expireStatus = 'EXPIRING_WITHIN';
								} else if (daysToExpire > 35) {
									expireStatus = 'EXPIRY_DATE';
								}
							} else {
								expireStatus = 'EXPIRED';
							}

							return {
								...obj,
								DAYS_DIFFERENCE: daysToExpire.toString(),
								expireStatus: expireStatus,
							};
						})
						.sort(
							(a, b) =>
								new Date(a.POLICY_EXPIRY_DATE).getTime() -
								new Date(b.POLICY_EXPIRY_DATE).getTime(),
						);

					this.userName =
						this.currentLang === 'en'
							? res.customer_info.first_name_en
							: res.customer_info.first_name_ar;
					this.carsNumber = res?.count;
					this.isLoadingQuoteSummary = false;
				},
				error: err => {
					this.isLoadingQuoteSummary = false;

					this.router.navigate(['/revamp-individual-motor/']);

					console.log(err);
				},
			});
			// });
		});
	}
	btnRenewalClick(POLICY_ID: number, POLICY_NUMBER: string) {
		this.loadingPolicyId = POLICY_ID;
		this.isLoading = true;
		return new Promise((resolve, reject) => {
			// this.authService
			// 	.guestLogin()
			// 	.pipe(
			// 		tap((res: any) => {
			// 			localStorage.removeItem('dcp-token');
			// 			localStorage.setItem('dcp-token', res.token);
			// 		}),
			// 		delay(1200),
			// 		switchMap(() => this.getCacheData()),
			// 	)
			// 	.subscribe(res => {
			this.individualMotorService
				.getPolicyRenew(POLICY_ID, POLICY_NUMBER)
				.subscribe({
					next: res => {
						this.getQuoteSummary(res.reference_number).then(response => {
							if (![11, 12].includes(response.quote_details.status_id)) {
								console.log(res);
								this.storage.mergeIntoExistValue(
									this.individualMotorService.STORAGE_KEY,
									{
										quoteResponse: res,
										quoteDetails: response,
									},
								);

								this.loadingPolicyId = null;
								this.isLoading = false;
								this.storage.Setvalue('is-Renewal-Policy', true);
								this.router.navigateByUrl(
									'revamp-individual-motor/renewal/premium-calculation',
								);
							} else {
								if (response.quote_details.status_id == 12) {
									this.openSadadPaymentModal();
								} else {
									this.openPolicyPendingModal();
								}
								this.isLoading = false;
							}
						});
					},
					error: err => {
						this.isLoadingQuoteSummary = false;
						this.loadingPolicyId = null;
						this.isLoading = false;

						this.router.navigate(['/revamp-individual-motor/']);

						console.log(err);
					},
				});
			// });
		});
	}

	openSadadPaymentModal() {
		const sadadPaymentModalCard = this.ngbModal.open(
			SadadPaymentPopupComponent,
			{
				centered: true,
				windowClass: 'upgrade-popup',
			},
		);
	}
	openPolicyPendingModal() {
		const openPolicyPendingModalCard = this.ngbModal.open(
			PolicyPendingPopupComponent,
			{
				centered: true,
				windowClass: 'upgrade-popup',
			},
		);
	}

	getCacheData(): Promise<void> {
		return new Promise((resolve, reject) => {
			this.individualMotorService.getCacheDataWithCredential().subscribe({
				next: res => {
					console.log('cache Data response: ', res);
					resolve();
				},
				error: err => {
					this.isLoadingQuoteSummary = false;
					if (err?.statusCode == 401) {
						this.router.navigate(['/revamp-individual-motor/']);
					}
					console.log(err);
				},
			});
		});
	}
	btnAddPolicyClick() {
		this.router.navigateByUrl('/revamp-individual-motor/quotation');
	}

	download(policy_id: number, POLICY_NUMBER: string) {
		this.downloadPolicyId = policy_id;
		this.isLoading = true;
		const pdfName = 'policy_details_' + POLICY_NUMBER + '.pdf';
		return new Promise((resolve, reject) => {
			this.authService
				.guestLogin()
				.pipe(
					tap((res: any) => {
						localStorage.removeItem('dcp-token');
						localStorage.setItem('dcp-token', res.token);
					}),
					delay(1200),
					switchMap(() =>
						this.individualMotorService.getCacheDataWithCredential(),
					),
				)
				.subscribe(res => {
					this.individualMotorService
						.downloadPolicy(policy_id, POLICY_NUMBER)
						.subscribe({
							next: res => {
								this.downloadPolicyId = null;
								let blob = new Blob([res], { type: 'application/pdf' });
								FileSaver.saveAs(blob, pdfName);
								this.isLoading = false;
							},
							error: err => {
								this.downloadPolicyId = null;
								this.isLoading = false;
								//this.serverErrorMsg = err.message;
								console.log(err);
							},
						});
				});
		});
	}

	getQuoteSummary(referenceId): Promise<any> {
		return new Promise((resolve, reject) => {
			this.individualMotorService.quoteSummary(referenceId).subscribe({
				next: res => {
					this.isLoadingQuoteSummary = false;
					resolve(res);
				},
				error: err => {
					if (err?.statusCode == 401) {
						this.router.navigate(['/revamp-individual-motor']);
					}
					this.isLoadingQuoteSummary = false;
				},
			});
		});
	}

	getNumberFromString(input: string): number | null {
		const regex = /\d+/; // Regular expression to find numeric digits
		const result = regex.exec(input); // Execute regex on the input string
		return result ? parseInt(result[0], 10) : null;
	}

	@HostListener('window:resize', ['$event'])
	onResize(event: any) {
		this.checkIfMobile();
	}

	checkIfMobile(): void {
		this.isMobile = window.innerWidth <= 768;
	}
}
