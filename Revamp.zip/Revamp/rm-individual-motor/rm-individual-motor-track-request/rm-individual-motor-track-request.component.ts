import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';
import { TRackRequestType } from 'src/app/design-system/types/TrackRequestType';

@Component({
	selector: 'art-rm-individual-motor-track-request',
	templateUrl: './rm-individual-motor-track-request.component.html',
	styleUrls: ['./rm-individual-motor-track-request.component.scss'],
})
export class RMIndividualMotorTrackRequestComponent {
	private readonly STORAGE_KEY = 'vveSession';
	private readonly storage = inject(ARTStorageService);
	private readonly router = inject(Router);

	trackRequestData: TRackRequestType = {
		refferenceNumber: '123333333',
		firstStausDesc: '07 Feb 2024',
		headerLabel: 'TRACK_REQUEST.POLICY_ISSUING_TRACKING',
		headerSubtitle: 'TRACK_REQUEST.YOU_CAN_TRACK',
		refferenceNumberLabel: 'TRACK_REQUEST.REFERENEC_NUMBER',
		headerIcon: 'art-light-copy',
		startStausIcon: 'art-green-success',
		firstStausTitle: 'TRACK_REQUEST.POLICY_ISSUING_TRACKING',
		firstStausLabel: 'TRACK_REQUEST.DONE',
		endStausIcon: 'art-file-sync',
		secondStausTitle: 'TRACK_REQUEST.POLICY_ISSUED',
		secondStausLabel: 'TRACK_REQUEST.WILL_BE_SENT_BY_EMAIL',
		secondStausDate: 'TRACK_REQUEST.WITHIN_2_HOURS',
		secondStausColor: 'warning',
		endStausIconCustomClass:'background-tint-orange p-2a rounded-circle overflow-visible w-h-46',
		btnText: 'TRACK_REQUEST.BACK_TO_HOME',
	};

	ngOnInit() {
		// @TODO : Get the data from local storage
		// this.customerData = this.storage.GetValue(this.STORAGE_KEY);
	}

	backToHome() {
		this.router.navigate(['/']);
	}
}
