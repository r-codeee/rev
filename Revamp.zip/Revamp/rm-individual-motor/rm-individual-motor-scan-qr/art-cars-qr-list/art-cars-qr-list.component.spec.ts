import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArtCarsQrListComponent } from './art-cars-qr-list.component';

describe('ArtCarsQrListComponent', () => {
  let component: ArtCarsQrListComponent;
  let fixture: ComponentFixture<ArtCarsQrListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ArtCarsQrListComponent]
    });
    fixture = TestBed.createComponent(ArtCarsQrListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
