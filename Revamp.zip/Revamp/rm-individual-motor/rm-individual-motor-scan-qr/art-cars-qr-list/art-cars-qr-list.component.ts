import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { IconComponent } from '../../../design-system/icon/icon.component';
import { TranslateModule } from '@ngx-translate/core';
import { ARTStorageService } from '../../../utils/services/shared/storage.service';

@Component({
	selector: 'art-cars-qr-list',
	standalone: true,
	imports: [CommonModule, IconComponent, TranslateModule, NgOptimizedImage],
	templateUrl: './art-cars-qr-list.component.html',
	styleUrls: ['./art-cars-qr-list.component.scss'],
})
export class ArtCarsQrListComponent {
	@Input() cars: any[] = [];
	@Output() uploadedCars: any = new EventEmitter<any[]>();
	selectedCars = [];
	private state = inject(ARTStorageService);
	@Input() disabledClick = false;
	carSelcetd = [];
	chooseCar(i: number) {
		this.carSelcetd = []
		if (!this.cars[i].is_documents_uploaded && !this.disabledClick)
			this.uploadedCars.emit([]);
		const arr = this.createSelectionArray(1, i);
		this.selectedCars = [...arr];
		this.carSelcetd.push(this.cars[i]['id_no']);
		this.uploadedCars.emit(this.carSelcetd);
		this.state.Setvalue('carDetails', this.cars[i]);
	}
	createSelectionArray(length: number, index: number): boolean[] {
		return Array.from({ length }, (_, i) => i === index);
	}
}
