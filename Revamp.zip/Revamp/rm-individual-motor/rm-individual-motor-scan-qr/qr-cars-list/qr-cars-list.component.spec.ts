import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QrCarsListComponent } from './qr-cars-list.component';

describe('QrCarsListComponent', () => {
  let component: QrCarsListComponent;
  let fixture: ComponentFixture<QrCarsListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QrCarsListComponent]
    });
    fixture = TestBed.createComponent(QrCarsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
