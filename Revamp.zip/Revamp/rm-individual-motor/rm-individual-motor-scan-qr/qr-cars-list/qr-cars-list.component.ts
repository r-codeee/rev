import { Component, inject, OnInit } from '@angular/core';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
	PaymentApiResponse,
	RiskItemDetails,
} from '../../models/individual-motor-payment';
import { IQuoteSummaryResponse } from '../../models/individualMotorDto';
import { ARTStorageService } from '../../../utils/services/shared/storage.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { delay, switchMap, tap } from 'rxjs';

@Component({
	selector: 'art-qr-cars-list',
	templateUrl: './qr-cars-list.component.html',
	styleUrls: ['./qr-cars-list.component.scss'],
})
export class QrCarsListComponent implements OnInit {
	apiLoading: boolean;
	isLoadingCarList = false;
	selctError = false;
	proceedToPayment = false;
	private individualMotor = inject(IndividualMotorService);
	private route = inject(ActivatedRoute);
	private router = inject(Router);
	private state = inject(ARTStorageService);
	private authService = inject(AuthService);
	cars: RiskItemDetails[];
	quoteDetails: IQuoteSummaryResponse = {
		risk_item_details: [],
	} as IQuoteSummaryResponse;
	carsToUpload = [];
	proceed() {
		if(this.carsToUpload.length > 0){
			this.selctError = false;
			this.router.navigate([
				'/revamp-individual-motor/motor-individual-qr-stepper/car-photos',
			]);
		}else{
			this.selctError = true;
		}
	}

	ngOnInit(): void {
	 	if(this.state.GetValue('referenceId')){
			this.getCarsList(this.state.GetValue('referenceId'));
		}
	}

	private getCarsList(refNum: string) {
		this.isLoadingCarList = true;
		this.individualMotor.getUserInfo().subscribe(res => {
			this.individualMotor.getCarsDetails({ reference_number: refNum })
			.subscribe(res => {
				this.isLoadingCarList = false;
				this.quoteDetails = res;
				// if
				// is_documents_uploaded
				this.getVehicleImage();
			});
		})		
	}
	getVehicleImage(): Promise<any[]> {
		return new Promise((resolve, reject) => {
			const promises: Promise<any>[] = [];

			for (let i = 0; i < this.quoteDetails.risk_item_details.length; i++) {
				const riskItem = this.quoteDetails.risk_item_details[i];
				const imgId = riskItem.addl_details?.eska_make;

				if (!imgId) {
					continue;
				}

				const imagePromise = new Promise<void>((res, rej) => {
					this.individualMotor.getVehicleImage(imgId).subscribe({
						next: (resBlob: Blob) => {
							const objectUrl = URL.createObjectURL(resBlob);
							this.quoteDetails.risk_item_details[
								i
							].addl_details.vehicleLogoUrl = objectUrl;

							res();
						},
						error: err => {
							rej(err);
						},
					});
				});

				promises.push(imagePromise);
			}

			Promise.all(promises)
				.then(() => {
					resolve(this.quoteDetails.risk_item_details);
				})
				.catch(err => {
					reject(err);
				});
		});
	}

	setCars(event: any[]) {
		this.carsToUpload = event;
	}
}
