import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmIndividualMotorScanQrStepperComponent } from './rm-individual-motor-scan-qr-stepper.component';

describe('RmIndividualMotorScanQrStepperComponent', () => {
  let component: RmIndividualMotorScanQrStepperComponent;
  let fixture: ComponentFixture<RmIndividualMotorScanQrStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmIndividualMotorScanQrStepperComponent]
    });
    fixture = TestBed.createComponent(RmIndividualMotorScanQrStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
