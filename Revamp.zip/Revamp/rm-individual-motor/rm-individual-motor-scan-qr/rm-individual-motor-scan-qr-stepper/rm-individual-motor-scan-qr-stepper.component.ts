import { Component, inject } from '@angular/core';
import { StepperService } from '../../../design-system/services/stepper.service';
@Component({
	selector: 'app-rm-individual-motor-scan-qr-stepper',
	templateUrl: './rm-individual-motor-scan-qr-stepper.component.html',
	styleUrls: ['./rm-individual-motor-scan-qr-stepper.component.scss'],
})
export class RmIndividualMotorScanQrStepperComponent {
	protected stepperService = inject(StepperService);
	ngOnInit() {
		this.stepperService.setStepsData([
			{
				titleKey: 'COMMON.CARS_LIST',
				url: '/revamp-individual-motor/motor-individual-qr-stepper/cars-list',
				isActive: true,
				isValid: false,
			},
			{
				titleKey: 'COMMON.CARS_PHOTO',
				url: '/revamp-individual-motor/motor-individual-qr-stepper/car-photos',
				isActive: false,
				isValid: false,
			},
		]);
	}
}
