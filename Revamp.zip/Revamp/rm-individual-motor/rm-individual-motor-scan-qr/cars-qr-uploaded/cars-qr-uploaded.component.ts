import { Component, inject } from '@angular/core';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RiskItemDetails } from '../../models/individual-motor-payment';
import { IQuoteSummaryResponse } from '../../models/individualMotorDto';
import { ARTStorageService } from '../../../utils/services/shared/storage.service';

@Component({
	selector: 'art-cars-qr-uploaded',
	templateUrl: './cars-qr-uploaded.component.html',
	styleUrls: ['./cars-qr-uploaded.component.scss'],
})
export class CarsQrUploadedComponent {
	apiLoading: boolean;
	isLoadingCarList = false;
	private individualMotor = inject(IndividualMotorService);
	private route = inject(ActivatedRoute);
	private router = inject(Router);
	private storage = inject(ARTStorageService);
	cars: RiskItemDetails[];
	quoteDetails: IQuoteSummaryResponse = {
		risk_item_details: [],
	} as IQuoteSummaryResponse;
	carsToUpload = [];
	private state = inject(ARTStorageService);

	proceed() {
		this.individualMotor.getUserInfo().subscribe((res)=>{
			if(res.data['otp-verified']
				){
				if(res.data.is_renewal_endorsement_journey){
					this.router.navigateByUrl('/revamp-individual-motor/renewal/payment');
				}else{
					this.router.navigateByUrl('/revamp-individual-motor/motor-individual-quotation-stepper/payment');
				}

			}else{
				if(res.data.is_renewal_endorsement_journey){
					this.storage.Setvalue('is-Renewal-Policy',true)
				}
				this.router.navigateByUrl('/revamp-individual-motor/revamp-individual-motor-otp');
			}
		})
	}

	ngOnInit(): void {
		this.route.params.subscribe(res => {
			if (res.reference_number) {
				this.getCarsList(res.reference_number);
				this.state.Setvalue('referenceId', res.reference_number);
			}
		});

		this.getCarsList(this.state.GetValue('referenceId',));
	}

	private getCarsList(refNum: string) {
		this.individualMotor
			.getCarsDetails({ reference_number: refNum })
			.subscribe(res => {
				this.quoteDetails = res;
				this.storage.mergeIntoExistValue(this.individualMotor.STORAGE_KEY,res)
				this.storage.mergeIntoExistValue(this.individualMotor.STORAGE_KEY,{
					reference_number:res.quote_details.reference_number,
					quoteResponse:{reference_number:res.quote_details.reference_number},
					phone_no:res.quote_details.phone_no
				})
				this.getVehicleImage();
			});
	}
	getVehicleImage(): Promise<any[]> {
		return new Promise((resolve, reject) => {
			const promises: Promise<any>[] = [];

			for (let i = 0; i < this.quoteDetails.risk_item_details.length; i++) {
				const riskItem = this.quoteDetails.risk_item_details[i];
				const imgId = riskItem.addl_details?.eska_make;

				if (!imgId) {
					continue;
				}

				const imagePromise = new Promise<void>((res, rej) => {
					this.individualMotor.getVehicleImage(imgId).subscribe({
						next: (resBlob: Blob) => {
							const objectUrl = URL.createObjectURL(resBlob);
							this.quoteDetails.risk_item_details[
								i
							].addl_details.vehicleLogoUrl = objectUrl;

							res();
						},
						error: err => {
							rej(err);
						},
					});
				});

				promises.push(imagePromise);
			}

			Promise.all(promises)
				.then(() => {
					resolve(this.quoteDetails.risk_item_details);
				})
				.catch(err => {
					reject(err);
				});
		});
	}

	setCars(event: any[]) {
		this.carsToUpload = [...event];
	}
}
