import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarsQrUploadedComponent } from './cars-qr-uploaded.component';

describe('CarsQrUploadedComponent', () => {
  let component: CarsQrUploadedComponent;
  let fixture: ComponentFixture<CarsQrUploadedComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CarsQrUploadedComponent]
    });
    fixture = TestBed.createComponent(CarsQrUploadedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
