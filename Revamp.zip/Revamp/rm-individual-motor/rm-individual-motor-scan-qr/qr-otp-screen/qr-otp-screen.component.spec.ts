import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QrOtpScreenComponent } from './qr-otp-screen.component';

describe('QrOtpScreenComponent', () => {
  let component: QrOtpScreenComponent;
  let fixture: ComponentFixture<QrOtpScreenComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QrOtpScreenComponent]
    });
    fixture = TestBed.createComponent(QrOtpScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
