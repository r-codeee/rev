import { Component, inject } from '@angular/core';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { delay, switchMap, tap } from 'rxjs';
@Component({
  selector: 'app-qr-otp-screen',
  templateUrl: './qr-otp-screen.component.html',
  styleUrls: ['./qr-otp-screen.component.scss']
})
export class QrOtpScreenComponent {
private individualMotor = inject(IndividualMotorService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private state = inject(ARTStorageService);
  private authService = inject(AuthService);
  isLoading = false;
  quoteDetails;
  redirectUrl: string;
  referenceId: string;
  apiLoading = false;
  firstName: string;
  sendVechilImagModalRef;
  constructor(){
	this.route.queryParams.subscribe(res => {
		if(res.source){
			localStorage.setItem('sourceHeader',res.source)
		}
		if (res.reference_number) {
			this.state.Setvalue('referenceId', res.reference_number);
			this.referenceId = res.reference_number;
			this.redirectUrl = '/revamp-individual-motor/motor-individual-qr-stepper/cars-list';
			this.loadTokens()
		}
	});
  }
  loadTokens(){
    this.isLoading = false;
    this.apiLoading = true;
	
	this.individualMotor.generateAuthCode().subscribe(res => {
		
		let authorizationCode = res.Authorization_code;
		if (authorizationCode) {
			
			this.individualMotor.generateAccessToken(authorizationCode).subscribe(res => {
				
				let token = "Bearer" + " " + res.Access_token
				localStorage.setItem("Pay_Token", token);
				sessionStorage.setItem("Pay_session_token", token);
				this.authService
				.guestLogin()
				.pipe(
					tap((res: any) => {
					localStorage.removeItem('dcp-token');
					localStorage.setItem('dcp-token', res.token);
					}),
					// Added Delay here to make sure that getCacheData is called after Pay_Token is updated in local storage
					delay(1200),
					switchMap(() => this.individualMotor.getCacheDataWithCredential()),
				)
				.subscribe(res => {
					
					this.individualMotor
					.getCarsDetails({ reference_number: this.referenceId })
					.subscribe(res => {
						this.state.mergeIntoExistValue(this.individualMotor.STORAGE_KEY,res)
						this.state.mergeIntoExistValue(this.individualMotor.STORAGE_KEY,{
							reference_number:res.quote_details.reference_number,
							phone_no:res.quote_details.phone_no
						})
						this.quoteDetails = res;
						this.isLoading = true;
						this.apiLoading = false;
					});
				});
			})
		}
	})

  }
}
