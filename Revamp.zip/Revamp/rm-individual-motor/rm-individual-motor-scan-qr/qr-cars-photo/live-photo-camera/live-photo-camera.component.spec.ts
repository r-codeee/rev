import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LivePhotoCameraComponent } from './live-photo-camera.component';

describe('LivePhotoCameraComponent', () => {
  let component: LivePhotoCameraComponent;
  let fixture: ComponentFixture<LivePhotoCameraComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [LivePhotoCameraComponent]
    });
    fixture = TestBed.createComponent(LivePhotoCameraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
