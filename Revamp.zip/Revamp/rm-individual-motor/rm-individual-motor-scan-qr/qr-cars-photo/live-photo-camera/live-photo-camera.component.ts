import { Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import Compressor  from "compressorjs";
import { IndividualMotorService } from 'src/app/rm-individual-motor/services/individual-motor.service';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

@Component({
  selector: 'app-live-photo-camera',
  templateUrl: './live-photo-camera.component.html',
  styleUrls: ['./live-photo-camera.component.scss']
})
export class LivePhotoCameraComponent implements OnInit{
  private individualMSSerive = inject(IndividualMotorService);
  private state = inject(ARTStorageService);
  private languageService = inject(RMLanguageService);
  private translateService = inject(TranslateService);
  @Input() data;
  @Input() mode;
  @Input() hasPhoto =false;
  @Output() updateStatus = new EventEmitter();
  @Output() setErrorMessage = new EventEmitter();
  selecetdData
  errorMessage 
  currentLang = this.languageService.activeLang();
  isLoading = false;
  ngOnInit(): void {
    this.selecetdData = this.data.filter(data=> data.image_type == this.mode)[0]
  }
  openCameraModal(inputFile: HTMLInputElement) {
    inputFile.click();
    const uploadFile = this.uploadFileData;
    const appObj = this;
    inputFile.onchange = (event: any) => {
      const file = event.target.files[0];
      console.log(file);
      if (
        (
          file.type == "image/png" ||
          file.type == "image/svg+xml" ||
          file.type == "image/jpg" ||
          file.type == "image/jpeg") &&
          file.size <= 20000000
      ) {
            const formData = new FormData();
            formData.append("documents", file, file.name);
            formData.append("doc_sub_type_id", this.selecetdData['doc_sub_type_id']);
            formData.append("reference_number", this.selecetdData['reference_number']);
            formData.append("image_type", this.selecetdData['image_type']);
            formData.append("risk_id", this.selecetdData['risk_id']);
            formData.append("doc_type_id", this.selecetdData['doc_type_id']);
            uploadFile.call(appObj,formData);
            inputFile.value = null;
      } else {
        // this.showFileerrors[docId] = true;
        
      }
    };
  }
  uploadFileData(formData) {
      this.isLoading = true;
      this.individualMSSerive.uploadImageComprehensive(formData).subscribe((data) => {
        this.isLoading = false;
        if(data.status){
          this.selecetdData.uploadedData = data.data;
          this.updateStatus.emit(this.selecetdData)
          this.hasPhoto = true;
        }else{
          this.hasPhoto = false;
        }
        console.log("data upload", data);
      },(err)=>{
        this.isLoading = false;
        this.setError(err);
      });
  }
	setError(err) {
		if (err.error && err.error.error) {
			this.errorMessage = err.error.error;
			if(err.error.error_msg && this.currentLang == 'ar'){
				this.errorMessage = err.error.error_msg;
			}
    } else if (err.error && err.error) {
      this.errorMessage = err.error;
			if(err.error_msg && this.currentLang == 'ar'){
				this.errorMessage = err.error_msg;
			}
    } else if (err.message) {
      this.errorMessage = err.message;
    } else {
      this.errorMessage = this.translateService.translations[this.currentLang].motorSME.oops;
    }
	}
  removeImage(){
    
  }
}
