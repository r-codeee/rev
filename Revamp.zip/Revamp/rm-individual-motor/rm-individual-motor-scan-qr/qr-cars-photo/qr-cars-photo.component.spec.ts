import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QrCarsPhotoComponent } from './qr-cars-photo.component';

describe('QrCarsPhotoComponent', () => {
  let component: QrCarsPhotoComponent;
  let fixture: ComponentFixture<QrCarsPhotoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [QrCarsPhotoComponent]
    });
    fixture = TestBed.createComponent(QrCarsPhotoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
