import { Component, inject } from '@angular/core';
import { IndividualMotorService } from '../../services/individual-motor.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';

@Component({
	selector: 'art-qr-cars-photo',
	templateUrl: './qr-cars-photo.component.html',
	styleUrls: ['./qr-cars-photo.component.scss'],
})
export class QrCarsPhotoComponent {
	private individualMSSerive = inject(IndividualMotorService);
	private state = inject(ARTStorageService);
	private router = inject(Router);
	uploadData = [];
	reference_number;
	vehcileData;
	carsToUpload = 0;
	uploaded = false;
	images;
	errorMessage;

	constructor() {
		this.vehcileData = this.state.GetValue('carDetails');
		if(this.vehcileData?.is_documents_uploaded){
			this.carsToUpload = 4;
			this.uploaded = true;
		}
		this.reference_number = this.state.GetValue('referenceId');
		if (this.state.GetValue('referenceId') && this.vehcileData) {
			this.getFiles();
		}
	}

	refreshdata(ev) {
		this.carsToUpload = 0;
		this.uploadData.forEach(data => {
			if (data.image_type === ev.image_type) {
				data.uploadedData = ev.uploadedData;
			}
			if (data.uploadedData) {
				this.carsToUpload++;
			}
		});
	}
	setError(ev){
		if(ev){
			this.errorMessage = ev
		}else{
			this.errorMessage = undefined
		}
	}

	getFiles() {
		let paylaod = { reference_number: this.reference_number };
		this.individualMSSerive.requiredFiles(paylaod).subscribe(data => {
			this.uploadData = data.required_documents.documents;
			this.uploadData = data['required_documents'][0]['documents'];
			this.uploadData = this.uploadData.map(upload => {
				return {
					doc_sub_type_id: upload['doc_sub_type_id'],
					reference_number: this.reference_number,
					image_type: upload['doc_sub_type'],
					risk_id: this.vehcileData['id'],
					doc_type_id: data['required_documents'][0]['document_type_id'],
				};
			});
		});
	}

	proceed() {
		this.router.navigateByUrl(
			'revamp-individual-motor/motor-individual-qr-stepper/cars-upload',
		);
	}
}
