import { Component, Input, OnInit } from '@angular/core';

@Component({
	selector: 'art-rm-tabby-card',
	templateUrl: './rm-tabby-card.component.html',
	styleUrls: ['./rm-tabby-card.component.scss'],
})
export class RmTabbyCard implements OnInit {
	@Input() totalPrice: number;
	constructor() {}

	ngOnInit() {}
}
