import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CyberInsuranceHomeComponent } from 'src/app/rm-cyber-insurance/cyber-insurance-home/cyber-insurance-home.component';
import { CyberInsuranceStepperComponent } from 'src/app/rm-cyber-insurance/cyber-services/cyber-insurance-stepper/cyber-insurance-stepper.component';
import { RMPremiumCalculationComponent } from 'src/app/rm-cyber-insurance/premium-calculation/rm-premium-calculation.component';
import { RmCyberInsuranceQuotationComponent } from 'src/app/rm-cyber-insurance/rm-cyber-insurance-quotation/rm-cyber-insurance-quotation.component';
import { RmCyberInsurancePaymentComponent } from '../rm-payment/rm-cyber-insurance-payment.component';
import { CyberChangePhoneNumberComponent } from './cyber-change-phone-number/cyber-change-phone-number.component';
import { CyberOtpComponent } from './cyber-otp/cyber-otp.component';
import { CyberPaymentConfirmationComponent } from './cyber-payment-confirmation/cyber-payment-confirmation.component';
import { RMCyberTrackRequestComponent } from './rm-cyber-track-request/rm-cyber-track-request.component';
import { RMCyberPaymentFailurePageComponent } from './cyber-payment-failure-page/cyber-payment-failure-page.component';

const routes: Routes = [
	{
		path: '',
		component: CyberInsuranceHomeComponent,
	},
	{
		path: 'cyber-insurance-quotation-stepper',
		component: CyberInsuranceStepperComponent,
		data: { showHeader: false, showFooter: false },
		children: [
			{
				path: '',
				component: RmCyberInsuranceQuotationComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'premium-calculation',
				component: RMPremiumCalculationComponent,
				data: { showHeader: false, showFooter: false },
			},
			{
				path: 'payment',
				component: RmCyberInsurancePaymentComponent,
				data: { showHeader: false, showFooter: false },
			},
		],
		// canActivate: [quotationGuard],
	},
	{
		path: 'change-phone-number',
		component: CyberChangePhoneNumberComponent,
	},
	{
		path: 'otp',
		component: CyberOtpComponent,
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'payment-confirmation',
		component: CyberPaymentConfirmationComponent,
	},
	{
		path: 'track-request',
		component: RMCyberTrackRequestComponent,
	},
	{
		path: 'payment-failure',
		component: RMCyberPaymentFailurePageComponent,
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class RMCyberInsuranceRoutingModule {}
