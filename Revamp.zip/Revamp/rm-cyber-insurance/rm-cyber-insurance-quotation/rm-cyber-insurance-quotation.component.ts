import { Component, inject, OnInit } from '@angular/core';
import {
	FormBuilder,
	FormControl,
	FormGroup,
	Validators,
} from '@angular/forms';
import * as moment from 'moment';
import { StepperService } from 'src/app/design-system/services/stepper.service';
import { CustomOption } from '../models/custom-option.model';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { QuotationDto } from '../models/quotation';
import { Router } from '@angular/router';
import { ArtValidators } from 'src/app/utils/helpers/art-validators.helper';
@Component({
	selector: 'art-rm-cyber-insurance-quotation',
	templateUrl: './rm-cyber-insurance-quotation.component.html',
	styleUrls: ['./rm-cyber-insurance-quotation.component.scss'],
})
export class RmCyberInsuranceQuotationComponent implements OnInit {
	covarageOptions: Array<CustomOption> = [
		new CustomOption('Individual', 'Individual'),
		new CustomOption('Family', 'Family'),
	];
	form: FormGroup;
	submitted = false;
	serverErrMsg = '';
	storedData: any = null;
	retrieveQuotePayload: any = null;

	private readonly cyberInsuranceService = inject(CyberInsuranceService);
	private readonly storage = inject(ARTStorageService);
	private readonly router = inject(Router);
	private readonly stepperService = inject(StepperService);
	yesNoOptions: Array<CustomOption> = [
		new CustomOption('CYBER_INSURANCE.CYBER_YES', true),
		new CustomOption('CYBER_INSURANCE.CYBER_NO', false),
	];

	constructor(private fb: FormBuilder) {
		this.constructForm();
	}

	ngOnInit(): void {
		this.storedData = this.storage.GetValue(
			this.cyberInsuranceService.STORAGE_KEY,
		);
		this.retrieveQuotePayload = this.storedData.retrieveQuotePayload;

		if (this.retrieveQuotePayload?.referenceId) {
			this.setFormValues();
		}

		this.setStepperState();
		this.form.valueChanges.subscribe(() => {
			this.setStepperState();
		});
	}

	setStepperState() {
		this.stepperService.setStepIsValidState({
			stepIndex: 0,
			isValidState: this.form.valid,
			isSetNextStepActiveState: true,
			isNextStepActive: this.form.valid,
		});
	}

	constructForm() {
		this.form = this.fb.group({
			coverageType: [''],
			holdCyberInsurance: [null, [Validators.required]],
			hadCyberInsuranceClaims: [null, [Validators.required]],
			policyStartDate: ['', Validators.required],
		});
	}

	selectCoverage(value: string) {
		if (value === 'Family') {
			this.form.addControl(
				'depNationalId',
				new FormControl('', [
					Validators.required,
					Validators.minLength(10),
					Validators.maxLength(10),
					Validators.pattern(/^[1|2][0-9]*$/),
				]),
			);
		} else {
			this.removeFormControl('depNationalId');
		}
	}

	holdCyberInsuranceChange(value: boolean) {
		if (value) {
			this.form.addControl(
				'expiryOfCyberInsurance',
				new FormControl('', Validators.required),
			);
		} else {
			this.removeFormControl('expiryOfCyberInsurance');
		}
	}

	onClaimsSelected(value: boolean) {
		if (value) {
			this.form.addControl(
				'howManyClaims',
				new FormControl('', [Validators.required, Validators.max(100)]),
			);
			this.form.addControl(
				'totalLoseAmount',
				new FormControl('', [Validators.required, Validators.max(999999)]),
			);
		} else {
			this.removeFormControl('howManyClaims');
			this.removeFormControl('totalLoseAmount');
		}
	}

	removeFormControl(controlName: string) {
		this.form.removeControl(controlName);
	}

	onSubmit(form) {
		this.submitted = true;
		if (form?.valid || !form?.invalid) {
			const formValue = this.form.value;
			const storedValue = this.storage.GetValue(
				this.cyberInsuranceService.STORAGE_KEY,
			);
			const payload: QuotationDto = {
				// these data will come from the previous step in the cyber Home Page
				nationalId: storedValue.nationalId,
				mobileNumber: '966' + storedValue.phoneNumber,
				dateOfBirth: moment(storedValue.dateOfBirth).format('MM-YYYY'),
				email: storedValue.email,
				// groupType: formValue.coverageType,
				groupType: 'Individual',
				depNationalId: formValue.depNationalId,
				policyStartDate: moment(formValue.policyStartDate, 'DD-MM-YYYY').format(
					'YYYY-MM-DD',
				),
			};
			if (formValue.hadCyberInsuranceClaims) {
				payload['claimInLastThree'] = formValue.howManyClaims;
				payload['lossAmount'] = formValue.totalLoseAmount;
			}

			this.submitForQuotation(payload);
		}
	}

	// CAll API To Submit Quotation
	submitForQuotation(payload: QuotationDto) {
		this.cyberInsuranceService.submitForQuotation(payload).subscribe({
			next: res => {
				this.storage.mergeIntoExistValue(
					this.cyberInsuranceService.STORAGE_KEY,
					{
						retrieveQuotePayload: res,
					},
				);
				this.storage.Setvalue('isQuotation', true);
				localStorage.setItem('alowOTPCyber', 'true');
				this.router.navigate([
					'/revamp-cyber-insurance/otp',
				]);
			},
			error: (err: any) => {
				if (err?.message) {
					this.serverErrMsg = err?.message;
				} else if (err?.error?.message) {
					this.serverErrMsg = err.error.message;
				} else if (err?.error?.Error) {
					this.serverErrMsg = err.error.Error;
				} else {
					this.serverErrMsg = '';
				}
			},
		});
	}

	setFormValues() {
		const holdCyberInsurance = this.retrieveQuotePayload?.userInfo
			?.policyEndDate
			? true
			: false;
		const claimsNumber =
			this.retrieveQuotePayload?.family?.CitizenAllDepInfoResponse
				?.totalNumberOfCurrentDependents;

		this.selectCoverage(this.retrieveQuotePayload?.userInfo?.groupType);
		this.holdCyberInsuranceChange(holdCyberInsurance);
		this.onClaimsSelected(claimsNumber > 0);

		this.form.patchValue({
			depNationalId: this.retrieveQuotePayload?.userInfo?.id,
			coverageType: this.retrieveQuotePayload?.userInfo?.groupType,
			holdCyberInsurance,
			expiryOfCyberInsurance:
				this.retrieveQuotePayload?.userInfo?.policyEndDate,
			hadCyberInsuranceClaims: claimsNumber > 0,
			howManyClaims: claimsNumber,
			totalLoseAmount: this.retrieveQuotePayload?.userInfo?.amount,
			policyStartDate: this.retrieveQuotePayload?.userInfo?.policyStartDate,
		});
	}
}
