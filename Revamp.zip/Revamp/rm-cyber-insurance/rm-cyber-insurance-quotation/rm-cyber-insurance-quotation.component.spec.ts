import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RmCyberInsuranceQuotationComponent } from './rm-cyber-insurance-quotation.component';

describe('RmCyberInsuranceQuotationComponent', () => {
  let component: RmCyberInsuranceQuotationComponent;
  let fixture: ComponentFixture<RmCyberInsuranceQuotationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RmCyberInsuranceQuotationComponent]
    });
    fixture = TestBed.createComponent(RmCyberInsuranceQuotationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
