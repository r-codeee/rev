import { Component, inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import moment from 'moment';
import { CyberInsuranceQueriesService } from 'src/app/rm-cyber-insurance/services/cyber-insurance-queries.service';
import { CyberInsuranceService } from 'src/app/rm-cyber-insurance/services/cyber-insurance.service';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { GetQuoteFormValues } from 'src/app/rm-shared-components/types/GetQuoteFormValues';
import { AuthService } from 'src/app/utils/services/auth/auth.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';

@Component({
	selector: 'art-get-cyber-insurance-quote-form',
	templateUrl: './get-cyber-insurance-quote-form.component.html',
	styleUrls: ['./get-cyber-insurance-quote-form.component.scss'],
})
export class GetCyberInsuranceQuoteFormComponent {
	private cyberInsuranceService = inject(CyberInsuranceService);
	private cyberInsuranceQueriesService = inject(CyberInsuranceQueriesService);
	private router = inject(Router);
	private storage = inject(ARTStorageService);
	private authService = inject(AuthService);
	currentLang = localStorage.getItem('selectedLang');
	customerData;
	serverErrMsg = '';
	referenceId;

	mutation = this.cyberInsuranceQueriesService.getQuoteMutation;

	constructor() {
		this.customerData = this.storage.GetValue(
			this.cyberInsuranceService.STORAGE_KEY,
		);
	}

	private routeToQuotation() {
		this.router.navigate([
			'/revamp-cyber-insurance/cyber-insurance-quotation-stepper',
		]);
	}

	private saveSessionToStorage(data: any) {
		const { STORAGE_KEY } = this.cyberInsuranceService;
		this.storage.Setvalue(STORAGE_KEY, data);
	}

	private retrieveQuote(values) {
		this.mutation.mutate(values, {
			onSuccess: retrieveQuotePayload => {
				this.referenceId = retrieveQuotePayload.referenceId;
				this.storage.Setvalue('referenceId', retrieveQuotePayload.referenceId);
				this.saveSessionToStorage({ ...values, retrieveQuotePayload, isQuotationAleadyExist: true, identifier: this.referenceId });
				this.router.navigate(['/revamp-cyber-insurance/otp']);
			},
			onError: () => {
				this.saveSessionToStorage(values);
				this.routeToQuotation();
			},
		});
	}

	onSubmit({ values }: { values: GetQuoteFormValues; form: FormGroup }) {
		if (
			localStorage.getItem('LoggedIn')
		) {
			this.customerData['nationalId'] = values.nationalId;
			this.customerData['dateOfBirth'] = values.dateOfBirth;
			this.customerData['phoneNumber'] = values.phoneNumber;
			this.retrieveQuote(this.customerData);

		} else {
			let payload = {
				nationalId: values.nationalId,
				nationality: this.currentLang === 'en' ? 'IN' : 'SA',
				privacyPolicyConsent: true,
				mobile: values.phoneNumber,
				generateQuote: true,
			};
			this.authService.guestLogin().subscribe(res => {
				localStorage.setItem('token', res.token);
				this.authService.loginUserByMobile(payload).subscribe(
					res => {
						if(res.meta.statusCode == '007') {
							let registerPayload = {
								idValue: values.nationalId,
								nationality: this.currentLang === 'en' ? 'IN' : 'SA',
								privacyPolicyConsent: true,
								mobile: values.phoneNumber,
								dateOfBirth: moment(values.dateOfBirth).format('DD-MM-YYYY'),
								email: values.email,
								generateQuote: true,
							};
							this.authService.registerUser(registerPayload).subscribe(
								res => {
									if (res.meta?.statusCode == 200) {
										localStorage.setItem('token', res.data.token);
										localStorage.setItem('registeration', 'true');
										this.customerData = {
											redirectUrl: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper',
											phoneNumber: registerPayload.mobile,
											nationalId: registerPayload.idValue,
											dateOfBirth: registerPayload.dateOfBirth,
											email: registerPayload.email,
											transactionType: TransactionTypes.CYBER_INSURANCE,
											identifier: this.referenceId
										};
										this.storage.Setvalue(
											this.cyberInsuranceService.STORAGE_KEY,
											this.customerData,
										);
										this.retrieveQuote(this.customerData);
									} else {
										this.serverErrMsg = res.error.message
									}
								},
								err => {
								},
							);
						} else {

							localStorage.setItem('token', res.data.token);
							this.customerData = {
								redirectUrl: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper',
								phoneNumber: payload.mobile,
								mobileTail: res.data.mobileTail,
								nationalId: payload.nationalId,
								dateOfBirth: values.dateOfBirth,
								email: values.email,
								transactionType: TransactionTypes.CYBER_INSURANCE,
								identifier: this.referenceId
							};
							this.storage.Setvalue(
								this.cyberInsuranceService.STORAGE_KEY,
								this.customerData,
							);
							this.retrieveQuote(this.customerData);
						}
					},
					err => {},
				);
			})

		}
	}
}
