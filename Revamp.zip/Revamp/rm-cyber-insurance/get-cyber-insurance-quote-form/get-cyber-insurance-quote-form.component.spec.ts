import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCyberInsuranceQuoteFormComponent } from './get-cyber-insurance-quote-form.component';

describe('GetCyberInsuranceQuoteFormComponent', () => {
  let component: GetCyberInsuranceQuoteFormComponent;
  let fixture: ComponentFixture<GetCyberInsuranceQuoteFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [GetCyberInsuranceQuoteFormComponent]
    });
    fixture = TestBed.createComponent(GetCyberInsuranceQuoteFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
