import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { Router } from '@angular/router';

@Component({
  selector: 'art-cyber-payment-failure-page',
  templateUrl: './cyber-payment-failure-page.component.html',
  styleUrls: ['./cyber-payment-failure-page.component.scss']
})
export class RMCyberPaymentFailurePageComponent {
  private readonly storage = inject(ARTStorageService);
  private readonly cyberInsuranceService = inject(CyberInsuranceService);
  private readonly router = inject(Router);
  customerData: any;
  ngOnInit(){
    const { STORAGE_KEY } = this.cyberInsuranceService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
    this.customerData = {
			name: this.storage.GetValue('name'),
			refNumber: this.storage.GetValue('paymentRefNo'),
			policyId: this.storage.GetValue('paymentRefNo'),
			paymentFrom: this.storage.GetValue('policyStartDate'),
			paymentTo: this.storage.GetValue('policyEndDate'),
			policyName: 'COMMON.PRODUCTS_LIST.INDIVIDUAL.CYBER.TITLE',
			productIcon: 'art-products',
			paymentAmount: this.storage.GetValue('totalPremium'),
			paymentCurrency: 'COMMON.CURRENCY'
		}
  }
  navigateToPayment() {
    this.router.navigate(['revamp-cyber-insurance/cyber-insurance-quotation-stepper/payment']);
  }

}
