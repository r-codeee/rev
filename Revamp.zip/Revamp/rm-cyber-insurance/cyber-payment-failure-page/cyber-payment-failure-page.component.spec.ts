import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RMCyberPaymentFailurePageComponent } from './cyber-payment-failure-page.component';

describe('RMCyberPaymentFailurePageComponent', () => {
  let component: RMCyberPaymentFailurePageComponent;
  let fixture: ComponentFixture<RMCyberPaymentFailurePageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RMCyberPaymentFailurePageComponent]
    });
    fixture = TestBed.createComponent(RMCyberPaymentFailurePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
