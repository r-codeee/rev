import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { DialogData } from 'src/app/claims/claim-modal/claim-modal.component';
import { LanguageService } from 'src/app/utils/services/shared/language.service';

@Component({
  selector: 'art-rm-discount-popup',
  templateUrl: './rm-discount-popup.component.html',
  styleUrls: ['./rm-discount-popup.component.scss']
})
export class RMDiscountPopupComponent {
  currentLang;
  constructor( @Inject(MAT_DIALOG_DATA) public data: DialogData,
  private dialogRef: MatDialogRef<RMDiscountPopupComponent>,
  private translateService: TranslateService,
    private langService: LanguageService){
    this.currentLang = this.langService.currentLang;
    this.translateService.use(this.currentLang ? this.currentLang : "en");
  }

  upgradeNow(){
    this.dialogRef.close(false)
  }
    skip(){
      this.dialogRef.close(true)
    }
}
