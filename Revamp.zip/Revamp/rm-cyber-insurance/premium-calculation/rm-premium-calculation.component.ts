import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StepperService } from 'src/app/design-system/services/stepper.service';
import { BenifitPopupComponent } from '../benifit-popup/benifit-popup.component';
import { ComparisonPopupComponent } from '../comparison-popup/comparison-popup.component';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { TranslateService } from '@ngx-translate/core';
import { MatDialog } from '@angular/material/dialog';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { TappyPopupComponent } from 'src/app/rm-payment/components/tappy-popup/tappy-popup.component';
import { PaymentServiceService } from 'src/app/rm-payment/service/payment-service.service';

@Component({
	selector: 'art-rm-premium-calculation',
	templateUrl: './rm-premium-calculation.component.html',
	styleUrls: ['./rm-premium-calculation.component.scss'],
})
export class RMPremiumCalculationComponent implements OnInit {
	/** currentLang */
	public currentLang;
	/** Rates */
	public Rates;
	/** ratesdata */
	public ratesdata;
	/** Fullname */
	public Fullname: any;
	/** RatesSelected */
	public RatesSelected;
	/** currentDate */
	currentDate = new Date();
	/** endDate */
	public endDate;
	/** stepsPending */
	public stepsPending = 1;
	/** CIinsurancePayload */
	public CIinsurancePayload;
	/** retrieveQuote */
	retrieveQuote = false;
	/** flowName */
	public flowName;
	/** mobileNumber */
	public mobileNumber: string = '';
	/** slectedPlan */
	public slectedPlan = 'Advanced';

	private readonly stepperService = inject(StepperService);
	private paymentService = inject(PaymentServiceService);

	constructor(
		private langService: LanguageService,
		private cyberInsuranceService: CyberInsuranceService,
		private translateService: TranslateService,
		private dialog: MatDialog,
		private state: ARTStorageService,
		private router: Router,
	) {
		this.currentLang = this.langService.currentLang;
		this.translateService.use(this.currentLang ? this.currentLang : 'en');
		this.endDate = this.currentDate.setFullYear(
			this.currentDate.getFullYear() + 1,
		);
		this.CIinsurancePayload = this.state.GetValue('CIinsurancePayload');
		this.flowName = this.state.GetValue('flow');
		// this.ratesdata = JSON.parse(localStorage.getItem('csiRates'));
		this.ratesdata = this.state.GetValue(
			this.cyberInsuranceService.STORAGE_KEY,
		).retrieveQuotePayload;

		if (this.ratesdata && this.ratesdata.userInfo.groupType == 'Family') {
			this.stepsPending = 2;
		} else {
			this.stepsPending = 1;
		}
	}
	ngOnInit(): void {
		this.getCards();
		if (this.ratesdata) {
			if (this.ratesdata.referenceId) {
				this.Fullname = this.cyberInsuranceService.getFullName(
					this.ratesdata,
					this.currentLang,
				);
				this.state.Setvalue('Fullname', this.Fullname);
				if (this.retrieveQuote) {
					let selectedata = Object.values(this.ratesdata.rateDetails).filter(
						rate => rate['selected'] == true,
					)[0];
					if (selectedata) {
						this.slectedPlan = selectedata['PlanType'];
					} else {
						this.slectedPlan = 'Advanced';
					}
					this.RatesSelected = this.getRatesInfo(this.slectedPlan);
				} else {
					this.RatesSelected = this.getRatesInfo(this.slectedPlan);
				}
			} else {
				this.router.navigateByUrl(
					`/${this.currentLang}/revamp-cyber-insurance`,
				);
			}
		}
		this.stepperService.setStepIsValidState({
			stepIndex: 1,
			isValidState: false,
		});
	}

	onshowBenefits(rate) {
		this.dialog.open(BenifitPopupComponent, {
			data: {
				plan: rate,
				rateInfo: this.ratesdata.rates
					? this.ratesdata.rates
					: this.ratesdata.rateDetails,
			},
			autoFocus: false,
      		maxHeight: '90vh'
		});
	}

	getCards() {
		this.cyberInsuranceService.getCardRates(this.currentLang).subscribe(res => {
			this.Rates = res.data;
		});
	}

	insurNow() {
		this.cyberInsuranceService
			.selectRate(
				this.ratesdata.referenceId,
				this.RatesSelected['Id'],
				this.state.GetValue(this.cyberInsuranceService.STORAGE_KEY).nationalId,
			)
			.subscribe({
				next: res => {
					this.onProceed();
				},
			});

		this.stepperService.setStepIsValidState({
			stepIndex: 1,
			isValidState: true,
		});
	}

	slectPlan(plan) {
		this.slectedPlan = plan;
		this.RatesSelected = this.getRatesInfo(plan);
	}

	getRatesInfo(planName) {
		if (this.ratesdata.rateDetails) {
			return Object.values(this.ratesdata.rateDetails).filter(
				rate => rate['PlanType'] == planName,
			)[0];
		} else {
			return this.ratesdata.rates.filter(rate => rate.PlanType == planName)[0];
		}
	}

	openComparisonMadal() {
		const modalRef = this.dialog.open(ComparisonPopupComponent, {
			data: {
				selectedPlan: this.slectedPlan,
				rates: this.Rates,
			},
			panelClass: 'comparision-table',
			// maxWidth: '934px',
			width: '90%',

		});
		modalRef.afterClosed().subscribe(plan => {
			if (plan !== undefined) {
				this.slectedPlan = plan;
				this.RatesSelected = this.getRatesInfo(plan);
			}
		});
	}

	onRadioChange(value: any) {
		this.slectedPlan = value;
	}
	openTabbyMadal() {
		this.state.Setvalue('transactionType', TransactionTypes.CYBER_INSURANCE);

		this.dialog.open(TappyPopupComponent);
	}

	onProceed() {
		this.state.Setvalue('isQuotation', false);
		this.router.navigate([
			'/revamp-cyber-insurance/otp',
		]);
		// this.router.navigate([
		// 	'/revamp-cyber-insurance/cyber-insurance-quotation-stepper/payment',
		// ]);
	}
}
