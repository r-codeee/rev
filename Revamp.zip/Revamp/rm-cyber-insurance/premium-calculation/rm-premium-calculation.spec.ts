import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RMPremiumCalculationComponent } from './rm-premium-calculation.component';

describe('RMPremiumCalculationComponent', () => {
  let component: RMPremiumCalculationComponent;
  let fixture: ComponentFixture<RMPremiumCalculationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RMPremiumCalculationComponent]
    });
    fixture = TestBed.createComponent(RMPremiumCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
