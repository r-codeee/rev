import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';

export const quotationGuard: CanActivateFn = (route, state) => {
	const storage: ARTStorageService = inject(ARTStorageService);
	const cyberInsuranceService: CyberInsuranceService = inject(
		CyberInsuranceService,
	);
	const router: Router = inject(Router);
	// Check if nationalID is found
	const cyberFormValue = storage.GetValue(cyberInsuranceService.STORAGE_KEY);
	if (cyberFormValue?.nationalId) {
		return true;
	}

	// Redirect to Cyber Insurance Home page
	router.navigate(['/revamp-cyber-insurance']);

	return false;
};
