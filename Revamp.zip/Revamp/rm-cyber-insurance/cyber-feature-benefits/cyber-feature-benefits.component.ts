import { Component } from '@angular/core';
import { FeatureBenefitType } from 'src/app/design-system/types/FeatureBenefitType';

@Component({
	selector: 'art-cyber-feature-benefits',
	templateUrl: './cyber-feature-benefits.component.html',
	styleUrls: ['./cyber-feature-benefits.component.scss'],
})
export class CyberFeatureBenefitsComponent {
	// tslint:disable-next-line:max-line-length
	benefits: Array<FeatureBenefitType> = [
		{
			icon: 'art-policy-money',
			title: 'CYBER_INSURANCE.BENIFITS_CARD1_TITLE',
			description: 'CYBER_INSURANCE.BENIFITS_CARD1_DESC',
		},
		{
			icon: 'art-policy-information',
			title: 'CYBER_INSURANCE.BENIFITS_CARD2_TITLE',
			description: 'CYBER_INSURANCE.BENIFITS_CARD2_DESC',
		},
		{
			icon: 'art-policy-bullying',
			title: 'CYBER_INSURANCE.BENIFITS_CARD3_TITLE',
			description: 'CYBER_INSURANCE.BENIFITS_CARD3_DESC',
		}
	];
}
