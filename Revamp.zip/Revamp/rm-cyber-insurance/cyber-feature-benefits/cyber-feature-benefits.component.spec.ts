import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberFeatureBenefitsComponent } from './cyber-feature-benefits.component';

describe('CyberFeatureBenefitsComponent', () => {
  let component: CyberFeatureBenefitsComponent;
  let fixture: ComponentFixture<CyberFeatureBenefitsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CyberFeatureBenefitsComponent]
    });
    fixture = TestBed.createComponent(CyberFeatureBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
