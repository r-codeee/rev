export class QuotationDto {
    nationalId: string;
    mobileNumber: string;
    dateOfBirth: string;
    email: string;
    groupType: string;
    depNationalId: string;
    policyStartDate: string;

    constructor(quotation: any ) {
        this.nationalId = quotation.nationalId;
        this.mobileNumber = quotation.mobileNumber;
        this.dateOfBirth =  quotation.dateOfBirth;
        this.email = quotation.email;
        this.groupType = quotation.groupType;
        this.depNationalId = quotation.depNationalId;
        this.policyStartDate =  quotation.policyStartDate;
    }
}