export class CustomOption {
    label: string = '';
    value: string | number | boolean = null;
    Icon?: string ;

    constructor(label: string, value: string | number | boolean,icon?: string) {
        this.label = label;
        this.value = value;
        this.Icon = icon;
    }
}