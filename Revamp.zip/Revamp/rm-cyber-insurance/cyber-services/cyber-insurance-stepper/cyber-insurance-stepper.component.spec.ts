import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberInsuranceStepperComponent } from './cyber-insurance-stepper.component';

describe('CyberInsuranceStepperComponent', () => {
  let component: CyberInsuranceStepperComponent;
  let fixture: ComponentFixture<CyberInsuranceStepperComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CyberInsuranceStepperComponent]
    });
    fixture = TestBed.createComponent(CyberInsuranceStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
