import { Component, inject, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { StepperService } from 'src/app/design-system/services/stepper.service';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../../services/cyber-insurance.service';

@Component({
	selector: 'art-cyber-insurance-stepper',
	templateUrl: './cyber-insurance-stepper.component.html',
	styleUrls: ['./cyber-insurance-stepper.component.scss'],
})
export class CyberInsuranceStepperComponent implements OnInit {
	protected stepperService = inject(StepperService);
	protected translateService = inject(TranslateService);
	private router = inject(Router);
	steps = [
		{
			titleKey: 'COMMON.QUOTATION',
			url: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper',
			isActive: true,
			isValid: false,
		},
		{
			titleKey: 'COMMON.PREMIUM_CALCULATION',
			url: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/premium-calculation',
			isActive: false,
			isValid: false,
		},
		{
			titleKey: 'COMMON.REVIEW_AND_PAYMENT',
			url: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/payment',
			isActive: false,
			isValid: false,
		},
	];
	routerSubscription: Subscription;
	isQuotationAleadyExist: Boolean;
	private storage = inject(ARTStorageService);
	private cyberInsuranceService = inject(CyberInsuranceService)
	
 
    updateSteps(currentUrl: string) {
        let thisActive = false;
        this.steps.forEach((step, index) => {
            if (step.url === currentUrl) {
                thisActive = true;
                step.isActive = true;
            } else {
                step.isActive = thisActive ? false : true;
            }
        });
 
        this.stepperService.setStepsData(this.steps = this.isQuotationAleadyExist ? this.steps = [
			{
				titleKey: 'COMMON.PREMIUM_CALCULATION',
				url: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/premium-calculation',
				isActive: true,
				isValid: false,
			},
			{
				titleKey: 'COMMON.REVIEW_AND_PAYMENT',
				url: '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/payment',
				isActive: false,
				isValid: false,
			},
		] : this.steps );
    }

	ngOnInit() {
		this.isQuotationAleadyExist = this.storage.GetValue(
			this.cyberInsuranceService.STORAGE_KEY).isQuotationAleadyExist;
		this.updateSteps(this.router.url);
 
        // Subscribe to route changes
        this.routerSubscription = this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                this.updateSteps(event.urlAfterRedirects || event.url);
            }
        });
		
	}
}
