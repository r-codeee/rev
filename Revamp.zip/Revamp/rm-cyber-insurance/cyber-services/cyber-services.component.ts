import { Component } from '@angular/core';
import { FeatureBenefitType } from 'src/app/design-system/types/FeatureBenefitType';

@Component({
	selector: 'art-cyber-services',
	templateUrl: './cyber-services.component.html',
	styleUrls: ['./cyber-services.component.scss'],
})
export class CyberServicesComponent {
	// TODO: add the cyber insurance services here and pass it to component art-product-services in the template
	productServices: Array<FeatureBenefitType> = [
		{
			icon: 'art-policy-cancellation',
			title: 'CYBER_INSURANCE.SERVICES.SERVICE1.TITLE',
			description: 'CYBER_INSURANCE.SERVICES.SERVICE1.DESC',
		},
		{
			icon: 'art-policy-claims',
			title: 'CYBER_INSURANCE.SERVICES.SERVICE2.TITLE',
			description: 'CYBER_INSURANCE.SERVICES.SERVICE2.DESC',
		},
		{
			icon: 'home-document-icon',
			title: 'CYBER_INSURANCE.SERVICES.SERVICE3.TITLE',
			description: 'CYBER_INSURANCE.SERVICES.SERVICE3.DESC',
		},
		{
			icon: 'art-policy-support',
			title: 'CYBER_INSURANCE.SERVICES.SERVICE4.TITLE',
			description: 'CYBER_INSURANCE.SERVICES.SERVICE4.DESC',
		}
	];
}
