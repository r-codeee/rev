import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberServicesComponent } from './cyber-services.component';

describe('CyberServicesComponent', () => {
  let component: CyberServicesComponent;
  let fixture: ComponentFixture<CyberServicesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CyberServicesComponent]
    });
    fixture = TestBed.createComponent(CyberServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
