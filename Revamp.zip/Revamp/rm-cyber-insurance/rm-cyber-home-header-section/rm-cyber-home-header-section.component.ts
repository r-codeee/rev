import { Component, Input } from '@angular/core';

@Component({
  selector: 'art-rm-cyber-home-header-section',
  templateUrl: './rm-cyber-home-header-section.component.html',
  styleUrls: ['./rm-cyber-home-header-section.component.scss']
})
export class RmCyberHomeHeaderSectionComponent {
  @Input() title : string ;
  @Input() subTitle : string ;
}
