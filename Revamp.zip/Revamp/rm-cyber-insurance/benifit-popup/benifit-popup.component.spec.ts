import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BenifitPopupComponent } from './benifit-popup.component';

describe('BenifitPopupComponent', () => {
  let component: BenifitPopupComponent;
  let fixture: ComponentFixture<BenifitPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BenifitPopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BenifitPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
