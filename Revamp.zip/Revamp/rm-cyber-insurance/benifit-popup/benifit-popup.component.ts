import { Component, EventEmitter, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
	selector: 'art-rm-app-benifit-popup',
	templateUrl: './benifit-popup.component.html',
	styleUrls: ['./benifit-popup.component.scss'],
})
export class BenifitPopupComponent implements OnInit {
	currentLang: any;
	submit = new EventEmitter();
	objectKeys = Object.keys;
	isShowLess: boolean = false;
	panelOpenState: boolean = false;
	rateInfo: [];
	selctedRate;

	constructor(
		@Inject(MAT_DIALOG_DATA) public data: any,
		private dialogRef: MatDialogRef<BenifitPopupComponent>,
	) {
		this.currentLang = localStorage.getItem('selectedLang');
		this.rateInfo = data['rateInfo'];
	}

	ngOnInit(): void {
		this.selctedRate = this.getRatesInfo(this.data.plan.PlanName);
	}
	getRatesInfo(planName) {
		if (this.rateInfo) {
			return Object.values(this.rateInfo).filter(
				rate => rate['PlanType'] == planName,
			)[0];
		} else {
			return this.rateInfo.filter(rate => rate['PlanType'] == planName)[0];
		}
	}
	closeSidenav() {
		this.dialogRef.close(false);
	}
	showMore() {
		let benefitsListElm = document.getElementById('benefitsList');
		if (this.data.plan.ProductTitle.length > 5) {
			benefitsListElm.classList.add('expand');
			this.isShowLess = true;
		}
	}
	showLess() {
		let benefitsListElm = document.getElementById('benefitsList');
		benefitsListElm.classList.remove('expand');
		this.isShowLess = false;
	}

	close() {
		this.dialogRef.close(false);
	}
}
