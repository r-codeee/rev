import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { Router } from '@angular/router';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';

@Component({
	selector: 'art-cyber-otp',
	templateUrl: './cyber-otp.component.html',
	styleUrls: ['./cyber-otp.component.scss'],
})
export class CyberOtpComponent {
	readonly storage = inject(ARTStorageService);
	private readonly cyberInsuranceService = inject(CyberInsuranceService);
	readonly router = inject(Router);
	private readonly languageService = inject(RMLanguageService);
	currentLang = this.languageService.activeLang();
	customerData;
	private readonly PHONE_NUMBER_CHANGE_PAGE = '/revamp-cyber-insurance/change-phone-number';
    FIRST_REDIRECT_URL = '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/premium-calculation';
	SECOND_REDIRECT_URL = '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/payment';
	isQuotation = this.storage.GetValue('isQuotation');
	REDIRECT_URL: string;
	// private readonly REDIRECT_URL = '/revamp-cyber-insurance/cyber-insurance-quotation-stepper/premium-calculation';
	componentConfig  = {
		isFooter: true,
		isChangePhoneEnabled: true,
		isRedirectEnabled: true,
		isResendEnabled: false,
		isCounterEnabled: true,
		isSendEnabled: false,
		headerTitleCustomClasses: '',
		errorMessage: '',
		timerDisplay: '00:00',
	};

	constructor() {
		this.REDIRECT_URL = this.isQuotation == true ? this.FIRST_REDIRECT_URL : this.SECOND_REDIRECT_URL;
		if (localStorage.getItem('alowOTPCyber') == 'false') {
			this.router.navigateByUrl('/' + this.currentLang);
		}
		this.customerData = this.storage.GetValue(
			this.cyberInsuranceService.STORAGE_KEY,
		);
		this.customerData['redirectUrl'] = this.REDIRECT_URL;
		this.storage.Setvalue(this.cyberInsuranceService.STORAGE_KEY, this.customerData);
	}

	navigateToChangeMobileNumber() {
		this.router.navigateByUrl(this.PHONE_NUMBER_CHANGE_PAGE);
	}
}
