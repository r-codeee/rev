import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { RmChangePhoneNumberComponentConfigI } from 'src/app/rm-change-phone-number/rm-change-phone-number.component';
import { Router } from '@angular/router';

@Component({
	selector: 'art-cyber-change-phone-number',
	templateUrl: './cyber-change-phone-number.component.html',
	styleUrls: ['./cyber-change-phone-number.component.scss'],
})
export class CyberChangePhoneNumberComponent {
	componentConfig: RmChangePhoneNumberComponentConfigI = {
		isFooter: false,
		isRedirectEnabled: true,
		hasCancel: true,
		inputHasLabel: true,
		headerTitleCustomClasses: '',
		headerTitle: 'COMMON.PHONE.TITLE',
		headerDesc: 'COMMON.PHONE.DESCRIPTION',
		saveBtnText: 'COMMON.PHONE.SUBMIT',
	};
	private readonly storage = inject(ARTStorageService);
	private readonly cyberInsuranceService = inject(CyberInsuranceService);
  private readonly router = inject(Router);
	readonly customerData: any;

	constructor() {
		const { STORAGE_KEY } = this.cyberInsuranceService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
	}

  phoneNumberChanged(event) {
		this.customerData['phoneNumber'] = event;
		this.storage.Setvalue(
			this.cyberInsuranceService.STORAGE_KEY,
			this.customerData,
		);
	}

  goBack(){
    this.router.navigateByUrl('/revamp-cyber-insurance/otp')
  }
}
