import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberInsuranceHomeComponent } from './cyber-insurance-home.component';

describe('CyberInsuranceHomeComponent', () => {
  let component: CyberInsuranceHomeComponent;
  let fixture: ComponentFixture<CyberInsuranceHomeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CyberInsuranceHomeComponent]
    });
    fixture = TestBed.createComponent(CyberInsuranceHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
