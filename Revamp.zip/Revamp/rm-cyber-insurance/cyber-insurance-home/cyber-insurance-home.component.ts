import { Component } from '@angular/core';

@Component({
	selector: 'art-cyber-insurance-home',
	templateUrl: './cyber-insurance-home.component.html',
	styleUrls: ['./cyber-insurance-home.component.scss'],
})
export class CyberInsuranceHomeComponent {}
