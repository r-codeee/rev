import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';
import { TRackRequestType } from 'src/app/design-system/types/TrackRequestType';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { TransactionTypes } from 'src/app/rm-payment/enums/transactionTypes';
import { PaymentServiceService } from 'src/app/rm-payment/service/payment-service.service';
import { DatePipe } from '@angular/common';

@Component({
	selector: 'art-rm-cyber-track-request',
	templateUrl: './rm-cyber-track-request.component.html',
	styleUrls: ['./rm-cyber-track-request.component.scss'],
})
export class RMCyberTrackRequestComponent {
	private readonly storage = inject(ARTStorageService);
	private readonly cyberInsuranceService = inject(CyberInsuranceService);
	private readonly router = inject(Router);
	private paymentService = inject(PaymentServiceService);
	private datePipe = inject(DatePipe);
	customerData : any;
	trackRequestData: TRackRequestType = {
		refferenceNumber: '',
		firstStausDesc: '',
		headerLabel: 'TRACK_REQUEST.POLICY_ISSUING_TRACKING',
		headerSubtitle: 'TRACK_REQUEST.YOU_CAN_TRACK',
		refferenceNumberLabel: 'TRACK_REQUEST.REFERENEC_NUMBER',
		headerIcon: 'art-light-copy',
		startStausIcon: 'art-green-success',
		firstStausTitle: 'TRACK_REQUEST.PAYMENT_SUCCESSFULLY_DONE',
		firstStausLabel: 'TRACK_REQUEST.DONE',
		endStausIcon: 'art-file-sync',
		secondStausTitle: 'TRACK_REQUEST.POLICY_ISSUED',
		secondStausLabel: 'TRACK_REQUEST.IN_PROGRESS',
		secondStausDate: 'TRACK_REQUEST.WITHIN_30_60_MINUTES',
		secondStausColor: 'warning',
		endStausIconCustomClass:'background-tint-orange p-2a rounded-circle overflow-visible w-h-46',
		btnText: 'TRACK_REQUEST.BACK_TO_HOME',
	};
	serverErrMsg: string;
	trackStatus: any;

	ngOnInit() {
		const { STORAGE_KEY } = this.cyberInsuranceService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
		this.trackRequestData['refferenceNumber']  = this.storage.GetValue('paymentRefNo');
		this.trackRequestData['firstStausDate']= this.datePipe.transform(this.storage.GetValue('createdAt'), 'dd-MM-yyyy', 'es-ES');
		this.getUpdatedStatus()
	}

	backToHome() {
		this.router.navigate(['/']);
	}
	  getUpdatedStatus() {
		this.paymentService.getStatusUpdate(TransactionTypes.CYBER_INSURANCE, encodeURIComponent(this.storage.GetValue('paymentRefNo'))).subscribe(res => {
		  if (res.meta && res.meta.status === 1) {
			this.trackStatus = res.data.policyScheduleStatus;
			if(res.data.policyScheduleStatus == 1){
				this.trackRequestData.secondStausTitle = 'TRACK_REQUEST.POLICY_ISSUED';
				this.trackRequestData.secondStausLabel = 'TRACK_REQUEST.DONE';
				this.trackRequestData.secondStausColor= 'color-success';
				this.trackRequestData.endStausIcon = 'art-file-sync-done';
			}
		  }
		}, err => {
		  if (err.meta && err.meta.status === 0) {
			this.serverErrMsg = err && err.error.message;
		  } 
		  else if(err.error.meta && err.error.meta.status === 0){
		  this.serverErrMsg = err.error.error.message;
		  }
		  else {
		  this.serverErrMsg = err.message;
		  }
		})
	  }
}
