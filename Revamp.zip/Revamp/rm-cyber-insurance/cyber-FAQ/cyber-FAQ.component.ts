import { Component } from '@angular/core';
import { FAQType } from 'src/app/design-system/types/FAQType';

@Component({
	selector: 'art-cyber-FAQ',
	templateUrl: './cyber-FAQ.component.html',
	styleUrls: ['./cyber-FAQ.component.scss'],
})
export class CyberFAQComponent {
	FAQs: Array<FAQType> = [
		{
		  id: 1,
		  question: 'CYBER_INSURANCE.FAQS.FAQ_1.QUESTION',
		  answer: 'CYBER_INSURANCE.FAQS.FAQ_1.ANSWER',
		},
		{
		  id: 2,
		  question: 'CYBER_INSURANCE.FAQS.FAQ_2.QUESTION',
		  answer: 'CYBER_INSURANCE.FAQS.FAQ_2.ANSWER',
		},
	  ]
}
