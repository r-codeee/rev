import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberFAQComponent } from 'src/app/rm-cyber-insurance/cyber-FAQ/cyber-FAQ.component';

describe('CyberFAQComponent', () => {
	let component: CyberFAQComponent;
	let fixture: ComponentFixture<CyberFAQComponent>;

	beforeEach(() => {
		TestBed.configureTestingModule({
			declarations: [CyberFAQComponent],
		});
		fixture = TestBed.createComponent(CyberFAQComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
