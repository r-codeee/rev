import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { Router } from '@angular/router';

@Component({
	selector: 'art-cyber-payment-confirmation',
	templateUrl: './cyber-payment-confirmation.component.html',
	styleUrls: ['./cyber-payment-confirmation.component.scss'],
})
export class CyberPaymentConfirmationComponent {
	private readonly storage = inject(ARTStorageService);
	private readonly cyberInsuranceService = inject(CyberInsuranceService);
	private router = inject(Router);
	readonly customerData: any;
	paymentParams: any;

	constructor() {
		const { STORAGE_KEY } = this.cyberInsuranceService;
		this.customerData = this.storage.GetValue(STORAGE_KEY);
		this.paymentParams = this.storage.GetValue('paymentParams');
		this.customerData = {
			name: this.storage.GetValue('Fullname'),
			refNumber: this.storage.GetValue('paymentRefNo'),
			policyId: this.storage.GetValue('paymentRefNo'),
			paymentFrom: this.storage.GetValue('policyStartDate'),
			paymentTo: this.storage.GetValue('policyEndDate'),
			policyName: 'COMMON.PRODUCTS_LIST.INDIVIDUAL.CYBER.TITLE',
			productIcon: 'art-products',
			plan: this.storage.GetValue('productType'),
			paymentAmount: this.storage.GetValue('totalPremium'),
			paymentCurrency: 'COMMON.CURRENCY'
		}
	}

	navigateToTrackRequest() {
		this.router.navigateByUrl(
			'revamp-cyber-insurance/track-request',
		);
	}

}
