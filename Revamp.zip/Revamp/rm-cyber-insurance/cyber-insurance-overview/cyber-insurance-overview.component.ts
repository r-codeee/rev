import { Component } from '@angular/core';

@Component({
	selector: 'art-cyber-insurance-overview',
	templateUrl: './cyber-insurance-overview.component.html',
	styleUrls: ['./cyber-insurance-overview.component.scss'],
})
export class CyberInsuranceOverviewComponent {
	onClickCheckProductDetails() {
		document
			.getElementById('feature-benefits')
			?.scrollIntoView({ behavior: 'smooth' });
	}
}
