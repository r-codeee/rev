import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CyberInsuranceOverviewComponent } from './cyber-insurance-overview.component';

describe('CyberInsuranceOverviewComponent', () => {
  let component: CyberInsuranceOverviewComponent;
  let fixture: ComponentFixture<CyberInsuranceOverviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CyberInsuranceOverviewComponent]
    });
    fixture = TestBed.createComponent(CyberInsuranceOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
