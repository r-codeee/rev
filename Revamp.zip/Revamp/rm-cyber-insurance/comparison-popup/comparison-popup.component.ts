import { Component, EventEmitter, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateService } from '@ngx-translate/core';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { ComparisonTableHelperService, TableColumn, TableRow } from 'src/app/services/comparison-table-helper.service';

@Component({
	selector: 'art-app-comparison-popup',
	templateUrl: './comparison-popup.component.html',
	styleUrls: ['./comparison-popup.component.scss'],
})
export class ComparisonPopupComponent implements OnInit {
	currentLang: any;
	@Input() title: string;
	@Input() mode: number;
	submit = new EventEmitter();
	benifitsData;
	selectedValue: any;
	tableData: TableColumn[];
	rowLabels: TableRow[];
	
	constructor(
		@Inject(MAT_DIALOG_DATA) public data: any,
		private dialogRef: MatDialogRef<ComparisonPopupComponent>,
		private translateService: TranslateService,
		private comparisonTableHelper: ComparisonTableHelperService
	) {
		this.currentLang = localStorage.getItem('selectedLang');
		this.translateService.use(this.currentLang);
		this.selectedValue = data.selectedPlan;
	}

	ngOnInit(): void {
		this.tableData = this.mapDataToTableRows(this.data.rates);
		this.rowLabels.push({ name: 'componentData', isCustomComponent: true });
		this.tableData.forEach((col: any) => {
			col.benefits['componentData'] = {
				value: '',
				componentData:
					col.Name === this.selectedValue 
						? null
						: {
								component: ArtButtonComponent,
								fallbackTriggers: [{ name: 'onClick', data: col.Name }],
								config: {
									text:
										this.translateService.instant('CYBER_INSURANCE.UPGRADE'),
									type: 'button',
									size: 'lg',
								},
							},
			};
		});
	}

	mapDataToTableRows(rates) {
		this.rowLabels = [];

		return rates.map((item, index) => {
			return {
				...item,
				Name: item.PlanName,
				subtitle: this.translateService.instant(
					'HI.COVERED_UP_TO_THE_OVERALL_ANNUAL',
				),
				startIcon: this.comparisonTableHelper.getPlanIcon(
					(item.PlanName as string).toLowerCase(),
				),
				benefits: item.ProductTitle?.reduce((acc, {Name, Value }) => {
					acc[Name] = { value: Value };
					this.rowLabels.push({name: Name});

					return acc;
				}, {}),
			};
		});
	}

	onClose() {
		this.dialogRef.close(this.data.selectedPlan);
	}
	onUpgrade(event) {
		this.selectedValue = event.data;
		this.dialogRef.close(this.selectedValue);
	}
}