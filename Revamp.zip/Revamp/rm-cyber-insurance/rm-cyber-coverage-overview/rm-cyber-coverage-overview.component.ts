import { Component, inject, Input } from '@angular/core';
import { CyberInsuranceService } from '../services/cyber-insurance.service';
import { LanguageService } from 'src/app/utils/services/shared/language.service';
import { ComparisonTableHelperService, TableColumn, TableRow } from 'src/app/services/comparison-table-helper.service';

@Component({
	selector: 'art-rm-cyber-coverage-overview',
	templateUrl: './rm-cyber-coverage-overview.component.html',
	styleUrls: ['./rm-cyber-coverage-overview.component.scss'],
})
export class RmCyberCoverageOverviewComponent {
	data: any;
	showAll: boolean = false;
	public currentLang;
	private cyberInsuranceService: CyberInsuranceService = inject(
		CyberInsuranceService,
	);
	public langService: LanguageService = inject(LanguageService);
	private comparisonTableHelper:ComparisonTableHelperService = inject(ComparisonTableHelperService);
	tableData: TableColumn[];
	rowLabels: TableRow[];

	ngOnInit(): void {
		this.currentLang = this.langService.currentLang;
		this.loadloadBenefitsTableData();
	}

	loadloadBenefitsTableData() {
		this.cyberInsuranceService.getCardRates(this.currentLang).subscribe({
			next: res => {
				this.data = res.data;
				this.tableData = this.mapDataToTableRows(res.data); 
			},
		});
	}

	mapDataToTableRows(res) {  
		const labels = new Set<string>();  
	
		return  res.map((el)=> {
	
		  return {
			...el,
			Name: el.PlanName,
			startIcon: this.comparisonTableHelper.getPlanIcon(el.PlanName),
			benefits: el.ProductTitle?.reduce((acc, { Name, Value, Type }) => {
			  const lowerCaseName = (Name || '').toLowerCase();
			  acc[lowerCaseName] = { value: Value, type: Type };
			  labels.add(lowerCaseName)
			  this.rowLabels = Array.from(labels).map(name => ({ name }));

			  return acc;
			}, {}),
		  }
		});
	}
}
