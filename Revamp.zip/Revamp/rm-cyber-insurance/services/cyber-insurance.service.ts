import { Injectable } from '@angular/core';
import {
	Observable,
	catchError,
	retry,
	throwError,
	map,
	firstValueFrom,
} from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { isCyberAPI } from 'src/app/utils/helpers/token-interceptor.service';
import { CMSService } from 'src/app/utils/cms.service';

@Injectable({
	providedIn: 'root',
})
export class CyberInsuranceService {
	public currentLang;
	baseUrl = environment.apigeeUrl;
	STORAGE_KEY = 'cyberInsuranceSession';
	constructor(
		private http: HttpClient,
		private cmsService: CMSService,
	) {}

	retrieveQuotation(Nid: any): Promise<any> {
		return firstValueFrom(
			this.http.get<any>(
				this.baseUrl + `/cyberonweb-dcp/api/dcp-v2/cyber-policy/${Nid}`,
				{ context: isCyberAPI() },
			),
		);
	}

	public getFullName(ratesdata, currentLang) {
		const userInfo = ratesdata.userInfo;

		const getNamePart = (name: string) => (name && name !== 'NULL' ? name : '');

		const englishNames = [
			getNamePart(userInfo.englishFirstName),
			getNamePart(userInfo.englishSecondName),
			getNamePart(userInfo.englishThirdName),
			getNamePart(userInfo.englishLastName),
		];

		const arabicNames = [
			getNamePart(userInfo.firstName),
			getNamePart(userInfo.fatherName),
			getNamePart(userInfo.grandFatherName),
			getNamePart(userInfo.familyName),
		];

		const Fullname =
			currentLang === 'en'
				? englishNames.join(' ').trim()
				: arabicNames.join(' ').trim();

		const trimmedFullname = Fullname.replace(/\s/g, '');

		return trimmedFullname === '' && currentLang !== 'en'
			? englishNames.join(' ').trim()
			: Fullname;
	}

	public getCardRates(lang?) {
		let cmsLan = this.cmsService.langEN;

		if (
			this.currentLang === 'ar' ||
			lang === 'ar' ||
			localStorage.getItem('selectedLang') == 'ar'
		) {
			cmsLan = this.cmsService.langAR;
		}
		if (lang && lang === 'ar') {
			cmsLan = this.cmsService.langAR;
		}
		let result = {
			data: [],
		};
		return this.cmsService
			.query({
				options: {
					query: `
			  query{
				premiumTiles(locale: "${cmsLan}", filters:{ProductName:{containsi:"CyberInsurance"}}){
				  data{
					attributes{
					  Tile{
						Name
						Value
					  }
					  ProductName
					  PlanName
					}
				  }
				}
			  }`,
				},
			})
			.pipe(catchError(this.handleError))
			.pipe(
				map((val: any) => {
					val = val.premiumTiles.data;
					let pdetails;
					(val as any[]).forEach(doc => {
						pdetails = {};
						pdetails.PlanName = doc.attributes.PlanName;
						pdetails.ProductName = doc.attributes.ProductName;
						pdetails.ProductTitle = doc.attributes.Tile;
						result.data.push(pdetails);
						//tdoc.Title = doc.Title;
					});
					return result;
				}),
			);
	}

	public selectRate(referenceId: any, palnID: any, nid): Observable<any> {
		return this.http
			.put<any>(
				this.baseUrl +
					`/cyberonweb-dcp/api/dcp-v2/cyber-policy/select-rate?referenceId=${referenceId}=&selectedRateId=${palnID}`,
				{},
			)
			.pipe(catchError(this.handleError));
	}

	handleError(error: HttpErrorResponse) {
		let errorMessage = '';
		if (error.error instanceof ErrorEvent) {
			errorMessage = error.error.message;
		} else {
			errorMessage = error.error;
		}
		console.error('An error occurred:', error);
		return throwError(errorMessage);
	}

	submitForQuotation(payLoad: any): Observable<any> {
		return this.http
			.post<any>(
				this.baseUrl + `/cyberonweb-dcp/api/dcp-v2/cyber-policy/add-quote`,
				payLoad,
				{ context: isCyberAPI() },
			)
			.pipe(retry(1), catchError(this.handleError));
	}
}
