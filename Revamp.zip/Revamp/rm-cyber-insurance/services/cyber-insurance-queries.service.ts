import { inject, Injectable } from '@angular/core';
import { injectMutation } from '@tanstack/angular-query-experimental';
import { CyberInsuranceService } from 'src/app/rm-cyber-insurance/services/cyber-insurance.service';
import { GetQuoteFormValues } from 'src/app/rm-shared-components/types/GetQuoteFormValues';

@Injectable({
	providedIn: 'root',
})
export class CyberInsuranceQueriesService {
	private cyberInsuranceService = inject(CyberInsuranceService);

	queryKeys = {
		getCyberInsuranceQuote: ['getCyberInsuranceQuote'],
	};

	getQuoteMutation = injectMutation(() => ({
		mutationKey: this.queryKeys.getCyberInsuranceQuote,
		mutationFn: (values: GetQuoteFormValues) => {
			return this.cyberInsuranceService.retrieveQuotation(values.nationalId);
		},
		retry: 0,
	}));
}
