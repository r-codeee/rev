import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { AnimationComponent } from 'src/app/design-system/animation/animation.component';
import { ArtButtonComponent } from 'src/app/design-system/art-button/art-button.component';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { LoadingHideDirective } from 'src/app/design-system/directives/loading-hide.directive';
import { DoYouNeedHelpComponent } from 'src/app/design-system/do-you-need-help/do-you-need-help.component';
import { DynamicStepperComponent } from 'src/app/design-system/dynamic-stepper/dynamic-stepper.component';
import { FeatureBenefitsComponent } from 'src/app/design-system/feature-benefits/feature-benefits.component';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { InsuranceOverviewComponent } from 'src/app/design-system/insurance-overview/insurance-overview.component';
import { ManageYourPolicyOnlineSectionComponent } from 'src/app/design-system/manage-your-policy-online-section/manage-your-policy-online-section.component';
import { PhoneBasicInputComponent } from 'src/app/design-system/phone-basic-input/phone-basic-input.component';
import { ProductFAQComponent } from 'src/app/design-system/product-FAQ/product-FAQ.component';
import { ProductInsuranceSideMenuComponent } from 'src/app/design-system/product-insurance-side-menu/product-insurance-side-menu.component';
import { ProductServicesComponent } from 'src/app/design-system/product-services/product-services.component';
import { StepperFooterComponent } from 'src/app/design-system/stepper-footer/stepper-footer.component';
import { StepperComponent } from 'src/app/design-system/stepper/stepper.component';
import { SwitchBusinessIndividualComponent } from 'src/app/design-system/switch-business-individual/switch-business-individual.component';
import { GetCyberInsuranceQuoteFormComponent } from 'src/app/rm-cyber-insurance/get-cyber-insurance-quote-form/get-cyber-insurance-quote-form.component';
import { GetQuoteFormComponent } from 'src/app/rm-shared-components/get-quote-form/get-quote-form.component';
import { ProductHomeComponent } from 'src/app/rm-shared-components/product-home/product-home.component';
import { ArtFormsModule } from 'src/art-forms/art-forms.module';

import { RMCyberInsuranceRoutingModule } from './rm-cyber-insurance-routing.module';
import { CyberInsuranceHomeComponent } from './cyber-insurance-home/cyber-insurance-home.component';
import { CyberInsuranceOverviewComponent } from './cyber-insurance-overview/cyber-insurance-overview.component';
import { CyberFeatureBenefitsComponent } from './cyber-feature-benefits/cyber-feature-benefits.component';
import { CyberServicesComponent } from './cyber-services/cyber-services.component';
import { CyberFAQComponent } from './cyber-FAQ/cyber-FAQ.component';
import { RmCyberInsuranceQuotationComponent } from './rm-cyber-insurance-quotation/rm-cyber-insurance-quotation.component';
import { RmCustomOptionsComponent } from '../design-system/rm-custom-options/rm-custom-options.component';
import { RmSimpleInputComponent } from '../design-system/rm-simple-input/rm-simple-input.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RmDateInputComponent } from '../design-system/rm-date-input/rm-date-input.component';
import { ComparisonPopupComponent } from './comparison-popup/comparison-popup.component';
import { RMPremiumCalculationComponent } from './premium-calculation/rm-premium-calculation.component';
import { ArtComparisonCard } from '../design-system/rm-comparison-card/rm-comparison-card';
import { ArtDeviderCard } from '../design-system/rm-devider-card/rm-devider-card';
import { ArtProductSummaryCard } from '../design-system/rm-product-summary-card/rm-product-summary-card';
import { ArtProductPlanCard } from '../design-system/rm-product-plan-card/rm-product-plan-card';
import { BenifitPopupComponent } from './benifit-popup/benifit-popup.component';
import { RMDiscountPopupComponent } from './discount-popup/rm-discount-popup.component';
import { CyberInsuranceStepperComponent } from './cyber-services/cyber-insurance-stepper/cyber-insurance-stepper.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { SvgIconComponent } from '../design-system/svg-icon/svg-icon.component';
import { CyberOtpComponent } from './cyber-otp/cyber-otp.component';
import { CyberChangePhoneNumberComponent } from './cyber-change-phone-number/cyber-change-phone-number.component';
import { CyberPaymentConfirmationComponent } from './cyber-payment-confirmation/cyber-payment-confirmation.component';
import { RmPaymentConfirmationPageComponent } from '../rm-payment-confirmation-page/rm-payment-confirmation-page.component';
import { RMChangePhoneNumberComponent } from '../rm-change-phone-number/rm-change-phone-number.component';
import { RMOtpModule } from '../rm-otp/rm-otp.module';
import { RMBenifitCardComponent } from '../design-system/rm-product-benifit-card/rm-product-benifit-card.component';
import { RMCyberTrackRequestComponent } from './rm-cyber-track-request/rm-cyber-track-request.component';
import { ArtTrackRequest } from '../design-system/rm-track-request/rm-track-request.component';
import { RmPaymentFailurePageComponent } from '../rm-payment-failure-page/rm-payment-failure-page.component';
import { RMCyberPaymentFailurePageComponent } from './cyber-payment-failure-page/cyber-payment-failure-page.component';
import { RmCyberCoverageOverviewComponent } from './rm-cyber-coverage-overview/rm-cyber-coverage-overview.component';
import { RmCyberHomeHeaderSectionComponent } from './rm-cyber-home-header-section/rm-cyber-home-header-section.component';
import { OtpComponent } from '../design-system/otp/otp.component';
import { RmHeaderDesktopCommonComponent } from '../design-system/rm-header-desktop-common/rm-header-desktop-common.component';
import { RmComparisonTableComponent } from '../design-system/rm-comparison-table/rm-comparison-table';
import { RmHeaderComponent } from '../rm-payment/components/rm-header/rm-header.component';

declare const VERSION: string;

@NgModule({
	declarations: [
		CyberInsuranceHomeComponent,
		CyberInsuranceOverviewComponent,
		CyberFeatureBenefitsComponent,
		CyberServicesComponent,
		CyberFAQComponent,
		RmCyberInsuranceQuotationComponent,
		GetCyberInsuranceQuoteFormComponent,
		RMPremiumCalculationComponent,
		BenifitPopupComponent,
		ComparisonPopupComponent,
		CyberInsuranceStepperComponent,
		RMDiscountPopupComponent,
		CyberOtpComponent,
		CyberChangePhoneNumberComponent,
		CyberPaymentConfirmationComponent,
		RMCyberTrackRequestComponent,
		RMCyberPaymentFailurePageComponent,
		RmCyberCoverageOverviewComponent,
		RmCyberHomeHeaderSectionComponent,
	],
	imports: [
		ArtFormsModule,
		CommonModule,
		RMCyberInsuranceRoutingModule,
		SwitchBusinessIndividualComponent,
		TranslateModule,
		InsuranceOverviewComponent,
		ManageYourPolicyOnlineSectionComponent,
		ProductInsuranceSideMenuComponent,
		FeatureBenefitsComponent,
		ProductServicesComponent,
		ProductFAQComponent,
		DoYouNeedHelpComponent,
		FormsModule,
		ReactiveFormsModule,
		RmCustomOptionsComponent,
		RmSimpleInputComponent,
		ArtButtonComponent,
		RmDateInputComponent,
		ArtProductPlanCard,
		ArtProductSummaryCard,
		ArtComparisonCard,
		ArtDeviderCard,
		MatExpansionModule,
		SvgIconComponent,
		BasicInputComponent,
		PhoneBasicInputComponent,
		IconComponent,
		GetQuoteFormComponent,
		AnimationComponent,
		LoadingHideDirective,
		StepperComponent,
		StepperFooterComponent,
		RmPaymentConfirmationPageComponent,
		RMChangePhoneNumberComponent,
		RMOtpModule,
		RMBenifitCardComponent,
		ArtTrackRequest,
		RmPaymentFailurePageComponent,
		OtpComponent,
		RmHeaderDesktopCommonComponent,
		ProductHomeComponent,
		RmComparisonTableComponent,
		RmHeaderComponent
	],
})
export class RMCyberInsuranceModule {}
