import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { ArtButtonComponent } from '../design-system/art-button/art-button.component';
import { ClipboardModule } from 'ngx-clipboard';
import { Clipboard } from '@angular/cdk/clipboard';
import { AlertComponent } from '../design-system/alert/alert.component';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { SvgIconComponent } from '../design-system/svg-icon/svg-icon.component';

@Component({
	selector: 'art-rm-confirmation-details',
	standalone: true,
	imports: [
		CommonModule,
		TranslateModule,
		SvgIconComponent,
		IconComponent,
		ArtButtonComponent,
		ClipboardModule,
		AlertComponent,
	],
	templateUrl: './rm-confirmation-details.component.html',
	styleUrls: ['./rm-confirmation-details.component.scss'],
})
export class RmConfirmationDetailsComponent {
	@Input() customerData: any;
	@Input() type: 'success' | 'failed';
	private readonly clipboard = inject(Clipboard);
	readonly contentLeftTitles: string[] = [
		'CONFIRMATION.COMPREHENSIVE_COVERAGE',
		'CONFIRMATION.POLICY_COVERAGE_DURATION',
		'CONFIRMATION.REFERENEC_NUMBER',
	];
	isCopied = false;
	@Output() onClickTrackRequest = new EventEmitter();

	navigateToTrackRequest() {
		this.onClickTrackRequest.emit();
	}

	copyToClipBoard() {
		this.clipboard.copy(this.customerData.refNumber);
		this.isCopied = true;
		setTimeout(() => (this.isCopied = false), 1000);
	}

	get isSuccess() {
		return this.type === 'success';
	}
}
