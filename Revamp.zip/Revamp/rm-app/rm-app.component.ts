import {
	Component,
	HostListener,
	OnInit,
	Renderer2,
	ViewChild,
} from '@angular/core';
import { RMLanguageService } from 'src/app/RM-services/r-m-language.service';
import { RmThemeService } from 'src/app/themes-service/service/RM-theme.service';
import { AuthService } from '../utils/services/auth/auth.service';
import { MatDrawer } from '@angular/material/sidenav';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import AOS from 'aos';

@Component({
	selector: 'art-rm-app',
	templateUrl: './rm-app.component.html',
	styleUrls: ['./rm-app.component.scss'],
})
export class RMAppComponent implements OnInit {
	@ViewChild('drawerSearch') drawerSearchElem: MatDrawer;
	@ViewChild('drawer') drawer: MatDrawer;
	menuOpen = false;
	searchOpen = false;
	showHeader = true;
	showFooter = true;
	mySpace = false;
	navbarFixed = false;
	constructor(
		private langService: RMLanguageService,
		private themeService: RmThemeService,
		private authService: AuthService,
		private render: Renderer2,
		private router: Router,
	) {}

	@HostListener('window:scroll', ['$event']) onScroll() {
		if (window.scrollY >= 5) {
			this.navbarFixed = true;
		} else {
			this.navbarFixed = false;
		}
	}

	ngOnInit() {
		AOS.init();

		this.themeService.setThemeOnStart();
		this.langService.switchLayoutDirectionBasedOnLang();
		this.authService.searchBoxClicked.subscribe(searchBoxClicked => {
			if (searchBoxClicked) {
				this.drawerSearchElem.open();
			}
		});
		this.langService.searchNavOpen.subscribe(obj => {
			this.searchOpen = obj;
		});
		this.langService.NavOpen.subscribe(obj => {
			this.menuOpen = obj;
		});

		this.router.events
			.pipe(filter(event => event instanceof NavigationEnd))
			.subscribe(() => {
				this.updateRouteData();
			});
		// Initial update if already on a route
		this.updateRouteData();
	}

	mobileMenuClose() {
		this.render.removeClass(document.body, 'stop-scrolling');
		this.menuOpen = false;
		this.drawer.close();
	}

	drawerSearchClose() {
		if (!this.searchOpen) {
			this.render.removeClass(document.body, 'stop-scrolling');
		}
		this.searchOpen = false;
		this.drawerSearchElem.close();
	}

	private updateRouteData() {
		let route = this.router.routerState.root;

		while (route.firstChild) {
			route = route.firstChild;
		}
		if (route) {
			// Traverse the child routes to get the final active route
			route.data.subscribe(data => {
				this.showHeader = data['showHeader'] ?? true;
				this.showFooter = data['showFooter'] ?? true;
				this.mySpace = data['mySpace'] ? true : false;
			});
		}
	}
}
