import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RMAppComponent } from './rm-app.component';

describe('RMAppComponent', () => {
  let component: RMAppComponent;
  let fixture: ComponentFixture<RMAppComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RMAppComponent]
    });
    fixture = TestBed.createComponent(RMAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
