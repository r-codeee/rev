import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RmConfirmationDetailsComponent } from '../rm-confirmation-details/rm-confirmation-details.component';
import { SvgIconComponent } from '../design-system/svg-icon/svg-icon.component';
import { IconComponent } from '../design-system/icon/icon.component';
import { StepperHeaderMobileComponent } from '../design-system/stepper-header-mobile/stepper-header-mobile.component';
import { RmHeaderDesktopCommonComponent } from '../design-system/rm-header-desktop-common/rm-header-desktop-common.component';
@Component({
	selector: 'art-rm-confirmation-page[customerData]',
	standalone: true,
	imports: [
		CommonModule,
		TranslateModule,
		SvgIconComponent,
		RmConfirmationDetailsComponent,
		IconComponent,
		StepperHeaderMobileComponent,
		RmHeaderDesktopCommonComponent
	],
	templateUrl: './rm-confirmation-page.component.html',
	styleUrls: ['./rm-confirmation-page.component.scss'],
})
export class RmConfirmationPageComponent {
	@Input() customerData: any;
	@Output() onTrackRequestNavigation = new EventEmitter();
	readonly linkCards: link[] = [
		{
			label: 'CONFIRMATION.GOOGLE_PLAY',
			icon: 'googlePlay',  
			link: 'https://play.google.com/store/search?q=%D8%A7%D9%84%D8%B1%D8%A7%D8%AC%D8%AD%D9%8A%20%D8%AA%D9%83%D8%A7%D9%81%D9%84&c=apps',
		  },
		  {
			label: 'CONFIRMATION.APPLE_STORE',
			icon: 'apple',  
			link: 'https://apps.apple.com/app/al-rajhi-takaful-new/id1511689440',
		  },
		  {
			label: 'CONFIRMATION.APPGALLERY',
			icon: 'appGallery',  
			link: 'https://appgallery.huawei.com/search/Al%20Rajhi%20Takaful',
		  }
	];
	rateExperience(type: 'normal' | 'bad' | 'good' | 'excellent') {
		// @TODO : Rate the experience api call
	}

	navigateToTrackRequest() {
		this.onTrackRequestNavigation.emit();
	}
}

export interface link {
	label: string;
	icon: string;
	link: string;
}
