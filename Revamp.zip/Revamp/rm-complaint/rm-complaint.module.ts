import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RmComplaintRoutingModule } from './rm-complaint-routing.module';
import { FormSectionContainerComponent } from '../rm-shared-components/questions-section-container/form-section-container.component';
import { BasicInputComponent } from '../design-system/basic-input/basic-input.component';
import { CustomDropdownComponent } from '../design-system/custom-dropdown/custom-dropdown.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { PhoneBasicInputComponent } from '../design-system/phone-basic-input/phone-basic-input.component';
import { RmComplaintFormComponent } from './rm-complaint-form/rm-complaint-form.component';
import { BasicTextareaComponent } from '../design-system/basic-textarea/basic-textarea.component';
import { ArtUploadButtonComponent } from '../design-system/art-upload-button/art-upload-button.component';
import { ArtButtonComponent } from '../design-system/art-button/art-button.component';
import { RmTrackComplaintComponent } from './rm-track-complaint/rm-track-complaint.component';
import { RMAccountFormContainerComponent } from '../design-system/rm-account-form-container/rm-account-form-container.component';
import { ArtTrackRequest } from '../design-system/rm-track-request/rm-track-request.component';
import { RmComplaintTrackStatusComponent } from './rm-complaint-track-status/rm-complaint-track-status.component';
import { RmPaymentConfirmationPageComponent } from '../rm-payment-confirmation-page/rm-payment-confirmation-page.component';
import { RmComplaintConfirmationComponent } from './rm-complaint-confirmation/rm-complaint-confirmation.component';
import { AlertComponent } from '../design-system/alert/alert.component';

@NgModule({
	declarations: [RmComplaintFormComponent, RmTrackComplaintComponent, RmComplaintConfirmationComponent, RmComplaintTrackStatusComponent],
	imports: [
		CommonModule,
		RmComplaintRoutingModule,
		ReactiveFormsModule,
		TranslateModule,
		FormSectionContainerComponent,
		BasicInputComponent,
		PhoneBasicInputComponent,
		CustomDropdownComponent,
		BasicTextareaComponent,
		ArtUploadButtonComponent,
		ArtButtonComponent,
		RMAccountFormContainerComponent,
		ArtTrackRequest,
		RmPaymentConfirmationPageComponent,
		AlertComponent
	],
})
export class RmComplaintsModule {}
