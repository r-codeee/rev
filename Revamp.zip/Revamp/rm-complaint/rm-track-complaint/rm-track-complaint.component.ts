import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import * as yup from 'yup';
import { RmComplaintService } from '../service/rm-complaint.service';
import { OnlineServiceRequestService } from 'src/app/rm-online-services/service/online-service-request.service';

@Component({
	selector: 'rm-track-complaint',
	templateUrl: './rm-track-complaint.component.html',
	styleUrls: ['./rm-track-complaint.component.scss'],
})
export class RmTrackComplaintComponent extends BaseFormComponent<{
	requestNumber: string;
}> {
	values = {
		requestNumber: '',
	};
	isLoading = false;
	serverErrMsg = '';
	currentLang = localStorage.getItem('selectedLang');
	routingParams = 'complaint';
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private router: Router,
		private rmComplaintService: RmComplaintService,
		private onlineServiceRequestService: OnlineServiceRequestService,
	) {
		super(formBuilderService);
	}

	createValidationSchema() {
		return yup.object().shape({
			requestNumber: yup.string().required(),
		});
	}

	validationSchema = this.createValidationSchema();

	onSubmit(values: { requestNumber: string }) {
		let requestNumber = values.requestNumber;
		this.isLoading = true;
		sessionStorage.setItem('srNo', requestNumber);
		this.onlineServiceRequestService.setSelectedServicerequest = {
			srNo: requestNumber,
		};
		if (requestNumber.substring(0, 3) === 'LI-') {
			this.onlineServiceRequestService.getDLPLifeRequestStatus().subscribe(
				data => {
					console.log(data);
					this.isLoading = false;
					const isLifeServiceTrackRequest = true;
					this.router.navigateByUrl(
						`${this.currentLang}/service-requests/track/${this.routingParams}`,
						{ state: { isLifeServiceTrackRequest } },
					);
				},
				err => {
					this.isLoading = false;
					this.serverErrMsg = err.error.message;
					this.form.controls['requestNumber'].setErrors({ incorrect: true });
				},
			);
		} else {
			this.onlineServiceRequestService.getRequestStatus().subscribe(
				data => {
					console.log(data);
					this.isLoading = false;
					this.router.navigateByUrl(`/revamp-complaint/complaint-status`);
					// this.onCloseModal();
				},
				err => {
					this.isLoading = false;
					this.serverErrMsg = err.error.message;
					this.form.controls['requestNumber'].setErrors({ incorrect: true });
				},
			);
		}
	}
}
