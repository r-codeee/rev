import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { Router } from '@angular/router';
import { Component, inject } from '@angular/core';

@Component({
	selector: 'app-rm-complaint-confirmation',
	templateUrl: './rm-complaint-confirmation.component.html',
	styleUrls: ['./rm-complaint-confirmation.component.scss'],
})
export class RmComplaintConfirmationComponent {
	private readonly storage = inject(ARTStorageService);
	private readonly router = inject(Router);
	customerData: any;

	ngOnInit(): void {
		this.customerData = {
			complaintNumber: this.storage.GetValue("requestNumber"),
			policyName:"COMMON.COMPLAINT_SERVICE"	
		};
	}

	navigateToTrackRequest() {
		this.router.navigateByUrl('/revamp-complaint/complaint-status');
	}
}
