import { Injectable } from '@angular/core';
import * as yup from 'yup';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';

@Injectable({
	providedIn: 'root',
})
export class RmComplaintValidationSchemaService {
	constructor(private validationRulesService: ArtValidationRulesService) {}

	createComplaintRequestFormValidationSchema() {
		return yup.object().shape({
			serviceRequestNo: this.validationRulesService.onlyRequired(),
			description: this.validationRulesService.onlyRequired(),
			name: this.validationRulesService.onlyRequired(),
			nationalId: this.validationRulesService.nationalIdValidationRule(),
			mobile: this.validationRulesService.phoneNumberValidationRule(),
			email: this.validationRulesService.emailIdValidationRule(),
			city: this.validationRulesService.onlyRequired()
		});
	}
}
