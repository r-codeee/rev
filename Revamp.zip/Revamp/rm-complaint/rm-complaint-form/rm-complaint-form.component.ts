import { Component, inject } from '@angular/core';
import { GetComplaintRequestFormSubmitValues } from 'src/app/rm-shared-components/types/GetComplaintRequestValues';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { RmComplaintValidationSchemaService } from '../service/rm-complaint-validation-schema.service';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { CommonService } from 'src/app/rm-shared-components/services/common.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { IconComponent } from 'src/app/design-system/icon/icon.component';
import { OnlineServiceRequestService } from 'src/app/rm-online-services/service/online-service-request.service';
import * as moment from 'moment';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
@Component({
	selector: 'rm-complaint-form',
	templateUrl: './rm-complaint-form.component.html',
	styleUrls: ['./rm-complaint-form.component.scss'],
})
export class RmComplaintFormComponent extends BaseFormComponent<GetComplaintRequestFormSubmitValues> {
	values: GetComplaintRequestFormSubmitValues = {
		serviceRequestNo: '',
		description: '',
		name: '',
		nationalId: '',
		mobile: '',
		email: '',
		city: '',
		file1: {},
		file2: {},
		file3: {}
	};
	rmComplainValidationSchemaService = inject(
		RmComplaintValidationSchemaService,
	);
	uploadSuffixComponent = IconComponent;
	uploadSuffixComponentInputs = {
		icon: 'fa fa-arrow-up-from-bracket',
		size: 'xs',
    customClasses: 'color-main-dark-gray',
	};
	documentFiles = [
		{
			id: 0,
			file: null,
			doc_name: 'Upload Supporting Document',
			doc_arabic_name: 'تحميل الملفات',
			doc_info: '',
			url: '',
			docSize: 0,
			status: 0,
			filename: null,
			path: null,
		},
		{
			id: 1,
			file: null,
			doc_name: 'Upload Supporting Document',
			doc_arabic_name: 'تحميل الملفات',
			doc_info: '',
			url: '',
			docSize: 0,
			status: 0,
			filename: null,
			path: null,
		},

		{
			id: 2,
			file: null,
			doc_name: 'Upload Supporting Document',
			doc_arabic_name: 'تحميل الملفات',
			doc_info: '',
			url: '',
			docSize: 0,
			status: 0,
			filename: null,
			path: null,
		},
	];
	serverErrMsg = '';
	filesProgress = 0;
	showFileerrors: any[] = [false, false, false, false, false];
	showFileerror: boolean = false;
	validationSchema =
		this.rmComplainValidationSchemaService.createComplaintRequestFormValidationSchema();
	currentLang = localStorage.getItem('selectedLang');
	ksaCitiesList = [];
	isMobile = false;
	isLoading = false;
	constructor(
		protected formBuilderService: ArtFormBuilderService,
		private commonService: CommonService,
		private activatedRoute: ActivatedRoute,
		private router: Router,
		private onlineServiceRequestService: OnlineServiceRequestService,
		private storage: ARTStorageService,
	) {
		super(formBuilderService);
		this.getKSACities();
		this.activatedRoute.queryParams.subscribe((params: Params) => {
			if (params.source == 'mobile') {
				this.isMobile = true;
				localStorage.setItem('ViewSource', 'mobile');
				window['nsWebViewInterface'].on('userdataEventCompaints', response => {
					const res = JSON.parse(response);
				});
			}
		});
	}

	getKSACities() {
		this.commonService.getKSACities(1).subscribe(res => {
			this.ksaCitiesList = res;
		});
	}
	getLabel(index: number): string {
		return `COMMON.FILE${++index}`;
	}
	onFileUpload(event) {
		const file = event.event.target.files[0];
		const allowedExt = {
			'image/png': 'png',
			'image/jpeg': 'jpg',
			'application/pdf': 'pdf',
		};
		if (
			(file.type == 'image/png' ||
				file.type == 'image/jpeg' ||
				file.type == 'application/pdf') &&
			file.size <= 20000000
		) {
			const fileExt = allowedExt[file.type];

			this.filesProgress += 20;
			this.documentFiles.forEach(doc => {
				if (doc.id == event.docId) {
					let myfile = event.event.target.files[0];
					let filename =
						(myfile + new Date().getTime()).replace(/[^\w\s]/gi, '') +
						'.' +
						fileExt;
					const formData = new FormData();
					formData.append('file', myfile, filename);
					console.log(formData);
					this.onlineServiceRequestService.uploadFile(formData).subscribe(
						res => {
							console.log(res);
							doc.url = res.path;
							doc.filename = myfile.name;
							doc.path = res.path;
							this.showFileerror = false;
							doc.status = 1;
							doc.file = file;
							this.showFileerrors[event.docId] = false;
						},
						err => {
							console.log(err);
							this.showFileerror = true;
						},
					);
				}
			});
		} else {
			this.showFileerror = true;
			this.showFileerrors[event.docId] = true;
		}
	}

	onSelectCity(event) {
		let selectValue =
			this.currentLang === 'en' ? event.cityNameEn : event.cityNameAr;
		this.form.patchValue({ city: selectValue });
	}
	onRemoveFile(event) {
		this.filesProgress -= 20;
		this.documentFiles.forEach(doc => {
			if (doc.id == event) {
				doc.status = 0;
				doc.file = null;
				doc.url = '';
				doc.filename = '';
			}
		});
	}
	trackRequest() {
		this.router.navigateByUrl('/revamp-complaint/track-complaint');
	}
	onSubmit(values: GetComplaintRequestFormSubmitValues): void {
		let requiredAttachments = [];
		if (this.documentFiles[0].filename) {
			requiredAttachments.push({
				'Document 1': this.documentFiles[0].filename,
				path: this.documentFiles[0].path,
			});
		}
		if (this.documentFiles[1].filename) {
			requiredAttachments.push({
				'Document 2': this.documentFiles[1].filename,
				path: this.documentFiles[1].path,
			});
		}
		if (this.documentFiles[2].filename) {
			requiredAttachments.push({
				'Document 3': this.documentFiles[2].filename,
				path: this.documentFiles[2].path,
			});
		}
		const payload = {
			serviceRequestNo: values.serviceRequestNo,
			serviceType: 'Complaint',
			date: moment(new Date()).format('DD/MM/YYYY'),
			nationalId: values.nationalId,
			name: values.name,
			email: values.email,
			city: values.city,
			mobile: values.mobile,
			lang: this.currentLang === 'en' ? 'E' : 'A',
			description: values.description,
			requiredAttachments: requiredAttachments,
		};
		this.createComplaint(payload);
	}

	createComplaint(payload) {
		this.isLoading = true;
		this.onlineServiceRequestService.submitComplaints(payload).subscribe(
			(res: any) => {
				this.isLoading = false;
				this.serverErrMsg = '';
				this.storage.Setvalue('requestNumber', res.data);
				this.router.navigateByUrl('/revamp-complaint/complaint-confirmation');
			},
			err => {
				this.isLoading = false;
				if (err.error) {
					this.serverErrMsg = err.error.errorMessage;
				} else {
					this.serverErrMsg = err.message;
				}
				window.scroll({
					top: 0,
					left: 0,
					behavior: 'smooth',
				});
			},
		);
	}
}
