import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RmComplaintFormComponent } from './rm-complaint-form/rm-complaint-form.component';
import { RmTrackComplaintComponent } from './rm-track-complaint/rm-track-complaint.component';
import { RmComplaintTrackStatusComponent } from './rm-complaint-track-status/rm-complaint-track-status.component';
import { RmComplaintConfirmationComponent } from './rm-complaint-confirmation/rm-complaint-confirmation.component';
import { RmOnlineServiceTrackRequestStatusComponent } from '../rm-online-services/rm-online-service-track-request-status/rm-online-service-track-request-status.component';

const routes: Routes = [
	{
		path: '',
		component: RmComplaintFormComponent,
	},
	{
		path: 'track-complaint',
		component: RmTrackComplaintComponent,
		data: { showHeader:true, showFooter: true },
	},
	{
		path: 'complaint-confirmation',
		component: RmComplaintConfirmationComponent,
		data: { showHeader: false, showFooter: false },

	},
	{
		path: 'complaint-status',
		component: RmOnlineServiceTrackRequestStatusComponent,
		data: { showHeader: false, showFooter: false },
	},
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule],
})
export class RmComplaintRoutingModule {}
