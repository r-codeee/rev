import { Component, inject } from '@angular/core';
import { ARTStorageService } from 'src/app/utils/services/shared/storage.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { TRackRequestType } from 'src/app/design-system/types/TrackRequestType';
import { OnlineServiceRequestService } from 'src/app/rm-online-services/service/online-service-request.service';

export class TrackResponse {
	COMPLAINT_NUMBER: string;
	COMPLAINT_STATUS: string;
	COMPLAINT_TYPE: string;
	CUSTOMER_ID: string;
	CustomerName: string;
	PolicyNumber: string;
	REQUEST_TIME: string;
	ClaimNumber: string;
}

@Component({
	selector: 'art-rm-complaint-track-status',
	templateUrl: './rm-complaint-track-status.component.html',
	styleUrls: ['./rm-complaint-track-status.component.scss'],
})
export class RmComplaintTrackStatusComponent {
	private readonly storage = inject(ARTStorageService);
	submissionStatus: any;
	currentLang: string;
	trackRequestRespone: TrackResponse;
	serverErrMsg: string = '';
	showError: boolean = false;
	showMessage: boolean = false;
	params;
	heading;
	requestOrComplaintNumber;
	requestOrComplaintDetails;
	requestOrComplaintSubmitted;
	requestOrComplaintDate;
	isMobile: boolean = false;
	isLifeServiceTrackRequest: boolean = false;
	trackRequestData: TRackRequestType = {
		refferenceNumber: '123333333',
		firstStausDesc: '',
		headerLabel: 'COMMON.TRACK_REQUEST',
		headerSubtitle: 'TRACK_REQUEST.YOU_CAN_TRACK_SERVICE_REQUEST_STATUS',
		refferenceNumberLabel: 'TRACK_REQUEST.REFERENEC_NUMBER',
		headerIcon: 'art-light-copy',
		startStausIcon: 'art-green-success',
		firstStausTitle: 'TRACK_REQUEST.POLICY_ISSUING_TRACKING',
		firstStausLabel: 'TRACK_REQUEST.DONE',
		endStausIcon: 'art-file-sync',
		secondStausTitle: 'TRACK_REQUEST.SENDING_POLICY_SCHEDULE',
		secondStausLabel: 'TRACK_REQUEST.WILL_BE_SENT_BY_EMAIL',
		secondStausDate: 'TRACK_REQUEST.WITHIN_2_HOURS',
		btnText: 'TRACK_REQUEST.BACK_TO_HOME',
	};

	constructor(
		private translateService: TranslateService,
		private onlineServiceRequestService: OnlineServiceRequestService,
		private router: Router,
		private activatedRoute: ActivatedRoute,
	) {
		this.currentLang = localStorage.getItem('selectedLang');
		this.translateService.use(this.currentLang);
		this.isLifeServiceTrackRequest =
			this.router?.getCurrentNavigation()?.extras?.state?.isLifeServiceTrackRequest;
	}

	ngOnInit(): void {
		this.params = this.activatedRoute.snapshot.params['name'];
		if (this.params === 'complaint') {
			this.heading = 'serviceRequest.trackingRequest.trackComplaint';
			this.requestOrComplaintNumber =
				'serviceRequest.trackingRequest.complaintNumber';
			this.requestOrComplaintDetails = 'serviceRequest.complaintDetails';
			this.requestOrComplaintSubmitted = 'serviceRequest.complaintSubmitted';
			this.requestOrComplaintDate = 'serviceRequest.complaintDate';
		} else {
			this.heading = 'serviceRequest.trackingRequest.trackRequest';
			this.requestOrComplaintNumber =
				'serviceRequest.trackingRequest.requestNumber';
			this.requestOrComplaintDetails = 'serviceRequest.requestDetails';
			this.requestOrComplaintSubmitted = 'serviceRequest.requestSubmitted';
			this.requestOrComplaintDate = 'serviceRequest.requestDate';
		}

		this.onlineServiceRequestService.setSelectedServicerequest = {
			srNo: sessionStorage.getItem('srNo'),
		};
		this.trackRequestRespone = JSON.parse(sessionStorage.getItem('TrackData'));
		this.getServiceRequestStatus();
		if (localStorage.getItem('ViewSource') === 'mobile') {
			this.isMobile = true;
		} else {
			this.isMobile = false;
		}
	}

	goToHome() {
		this.router.navigateByUrl(`/${this.currentLang}`);
	}

	getServiceRequestStatus() {
		if (this.isLifeServiceTrackRequest) {
			this.onlineServiceRequestService.getDLPLifeRequestStatus().subscribe(
				res => {
					this.trackRequestRespone = res;
					sessionStorage.setItem(
						'TrackData',
						JSON.stringify(this.trackRequestRespone),
					);
					console.log(this.trackRequestRespone);
					if (
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() === 'SUBMITTED'
					) {
						this.submissionStatus = 0;
					} else if (
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() ===
							'COMPLETED' ||
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() ===
							'CLAIM INTIMATION PROCESS COMPLETED'
					) {
						this.submissionStatus = 1;
					} else if (
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() ===
							'IN-PROGRESS' ||
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() ===
							'AWAITING FOR PRICING'
					) {
						this.submissionStatus = 2;
					} else if (
						this.trackRequestRespone.COMPLAINT_STATUS.toUpperCase() === 'PENDING'
					) {
						this.submissionStatus = -1;
					}
					this.showMessage = true;
				},
				err => {
					if (err.error) {
						this.serverErrMsg = err.error.message;
					} else {
						this.serverErrMsg = err.message;
					}
					this.showError = true;
				},
				() => {
					this.showError = true;
				},
			);
		} else {
			this.onlineServiceRequestService.getRequestStatus().subscribe(
				res => {
					this.trackRequestRespone = res;
					sessionStorage.setItem(
						'TrackData',
						JSON.stringify(this.trackRequestRespone),
					);
					if (this.trackRequestRespone.COMPLAINT_STATUS === 'Open') {
						this.submissionStatus = 0;
					} else if (this.trackRequestRespone.COMPLAINT_STATUS === 'Closed') {
						this.submissionStatus = 1;
					} else if (this.trackRequestRespone.COMPLAINT_STATUS === 'In Progress') {
						this.submissionStatus = 2;
					}
					this.showMessage = true;
				},
				err => {
					if (err.error) {
						this.serverErrMsg = err.error.message;
					} else {
						this.serverErrMsg = err.message;
					}
					this.showError = true;
				},
				() => {
					this.showError = true;
				},
			);
		}
	}

	backToHome() {}
}
