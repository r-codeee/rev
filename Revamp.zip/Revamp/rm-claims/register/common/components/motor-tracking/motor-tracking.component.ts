import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-motor-tracking',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './motor-tracking.component.html',
  styleUrls: ['./motor-tracking.component.scss']
})
export class MotorTrackingComponent {

}
