import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorTrackingComponent } from './motor-tracking.component';

describe('MotorTrackingComponent', () => {
  let component: MotorTrackingComponent;
  let fixture: ComponentFixture<MotorTrackingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [MotorTrackingComponent]
    });
    fixture = TestBed.createComponent(MotorTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
