import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { BulkUploadComponent } from 'src/app/design-system/bulk-upload/bulk-upload.component';

@Component({
  selector: 'art-additional-attchement-documents',
  standalone: true,
  imports: [CommonModule,TranslateModule,BulkUploadComponent],
  templateUrl: './additional-attchement-documents.component.html',
  styleUrls: ['./additional-attchement-documents.component.scss']
})
// implements OnChanges
export class AdditionalAttchementDocumentsComponent {
  @Input() mode;
  @Input() 
  set addtionalDocCount(value){
    this.documentCount = value;
    this.setList();
  };
  documentCount;
  @Output() uploadDocs = new EventEmitter<any>();
  additionDocuments = [
    {
      lable: 'CLAIMS.MOTOR.UPLOAD_ADDITIONAL_DOCUMENT',
      docName:'UPLOAD_ADDITIONAL_DOCUMENT',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
  ]
  doc = 
    {
      lable: 'CLAIMS.MOTOR.UPLOAD_ADDITIONAL_DOCUMENT',
      docName:'UPLOAD_ADDITIONAL_DOCUMENT',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    }

  removeDoc(index){

  }
  setList(){
    this.additionDocuments = [];
    for(let i = 1; i <= this.documentCount; i++){
      this.additionDocuments.push(this.doc)
    }
  }
  fileBrowseHandler(ev,docName,index){

  }
}
