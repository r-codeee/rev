import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalAttchementDocumentsComponent } from './additional-attchement-documents.component';

describe('AdditionalAttchementDocumentsComponent', () => {
  let component: AdditionalAttchementDocumentsComponent;
  let fixture: ComponentFixture<AdditionalAttchementDocumentsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AdditionalAttchementDocumentsComponent]
    });
    fixture = TestBed.createComponent(AdditionalAttchementDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
