import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { BulkUploadComponent } from 'src/app/design-system/bulk-upload/bulk-upload.component';

@Component({
  selector: 'art-required-attchement-documents',
  standalone: true,
  imports: [CommonModule,TranslateModule,BulkUploadComponent],
  templateUrl: './required-attchement-documents.component.html',
  styleUrls: ['./required-attchement-documents.component.scss']
})
export class RequiredAttchementDocumentsComponent {

  @Input() mode;
  @Output() uploadDocs = new EventEmitter<any>();
  requireDocuments = [
    {
      lable: 'CLAIMS.MOTOR.ACCIDENT_REPORT',
      docName:'accident_report',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.CAR_OWNER_ID_COPY',
      docName:'car_owner_id_copy',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.DRIVER_LICENSE',
      docName:'driving_licence',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.VEHICLE_ESTEMARA',
      docName:'vehicle_estimate',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.DAMAGE_ESTIMATIONS',
      docName:'damage_estimate',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.IBAN_CARD',
      docName:'iban_card',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    },
    {
      lable: 'CLAIMS.MOTOR.AUTHORIZATION_LETTER',
      docName:'authorization_letter',
      isUploadInFailed:false,
      isUploadInSucees:false,
      isUploadInProgress:false
    }
  ]

  fileBrowseHandler(ev,docName){

  }
}
