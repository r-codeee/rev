import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequiredAttchementDocumentsComponent } from './required-attchement-documents.component';

describe('RequiredAttchementDocumentsComponent', () => {
  let component: RequiredAttchementDocumentsComponent;
  let fixture: ComponentFixture<RequiredAttchementDocumentsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RequiredAttchementDocumentsComponent]
    });
    fixture = TestBed.createComponent(RequiredAttchementDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
