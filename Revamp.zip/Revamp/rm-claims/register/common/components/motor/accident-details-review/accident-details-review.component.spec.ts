import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccidentDetailsReviewComponent } from './accident-details-review.component';

describe('AccidentDetailsReviewComponent', () => {
  let component: AccidentDetailsReviewComponent;
  let fixture: ComponentFixture<AccidentDetailsReviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AccidentDetailsReviewComponent]
    });
    fixture = TestBed.createComponent(AccidentDetailsReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
