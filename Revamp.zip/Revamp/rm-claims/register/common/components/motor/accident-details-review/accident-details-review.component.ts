import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'art-accident-details-review',
  standalone: true,
  imports: [CommonModule,TranslateModule],
  templateUrl: './accident-details-review.component.html',
  styleUrls: ['./accident-details-review.component.scss']
})
export class AccidentDetailsReviewComponent {
  @Input() data;
}
