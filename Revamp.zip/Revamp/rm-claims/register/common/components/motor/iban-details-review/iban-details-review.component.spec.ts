import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IbanDetailsReviewComponent } from './iban-details-review.component';

describe('IbanDetailsReviewComponent', () => {
  let component: IbanDetailsReviewComponent;
  let fixture: ComponentFixture<IbanDetailsReviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [IbanDetailsReviewComponent]
    });
    fixture = TestBed.createComponent(IbanDetailsReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
