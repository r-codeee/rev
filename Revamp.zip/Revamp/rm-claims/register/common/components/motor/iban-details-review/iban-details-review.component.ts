import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'art-iban-details-review',
  standalone: true,
  imports: [CommonModule,TranslateModule],
  templateUrl: './iban-details-review.component.html',
  styleUrls: ['./iban-details-review.component.scss']
})
export class IbanDetailsReviewComponent {
  @Input() data;
}
