import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AreYouSureLeaveProcessPopupComponent } from './are-you-sure-leave-process-popup.component';

describe('AreYouSureLeaveProcessPopupComponent', () => {
  let component: AreYouSureLeaveProcessPopupComponent;
  let fixture: ComponentFixture<AreYouSureLeaveProcessPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AreYouSureLeaveProcessPopupComponent]
    });
    fixture = TestBed.createComponent(AreYouSureLeaveProcessPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
