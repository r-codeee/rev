import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-are-you-sure-leave-process-popup',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './are-you-sure-leave-process-popup.component.html',
  styleUrls: ['./are-you-sure-leave-process-popup.component.scss']
})
export class AreYouSureLeaveProcessPopupComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef < AreYouSureLeaveProcessPopupComponent > ) {}
  confirm($event: any) {
    this.dialogRef.close(true)
  }
  close($event: any) {
    this.dialogRef.close();
  }
}
