import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CalimRegisterSuccessPopupComponent } from './calim-register-success-popup.component';

describe('CalimRegisterSuccessPopupComponent', () => {
  let component: CalimRegisterSuccessPopupComponent;
  let fixture: ComponentFixture<CalimRegisterSuccessPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CalimRegisterSuccessPopupComponent]
    });
    fixture = TestBed.createComponent(CalimRegisterSuccessPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
