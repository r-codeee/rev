import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-calim-register-success-popup',
  standalone: true,
  imports: [CommonModule,TranslateModule,PopupAlertComponent],
  templateUrl: './calim-register-success-popup.component.html',
  styleUrls: ['./calim-register-success-popup.component.scss']
})
export class CalimRegisterSuccessPopupComponent {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef < CalimRegisterSuccessPopupComponent > ,private route:Router) {}
  track($event: any) {
    this.dialogRef.close()
    this.route.navigateByUrl('')
  }
  dashboard($event: any) {
    this.dialogRef.close();
    this.route.navigateByUrl('')
  }
}
