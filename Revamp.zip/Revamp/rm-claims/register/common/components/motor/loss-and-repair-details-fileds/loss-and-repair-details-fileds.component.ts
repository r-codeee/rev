import { Component, Input, Output,EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomOption } from 'src/app/rm-cyber-insurance/models/custom-option.model';
import { TranslateModule } from '@ngx-translate/core';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { RmCustomOptionsComponent } from 'src/app/design-system/rm-custom-options/rm-custom-options.component';
import { CustomDropdownComponent } from 'src/app/design-system/custom-dropdown/custom-dropdown.component';

@Component({
  selector: 'art-loss-and-repair-details-fileds',
  standalone: true,
  imports: [CommonModule,TranslateModule,BasicInputComponent,RmCustomOptionsComponent,CustomDropdownComponent],
  templateUrl: './loss-and-repair-details-fileds.component.html',
  styleUrls: ['./loss-and-repair-details-fileds.component.scss']
})
export class LossAndRepairDetailsFiledsComponent {
  @Input() form;
  @Input() isFormSubmitted;
  @Output() setCity = new EventEmitter<any>();
  @Output() setWorkshop = new EventEmitter<any>();
  cityList
  workshopList
  settleMentType
  yesNoOptions: Array<CustomOption> = [
    new CustomOption('Yes', true),
    new CustomOption('No', false),
  ];
  repairOptions: Array<CustomOption> = [
    new CustomOption('Repair', 'repair'),
    new CustomOption('Cash', 'cash'),
  ];
  setCityValue(ev){
    this.setCity.emit(ev)
  }
  setWorkshopValue(ev){
    this.setWorkshop.emit(ev)
  }
  setSettlementTypeValue(ev){
    this.settleMentType = ev;
  }
}
