import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LossAndRepairDetailsFiledsComponent } from './loss-and-repair-details-fileds.component';

describe('LossAndRepairDetailsFiledsComponent', () => {
  let component: LossAndRepairDetailsFiledsComponent;
  let fixture: ComponentFixture<LossAndRepairDetailsFiledsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [LossAndRepairDetailsFiledsComponent]
    });
    fixture = TestBed.createComponent(LossAndRepairDetailsFiledsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
