import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { RmCustomOptionsComponent } from 'src/app/design-system/rm-custom-options/rm-custom-options.component';
import { CustomDropdownComponent } from 'src/app/design-system/custom-dropdown/custom-dropdown.component';
import { CustomOption } from 'src/app/products/personal/rm-mmp/models/custom-option.model';

@Component({
  selector: 'art-vehicle-owner-details-fileds',
  standalone: true,
  imports: [CommonModule,TranslateModule,BasicInputComponent,RmCustomOptionsComponent,CustomDropdownComponent],
  templateUrl: './vehicle-owner-details-fileds.component.html',
  styleUrls: ['./vehicle-owner-details-fileds.component.scss']
})
export class VehicleOwnerDetailsFiledsComponent {
  @Input() form;
  @Input() isFormSubmitted;
  @Output() setSequnceNum = new EventEmitter<any>();
  @Output() setLossRepairStatus = new EventEmitter<any>();
  yesNoOptions: Array<CustomOption> = [
    new CustomOption('Yes', true),
    new CustomOption('No', false),
  ];
  sequenceListOptions = [
    {
      Label_ar:'ocjdposcj',
      Label_en:'cinhaica',
      id:1
    },
    {
      Label_ar:'bcusbc',
      Label_en:'hc90hc',
      id:2
    },
  ]
  setSequnceNumber(ev){
    this.setSequnceNum.emit(ev)
  }
  setLossRepairStatusValue(ev){
    this.setLossRepairStatus.emit(ev)
  }
}
