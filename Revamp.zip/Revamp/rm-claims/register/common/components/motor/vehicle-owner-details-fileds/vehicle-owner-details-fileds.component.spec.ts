import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleOwnerDetailsFiledsComponent } from './vehicle-owner-details-fileds.component';

describe('VehicleOwnerDetailsFiledsComponent', () => {
  let component: VehicleOwnerDetailsFiledsComponent;
  let fixture: ComponentFixture<VehicleOwnerDetailsFiledsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [VehicleOwnerDetailsFiledsComponent]
    });
    fixture = TestBed.createComponent(VehicleOwnerDetailsFiledsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
