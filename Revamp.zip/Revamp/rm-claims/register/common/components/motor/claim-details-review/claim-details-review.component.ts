import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'art-claim-details-review',
  standalone: true,
  imports: [CommonModule,TranslateModule],
  templateUrl: './claim-details-review.component.html',
  styleUrls: ['./claim-details-review.component.scss']
})
export class ClaimDetailsReviewComponent {
  @Input() data;
}
