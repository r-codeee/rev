import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimDetailsReviewComponent } from './claim-details-review.component';

describe('ClaimDetailsReviewComponent', () => {
  let component: ClaimDetailsReviewComponent;
  let fixture: ComponentFixture<ClaimDetailsReviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ClaimDetailsReviewComponent]
    });
    fixture = TestBed.createComponent(ClaimDetailsReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
