import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { PopupAlertComponent } from 'src/app/design-system/popup-alert/popup-alert.component';

@Component({
  selector: 'art-are-you-sure-delete-popup',
  standalone: true,
  imports: [CommonModule,TranslateModule,PopupAlertComponent],
  templateUrl: './are-you-sure-delete-popup.component.html',
  styleUrls: ['./are-you-sure-delete-popup.component.scss']
})
export class AreYouSureDeletePopupComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef < AreYouSureDeletePopupComponent > ) {}
  confirm($event: any) {
    this.dialogRef.close(true)
  }
  close($event: any) {
    this.dialogRef.close();
  }

}
