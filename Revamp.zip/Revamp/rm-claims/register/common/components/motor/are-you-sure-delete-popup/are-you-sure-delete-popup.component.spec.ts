import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AreYouSureDeletePopupComponent } from './are-you-sure-delete-popup.component';

describe('AreYouSureDeletePopupComponent', () => {
  let component: AreYouSureDeletePopupComponent;
  let fixture: ComponentFixture<AreYouSureDeletePopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AreYouSureDeletePopupComponent]
    });
    fixture = TestBed.createComponent(AreYouSureDeletePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
