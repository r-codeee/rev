import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimNajmErrorPopupComponent } from './claim-najm-error-popup.component';

describe('ClaimNajmErrorPopupComponent', () => {
  let component: ClaimNajmErrorPopupComponent;
  let fixture: ComponentFixture<ClaimNajmErrorPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ClaimNajmErrorPopupComponent]
    });
    fixture = TestBed.createComponent(ClaimNajmErrorPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
