import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { BasicInputComponent } from 'src/app/design-system/basic-input/basic-input.component';
import { RmCustomOptionsComponent } from 'src/app/design-system/rm-custom-options/rm-custom-options.component';
import { PhoneBasicInputComponent } from 'src/app/design-system/phone-basic-input/phone-basic-input.component';
import { CustomOption } from 'src/app/rm-cyber-insurance/models/custom-option.model';

@Component({
  selector: 'art-claim-details-fileds',
  standalone: true,
  imports: [CommonModule,TranslateModule,BasicInputComponent,RmCustomOptionsComponent,PhoneBasicInputComponent],
  templateUrl: './claim-details-fileds.component.html',
  styleUrls: ['./claim-details-fileds.component.scss']
})
export class ClaimDetailsFiledsComponent {
  @Input() form;
  @Input() isFormSubmitted;
  yesNoOptions: Array<CustomOption> = [
    new CustomOption('Yes', true),
    new CustomOption('No', false),
  ];
}
