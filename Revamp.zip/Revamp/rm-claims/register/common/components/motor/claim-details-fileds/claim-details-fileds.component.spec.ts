import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimDetailsFiledsComponent } from './claim-details-fileds.component';

describe('ClaimDetailsFiledsComponent', () => {
  let component: ClaimDetailsFiledsComponent;
  let fixture: ComponentFixture<ClaimDetailsFiledsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ClaimDetailsFiledsComponent]
    });
    fixture = TestBed.createComponent(ClaimDetailsFiledsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
