import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttachedDocReviewComponent } from './attached-doc-review.component';

describe('AttachedDocReviewComponent', () => {
  let component: AttachedDocReviewComponent;
  let fixture: ComponentFixture<AttachedDocReviewComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AttachedDocReviewComponent]
    });
    fixture = TestBed.createComponent(AttachedDocReviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
