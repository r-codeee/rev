import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'art-attached-doc-review',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './attached-doc-review.component.html',
  styleUrls: ['./attached-doc-review.component.scss']
})
export class AttachedDocReviewComponent {
  @Input() data;
}
