import { TestBed } from '@angular/core/testing';

import { MotorClaimRegisterService } from './motor-claim-register.service';

describe('MotorClaimRegisterService', () => {
  let service: MotorClaimRegisterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MotorClaimRegisterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
