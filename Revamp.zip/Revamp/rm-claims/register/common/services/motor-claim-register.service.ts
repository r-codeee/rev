import { Injectable } from '@angular/core';
import * as yup from 'yup';
@Injectable({
  providedIn: 'root'
})
export class MotorClaimRegisterService {

  constructor() { }
  createMotorClaimRegisterValidationSchema() {
		return yup.object().shape({
			accidentReportNumber:yup.string().required(),
      sequenceNumber:yup.string().required(),
      nationalIdIqamaId:yup.string().required(),
      areYouOwnerOfThisVehicle:yup.boolean().required(),
      lossType:yup.boolean().required(),
      mobileNumber:yup.string().required(),
      email:yup.string().required(),
      taqdeerNumber:yup.string().required(),
      threeGarageEstimation:yup.boolean().required(),
      yourIbanNumber:yup.string().required(),
      yourBankName:yup.string().required(),
      ownerIbanNumber:yup.string().required(),
      ownerBankName:yup.string().required(),
      settlementType:yup.string().required(),
      repairCity:yup.string().required(),
      workshop:yup.string().required(),
      doYouHaveAnAuthorizationLetter:yup.boolean().required(),
      authorizedNationalId:yup.string().required(),
      authorizedIbanNumber:yup.string().required(),
      authorizedIbanBankName:yup.string().required(),
      acknowledge:yup.string().required(),
		});
	}
}
