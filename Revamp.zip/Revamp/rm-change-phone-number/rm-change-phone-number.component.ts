import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { CommonModule, Location } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RMChangePhoneNumberService } from './rm-change-phone-number.service';
import { ArtButtonComponent } from '../design-system/art-button/art-button.component';
import { ReactiveFormsModule } from '@angular/forms';
import { PhoneBasicInputComponent } from '../design-system/phone-basic-input/phone-basic-input.component';
import { BaseFormComponent } from 'src/art-forms/abstractions/base-form.component';
import { ArtFormBuilderService } from 'src/art-forms/services/art-form-builder.service';
import { ArtValidationRulesService } from 'src/art-forms/services/art-validation-rules.service';
import * as yup from 'yup';
import { AlertComponent } from '../design-system/alert/alert.component';
import { RMAccountFormContainerComponent } from '../design-system/rm-account-form-container/rm-account-form-container.component';
import { RmHeaderDesktopCommonComponent } from '../design-system/rm-header-desktop-common/rm-header-desktop-common.component';
@Component({
	selector: 'art-rm-change-phone-number',
	standalone: true,
	imports: [
		TranslateModule,
		PhoneBasicInputComponent,
		ReactiveFormsModule,
		ArtButtonComponent,
		CommonModule,
		AlertComponent,
		RMAccountFormContainerComponent,
		RmHeaderDesktopCommonComponent
	],
	templateUrl: './rm-change-phone-number.component.html',
	styleUrls: ['./rm-change-phone-number.component.scss'],
})
export class RMChangePhoneNumberComponent extends BaseFormComponent<{
	phoneNumber: string;
}> {
	private readonly changePhoneNumberService = inject(
		RMChangePhoneNumberService,
	);
	private readonly ValidationRulesService = inject(ArtValidationRulesService);
	private readonly location = inject(Location);
	// @TODO: customer data object will come from state..
	@Input() customerData: any = {
		phoneNumber: '',
		referenceId: '',
		transactionType: '',
	};
	@Input() componentConfig: RmChangePhoneNumberComponentConfigI = {
		isFooter: true,
		isRedirectEnabled: true,
		hasCancel: true,
		inputHasLabel: true,
		headerTitleCustomClasses: '',
		headerTitle: 'COMMON.PHONE.TITLE',
		headerDesc: 'COMMON.PHONE.DESCRIPTION',
		saveBtnText: 'COMMON.PHONE.SUBMIT',
	};
	@Input() heightAuto;
	@Input() isMokafaPopUp;
	@Input() headerCloseLink;
	@Input() headerEnable = true;
	@Output() phoneNumberChanged: EventEmitter<string> = new EventEmitter();
	@Output() onCancelled: EventEmitter<void> = new EventEmitter();

	values: { phoneNumber: string } = {
		phoneNumber: '',
	};
	validationSchema = yup.object().shape({
		phoneNumber: this.ValidationRulesService.phoneNumberValidationRule(),
	});
	errmsg: any;

	constructor(protected formBuilderService: ArtFormBuilderService) {
		super(formBuilderService);
	}

	onSubmit(values: { phoneNumber: string }) {
		this.componentConfig?.isRedirectEnabled
			? this.updatePhoneNumber(values.phoneNumber)
			: this.phoneNumberChanged.emit(values.phoneNumber);
	}

	updatePhoneNumber(phoneNumber: string) {
		const payload = {
			mobileNumber: phoneNumber,
			oldMobileNumber: this.customerData.phoneNumber,
			identifier: this.customerData.identifier,
			transactionType: this.customerData.transactionType,
		};

		this.changePhoneNumberService.updateMobileNo(payload).subscribe(
			() => {
				this.phoneNumberChanged.emit(payload.mobileNumber);
				// this.location.back();
			},
			err => {
				this.errmsg = err.error.error.message;
			},
		);
	}
}

export interface RmChangePhoneNumberComponentConfigI {
	isFooter: boolean;
	isRedirectEnabled: boolean;
	hasCancel: boolean;
	inputHasLabel: boolean;
	headerTitleCustomClasses: string;
	headerTitle: string;
	headerDesc: string;
	saveBtnText: string;
}
