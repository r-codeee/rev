import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RMChangePhoneNumberService {

  private _url = environment.loopbackApi;

  constructor(private http:HttpClient) { }

  updateMobileNo(payload, language = localStorage.getItem('selectedLang')) {
    // @TODO: Add the language header to the request from the interceptor.
    const headers = {
      language: language
    }
    return this.http.post(this._url + "/v1/otp/change/mobileNumber", payload, { headers });
  }
}
