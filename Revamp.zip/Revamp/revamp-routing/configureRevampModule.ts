import { TranslateService } from '@ngx-translate/core';
import { QueryClient } from '@tanstack/angular-query-experimental';
import { configureYupMessages } from 'src/art-forms/utility/configureValidationMessages';

export function initializeApp(translateService: TranslateService) {
	return () => {
		configureYupMessages(translateService);
	};
}

export const queryClient = new QueryClient({
	defaultOptions: {
		queries: {
			staleTime: 5 * 60 * 1000,
			retry: 1,
		},
		mutations: {
			retry: 1,
			retryDelay: 5 * 1000,
		},
	},
});
