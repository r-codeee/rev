import { NgModule, APP_INITIALIZER } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import {
	initializeApp,
	queryClient,
} from 'src/app/revamp-routing/configureRevampModule';
import { provideHttpClient } from '@angular/common/http';
import { provideAngularQuery } from '@tanstack/angular-query-experimental';
import { provideLottieOptions } from 'ngx-lottie';
import { QueryApiService } from 'src/app/rm-shared-components/services/query-api.service';
import { RmSadadPaymentComponent } from '../rm-payment/components/rm-sadad-payment/rm-sadad-payment.component';
import { RmPayComponent } from '../rm-payment/components/rm-pay/rm-pay.component';
import { RMPaymentResultComponent } from '../design-system/payment-result/payment-result.component';
import { AuthGuardMySPace } from '../rm-my-space/individual/utils/auth.guard';
import { RMPaymentStatusCheckComponent } from '../design-system/payment-status-check/payment-status-check.component';
import { RmGeneratePaymentStatusComponent } from '../rm-payment/components/rm-generate-payment-status/rm-generate-payment-status.component';

const routes: Routes = [
	{
		path: 'revamp-vve-insurance',
		loadChildren: () =>
			import('../rm-vve/rm-vve.module').then(m => m.RmVVEModule),
	},
	{
		path: 'revamp-cyber-insurance',
		loadChildren: () =>
			import('../rm-cyber-insurance/rm-cyber-insurance.module').then(
				m => m.RMCyberInsuranceModule,
			),
	},
	{
		path: 'revamp-mmp-insurance',
		loadChildren: () =>
			import('../products/personal/rm-mmp/rm-mmp.module').then(
				m => m.RmMmpModule,
			),
	},
	{
		path: 'revamp-motor-insurance-sme',
		loadChildren: () =>
			import('../products/sme/rm-motor/rm-motor.module').then(
				m => m.RmMotorModule,
			),
	},
	{
		path: 'revamp-individual-motor',
		loadChildren: () =>
			import('../rm-individual-motor/rm-individual-motor.module').then(
				m => m.RMIndividualMotorModule,
			),
	},
	{
		path: 'revamp-health-insurance',
		loadChildren: () =>
			import('../products/sme/rm-health-sme/rm-health-sme.module').then(
				m => m.RmHealthSmeModule,
			),
	},
	{
		path: 'revamp-domestic-helper',
		loadChildren: () =>
			import(
				'./../products/personal/rm-domestic-helper/rm-domestic-helper.module'
			).then(m => m.RmDomesticHelperModule),
	},
	{
		path: 'revamp-home-insurance',
		loadChildren: () =>
			import(
				'./../products/personal/rm-home-insurance/rm-home-insurance.module'
			).then(m => m.RmHomeInsuranceModule),
	},
	{
		path: 'revamp-travel-insurance',
		loadChildren: () =>
			import(
				'./../products/personal/rm-travel-insurance/rm-travel-insurance.module'
			).then(m => m.RmTravelInsuranceModule),
	},
	{
		path: 'revamp-life-insurance',
		loadChildren: () =>
			import(
				'./../products/personal/rm-life-insurance/rm-life-insurance.module'
			).then(m => m.RmLifeInsuranceModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-personal',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-personal/life-insurance-protection-and-savings-personal.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsPersonalModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-kids',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-kids/life-insurance-protection-and-savings-kids.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsKidsModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-loaded',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-personal-loaded/life-insurance-protection-and-savings-personal-loaded.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsPersonalLoadedModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-kids-loaded',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-kids-loaded/life-insurance-protection-and-savings-kids-loaded.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsKidsLoadedModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-term',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-term/life-insurance-protection-and-savings-term-insurance.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsTermInsuranceModule),
	},
	{
		path: 'revamp-life-insurance-protection-and-savings-retirement',
		loadChildren: () =>
			import(
				'../products/personal/rm-life-insurance/li-retirement/life-insurance-protection-and-savings-retirement.module'
			).then(m => m.LifeInsuranceProtectionAndSavingsRetirementModule),
	},
	{
		path: 'revamp-auth',
		// data: { showHeader: false, showFooter: false },
		loadChildren: () =>
			import('../rm-auth/rm-auth.module').then(m => m.RmAuthModule),
	},
	{
		path: 'revamp-online-services',
		loadChildren: () =>
			import('../rm-online-services/rm-online-services.module').then(
				m => m.RmOnlineServicesModules,
			),
	},
	{
		path: 'revamp-complaint',
		loadChildren: () =>
			import('../rm-complaint/rm-complaint.module').then(
				m => m.RmComplaintsModule,
			),
	},
	{
		path: 'surplus-distribution-registration',
		loadChildren: () =>
			import(
				'src/app/general-pages/surplus-distribution/surplus-distribution.module'
			).then(m => m.SurplusDistributionModule),
	},
	{
		path: 'generate-sadad',
		loadComponent: () =>
			import(
				'../rm-payment/components/rm-sadad-payment/rm-sadad-payment.component'
			).then(() => RmSadadPaymentComponent),
		data: { showHeader: false, showFooter: false },
	},
	{
		path: 'generate-urpay',
		loadComponent: () =>
			import('../rm-payment/components/rm-ur-pay/rm-ur-pay.component').then(
				m => m.RmUrPayComponent,
			),
	},
	{
		path: 'generate-payment-status',
		loadComponent: () =>
			import(
				'../rm-payment/components/rm-generate-payment-status/rm-generate-payment-status.component'
			).then(() => RmGeneratePaymentStatusComponent),
	},
	{
		path: 'pay-generation',
		data: { showHeader: false, showFooter: false },
		loadComponent: () =>
			import('../rm-payment/components/rm-pay/rm-pay.component').then(
				m => RmPayComponent,
			),
	},
	{
		path: 'pay/payment-status',
		loadComponent: () =>
			import('../design-system/payment-result/payment-result.component').then(
				m => RMPaymentResultComponent,
			),
	},
	{
		path: 'pay/payment-status-check',
		data: { showHeader: false, showFooter: false },
		loadComponent: () =>
			import(
				'../design-system/payment-status-check/payment-status-check.component'
			).then(m => RMPaymentStatusCheckComponent),
	},
	{
		path: 'individual-products',
		loadComponent: () =>
			import(
				'src/app/general-pages/individual-porducts/individual-products.component'
			).then(m => m.IndividualProductsComponent),
	},
	{
		path: 'business-products',
		loadComponent: () =>
			import(
				'src/app/general-pages/business-porducts/business-porducts.component'
			).then(m => m.BusinessPorductsComponent),
	},
	{
		path: 'about',
		loadComponent: () =>
			import('src/app/general-pages/about-us/about-us.component').then(
				m => m.AboutUsComponent,
			),
	},
	{
		path: 'FAQs',
		loadComponent: () =>
			import('src/app/general-pages/faqs/faqs.component').then(
				m => m.FAQSComponent,
			),
	},
	{
		path: 'contact-us',
		loadComponent: () =>
			import('src/app/general-pages/contact-us/contact-us.component').then(
				m => m.ContactUsComponent,
			),
	},

	{
		path: 'takaful',
		loadComponent: () =>
			import('src/app/general-pages/takaful/takaful.component').then(
				m => m.TakafulComponent,
			),
	},
	{
		path: 'investigation',
		loadComponent: () =>
			import(
				'src/app/general-pages/investigation/investigation.component'
			).then(m => m.InvestigationComponent),
	},
	{
		path: 'shariah-sama',
		loadComponent: () =>
			import('src/app/general-pages/shariah/shariah.component').then(
				m => m.ShariahComponent,
			),
	},
	{
		path: 'thanks-contact-us',
		loadComponent: () =>
			import(
				'src/app/general-pages/contact-us-thanks/contact-us-thanks.component'
			).then(m => m.ContactUsThanksComponent),
	},
	{
		path: 'news-media',
		loadComponent: () =>
			import(
				'src/app/general-pages/news-and-media/news-and-media.component'
			).then(m => m.NewsAndMediaComponent),
	},
	{
		path: 'news-article-new',
		loadComponent: () =>
			import(
				'src/app/general-pages/news-and-media-next/news-and-media-next.component'
			).then(m => m.NewsAndMediaNextComponent),
	},
	{
		path: 'motor-claims-tracking',
		loadComponent: () =>
			import(
				'src/app/general-pages/claim-tracking/claim-tracking.component'
			).then(m => m.ClaimTrackingComponent),
	},
	{
		path: 'my-space/individual',
		canActivate: [AuthGuardMySPace],
		loadChildren: () =>
			import('src/app/rm-my-space/individual/individual.module').then(
				m => m.IndividualMySpaceModule,
			),
	},
	{
		path: 'my-space/sme',
		canActivate: [AuthGuardMySPace],
		loadChildren: () =>
			import('src/app/rm-my-space/sme/sme.module').then(m => m.SmeModule),
	},
	{
		path: 'revamp-public-liability',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-public-liability/rm-public-liability.module'
			).then(m => m.RmPublicLiabilityModule),
	},
	{
		path: 'revamp-fedility-guarantee',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-fedility-guarantee/rm-fedility-guarantee.module'
			).then(m => m.RmFefilityGuaranteeModule),
	},
	{
		path: 'revamp-group-life-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-group-life-insurance/rm-group-life-insurance.module'
			).then(m => m.RmGroupLifeInsuranceModule),
	},
	{
		path: 'revamp-trade-credit-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-trade-credit-insurance/rm-trade-credit-insurance.module'
			).then(m => m.RmTradeCreditInsuranceModule),
	},
	{
		path: 'revamp-workmen-compenstation-employers-liability-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-workmen-compenstation-employers-liability-insurance/rm-workmen-compenstation-employers-liability-insurance.module'
			).then(m => m.RmWorkmenCompenstationEmployersLiabilityInsuranceModule),
	},
	{
		path: 'revamp-property-all-risk-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-property-all-risk-insurance/rm-property-all-risk-insurance.module'
			).then(m => m.RmPropertyAllRiskInsuranceModule),
	},
	{
		path: 'revamp-contractors-all-risk-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-contractors-all-risk-insurance/rm-contractors-all-risk-insurance.module'
			).then(m => m.RmContractorsAllRiskInsuranceModule),
	},
	{
		path: 'revamp-contractors-plant-and-machinery-insurance',
		loadChildren: () =>
			import(
				'src/app/products/sme/rm-contractors-plant-machinery-insurance/rm-contractors-plant-machinery-insurance.module'
			).then(m => m.RmContractorsPlantMachineryInsuranceModule),
	},
	{
		path: 'revamp-supplier-services',
		loadChildren: () =>
			import(
				'src/app/rm-supplier-services/rm-supplier-services.module'
			).then(m => m.RmSupplierServicesModule),
	},
	{
		path: 'investor-relations',
		loadComponent: () =>
			import('src/app/general-pages/investorrelations/investorrelations.component').then(
				m => m.InvestorrelationsComponent,
			),
	},
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule],
	providers: [
		QueryApiService,
		{
			provide: APP_INITIALIZER,
			useFactory: initializeApp,
			deps: [TranslateService],
			multi: true,
		},
		provideHttpClient(),
		provideAngularQuery(queryClient),
		provideLottieOptions({
			player: () => import('lottie-web'),
		}),
	],
})
export class RevampRoutingModule { }
